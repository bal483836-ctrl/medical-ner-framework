#!/usr/bin/env python3
"""run_small_test.py 数据格式兼容性轻量测试。"""
import json
import tempfile
from pathlib import Path

import run_small_test


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def main() -> None:
    samples = [
        {"text": "患者头痛", "entities": [{"entity": "头痛"}]},
        {"dialogue": [{"sentence": "发热", "symptom_norm": ["发热"], "symptom_type": ["1"]}]},
    ]
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        cases = {
            "array.json": json.dumps(samples, ensure_ascii=False),
            "jsonl.json": "\n".join(json.dumps(x, ensure_ascii=False) for x in samples),
            "prefixed_jsonl.json": "1\t" + json.dumps(samples[0], ensure_ascii=False) + "\n2\t" + json.dumps(samples[1], ensure_ascii=False),
            "continuous.json": "".join(json.dumps(x, ensure_ascii=False) for x in samples),
            "noisy.json": "LOG_PREFIX\n" + json.dumps(samples, ensure_ascii=False),
        }
        for name, content in cases.items():
            path = root / name
            write_text(path, content)
            loaded = run_small_test._load_json(str(path))
            assert len(loaded) == 2, f"{name} expected 2 records, got {len(loaded)}"
            assert all(isinstance(x, dict) for x in loaded), f"{name} contains non-dict records"
    print("small loader format smoke test passed")


if __name__ == "__main__":
    main()
