import os
from config.config import (
    IMCS_DEV_PATH, IMCS_TRAIN_PATH, CMEEE_DEV_PATH, YIDU_DEV_PATH,
    PRIMARY_MODEL_PATH, SECONDARY_MODEL_PATH,
)

paths = [
    ("IMCS_TRAIN", IMCS_TRAIN_PATH),
    ("IMCS_DEV", IMCS_DEV_PATH),
    ("CMEEE_DEV", CMEEE_DEV_PATH),
    ("YIDU_DEV", YIDU_DEV_PATH),
    ("PRIMARY_MODEL", PRIMARY_MODEL_PATH),
    ("SECONDARY_MODEL", SECONDARY_MODEL_PATH),
]

for name, path in paths:
    print(f"{name}: {path} | exists={os.path.exists(path)}")
