# 医疗 NER v21 项目 F1 低分诊断与优化交付报告

作者：**Manus AI**  
日期：2026-05-18

## 一、结论概览

本次检查后可以明确判断：当前项目 macro/micro F1 只有约 0.1，首要原因不是模型完全不会抽取，而是 **IMCS 任务口径、评估口径和归一化链路存在系统性错配**。项目提示词要求模型在 IMCS 阶段输出“口语原文症状”，例如“拉肚子”“发烧”；但评估 gold 侧使用的是 `symptom_norm` 标准医学词，例如“腹泻”“发热”。这样会把大量本应通过归一化后正确的预测判成 FP/FN，从而显著压低 F1。

此外，旧版 `compute_set_f1()` 把 gold 与 pred 同为空的 chunk 的样本级 F1 记为 0。IMCS 对话中存在大量无症状轮次，这会严重压低 macro F1。项目还存在当前轮与上下文混标、温度标准词归一化错误、LLM 归一化候选词表截断等问题。上述问题已经在源码中完成修复，并通过全项目语法编译和轻量回归测试。

| 维度 | 修复前问题 | 已做修复 | 预期影响 |
|---|---|---|---|
| IMCS raw 评估 | 口语预测直接对比标准词 gold | raw 评估对 IMCS 先规则归一化再对齐 gold | 直接消除“拉肚子 vs 腹泻”类系统性错判 |
| macro F1 | 空空 chunk 记为 0 | 空空 chunk 记为 1，并新增 `macro_f1_nonempty` | 修复 macro F1 被无症状轮次人为压低的问题 |
| chunk 对齐 | IMCS 允许从 context 抽取并归入当前 chunk | IMCS 只锚定当前 sentence | 降低跨轮 FP |
| 温度归一化 | 37.3--41.0 统一归为“发热” | 按低热 / 中等度热 / 高热分级 | 提高温度类标准词精度 |
| 归一化兜底 | 标准词表只传前 80 个 | 传完整 IMCS 标准词表 | 减少 LLM 归一化漏候选 |
| IMCS 召回 | 完全依赖 LLM 抽取 | 增加当前句词典召回补充和否定/问句过滤 | 提升常见症状召回率 |
| 工程可运行性 | `build_imcs_dict.py` 有语法错误 | 修复缺失导入与缩进结构 | 全项目编译通过 |

## 二、为什么 F1 会只有 0.1

项目的 IMCS 设计本来是“两阶段”：第一阶段从对话中抽取 **口语原文症状**，第二阶段再归一化成标准词。这个设计在历史模块 `src/normalize_imcs_step.py` 中也写得很清楚：输入字段是 `step1_sentence_entities` 中的 raw 口语，输出字段才是 `step2_normalized_entities` 与 `step2_normed_output`。

当前 v21 代码的问题在于，`src/dataset_detector.py` 构造 IMCS gold 时只能使用 `symptom_norm`，也就是标准词；而 `src/unified_prompt.py` 的 IMCS prompt 明确要求模型不要归一化，必须输出原文表述。因此在 `src/unified_normalize_eval.py` 的 raw 评估阶段，预测和标注并不在同一语义空间。典型例子如下。

| 原文 | 模型按 prompt 输出 | gold 的 `symptom_norm` | 旧评估结果 | 正确处理 |
|---|---|---|---|---|
| 宝宝拉肚子两天 | 拉肚子 | 腹泻 | FP=拉肚子，FN=腹泻 | 先归一化为“腹泻”再评估 |
| 体温 38.5 度 | 38.5度 | 中等度热 | FP=38.5度，FN=中等度热 | 温度分级为“中等度热” |
| 有点发烧 | 发烧 | 发热 | FP=发烧，FN=发热 | 口语映射为“发热” |

> **核心判断：** 如果 gold 只有标准词，那么 raw 预测必须先进入归一化层；否则 raw F1 不是模型抽取能力指标，而是“口语词与标准词不相等”的惩罚指标。

micro F1 低，主要来自上述口径错配造成的大量 FP/FN；macro F1 低，则还叠加了空 chunk 被记为 0 的实现问题。修复之后，macro 指标会同时输出 `macro_f1` 和 `macro_f1_nonempty`，后者只统计 gold 或 pred 非空的 chunk，更适合定位实体抽取错误。

## 三、已修改的核心文件

本次直接修改了以下文件，并保留了补丁文件 `f1_fix.patch` 供你在原环境中审查或应用。

| 文件 | 修改重点 |
|---|---|
| `src/unified_normalize_eval.py` | 修复 `compute_set_f1()` 的空空 chunk macro 口径；IMCS raw 评估先规则归一化再对齐 gold；优化温度归一化；LLM 归一化传完整标准词表；新增 `macro_f1_nonempty`、`n_true_empty` 等诊断字段。 |
| `src/unified_extractor.py` | IMCS 抽取只验证当前句，不再把 context 中实体归入当前 chunk；增加词典召回补充；增加否定句和问句过滤；解析模型输出时去掉“症状：”等前缀噪声。 |
| `src/unified_prompt.py` | 归一化 prompt 不再截断标准词表，避免正确标准词没有传给模型。 |
| `src/build_imcs_dict.py` | 修复历史脚本的语法错误和缺失 `json` 导入，使全项目编译通过。 |
| `test_f1_fix_smoke.py` | 新增轻量回归测试，覆盖 macro 空 chunk、口语映射和温度分级。 |

## 四、验证结果

由于压缩包中没有真实 IMCS/CMeEE/Yidu 数据文件，也没有配置中引用的本地大模型路径，本沙箱无法复跑完整训练/推理并给出真实 F1。实际检查结果显示配置路径均不存在，例如 IMCS dev 路径 `/root/autodl-tmp/MedNER_Project/new_data/IMCS_V2/IMCS_V2_dev_new.json` 和 Qwen/DeepSeek 模型路径都不存在。因此我没有编造实测 0.8 的结果，而是完成了可运行源码修复与可复跑验证。

当前已经通过以下验证。

| 验证项 | 命令 | 结果 |
|---|---|---|
| 全项目语法检查 | `python3.11 -m py_compile run_pipeline.py src/*.py config/*.py` | 通过 |
| 轻量回归测试 | `python3.11 test_f1_fix_smoke.py` | `smoke tests passed` |
| 补丁生成 | `diff -ru backups_before_f1_fix src > f1_fix.patch` | 已生成 |

## 五、如何在你的原环境中复跑

你可以将我交付的修改版项目解压到原运行机器，确认 `config/config.py` 中的数据和模型路径指向真实文件后，按原 README 或主脚本方式运行。建议优先只跑 IMCS dev，小样本确认指标趋势，再跑完整集合。

```bash
cd medical_ner_v21_FINAL
python3.11 -m py_compile run_pipeline.py src/*.py config/*.py
python3.11 test_f1_fix_smoke.py
python3.11 run_pipeline.py --dataset imcs --split dev
```

如果你的 `run_pipeline.py` 参数名与实际 README 略有差异，请以项目 README 中的命令为准。关键是复跑后重点查看三类指标：`micro_f1`、`macro_f1`、`macro_f1_nonempty`。如果修复前的 0.1 主要来自口径错配，那么 IMCS 的标准词对齐 F1 应该会显著上升；若仍未达到 0.8，则下一步应基于错误样本继续扩展 `imcs_oral_to_norm.json`，并把 FN 高频口语加入词典。

## 六、达到 0.8 左右的进一步建议

本次修复解决的是“指标算错/口径错配/归一化不稳”的基础问题。要稳定达到 0.8 左右，还需要在真实 dev 集上做错误分析。建议按以下顺序推进，而不是直接更换模型。

| 优先级 | 优化方向 | 具体做法 | 预计收益 |
|---|---|---|---|
| 高 | 扩充 IMCS 口语映射 | 从 dev/train 的 FN 中抽取高频口语，补充 `data/dicts/imcs_oral_to_norm.json` | 通常对 micro F1 提升最直接 |
| 高 | 强化否定与问句过滤 | 对“有没有咳嗽”“不发烧”“无腹泻”等模板做规则回归测试 | 降低 FP，提高 precision |
| 中 | 保留错误样本表 | 每次评估导出 FP/FN/TP 明细，按标准词聚合 | 让优化可迭代而不是盲改 prompt |
| 中 | 对低频标准词做 few-shot | 将高频错例加入 prompt 示例或技能库 | 改善 LLM 对口语变体的泛化 |
| 低 | 模型替换/微调 | 在评估链路正确后再考虑 SFT 或更强模型 | 避免用模型能力掩盖工程错误 |

## 七、交付文件说明

我已经在修改版项目目录中生成并保留了以下文件。

| 文件 | 用途 |
|---|---|
| `medical_ner_v21_FINAL_f1_fixed.zip` | 修改后的完整项目包，可直接下载到原环境复跑。 |
| `f1_fix.patch` | 相对备份源码的差异补丁，便于审查具体改动。 |
| `F1_FIX_REPORT.md` | 本报告。 |
| `F1_DIAGNOSIS_NOTES.md` | 诊断过程中的原始要点记录。 |
| `test_f1_fix_smoke.py` | 回归测试脚本。 |

## 八、最终建议

请优先在你的原始机器上用真实数据和本地 Qwen/DeepSeek 模型复跑一次 IMCS dev。若修复后 micro F1 已接近或超过 0.8，说明原先 0.1 的主要原因就是评估口径和归一化链路错误。若修复后仍低于 0.8，请把评估输出中的 FP/FN 明细或预测 JSON 发给我，我可以继续基于真实错误分布做第二轮词典扩展、规则修正和 prompt 精调。
