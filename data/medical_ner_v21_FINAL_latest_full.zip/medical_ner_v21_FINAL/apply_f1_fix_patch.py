from pathlib import Path

base = Path('/home/ubuntu/medical_ner_work/medical_ner_v21_FINAL')

# Patch unified_normalize_eval.py
p = base / 'src' / 'unified_normalize_eval.py'
s = p.read_text(encoding='utf-8')

s = s.replace(
'''def compute_set_f1(gold_list: List[Set[str]],
                   pred_list: List[Set[str]]) -> Dict:
    """字符串集合 F1（统一指标）"""
    tp = fp = fn = 0
    per_sample_f1 = []
    for gold, pred in zip(gold_list, pred_list):
        c_tp = len(gold & pred)
        c_fp = len(pred - gold)
        c_fn = len(gold - pred)
        tp += c_tp; fp += c_fp; fn += c_fn
        _, _, f1 = compute_f1(c_tp, c_fp, c_fn)
        per_sample_f1.append(f1)
    p, r, micro = compute_f1(tp, fp, fn)
    macro = sum(per_sample_f1) / len(per_sample_f1) if per_sample_f1 else 0.0
    return {
        "tp": tp, "fp": fp, "fn": fn,
        "precision": round(p, 4), "recall": round(r, 4),
        "micro_f1": round(micro, 4), "macro_f1": round(macro, 4),
        "n_samples": len(gold_list),
    }
''',
'''def compute_set_f1(gold_list: List[Set[str]],
                   pred_list: List[Set[str]]) -> Dict:
    """字符串集合 F1（统一指标）

    修复点：旧版把 gold/pred 同为空的 chunk 的样本级 F1 记为 0，
    这会在 IMCS 这类大量无症状对话轮次上显著压低 macro F1。
    这里同时返回三种口径：
      - micro_f1：实体级 TP/FP/FN，NER 主指标；
      - macro_f1：空空 chunk 记为 1 的样本平均；
      - macro_f1_nonempty：仅统计 gold 或 pred 非空的 chunk，便于错误定位。
    """
    tp = fp = fn = 0
    per_sample_f1 = []
    per_sample_f1_nonempty = []
    true_empty = 0
    for gold, pred in zip(gold_list, pred_list):
        c_tp = len(gold & pred)
        c_fp = len(pred - gold)
        c_fn = len(gold - pred)
        tp += c_tp; fp += c_fp; fn += c_fn
        if not gold and not pred:
            f1 = 1.0
            true_empty += 1
        else:
            _, _, f1 = compute_f1(c_tp, c_fp, c_fn)
            per_sample_f1_nonempty.append(f1)
        per_sample_f1.append(f1)
    p, r, micro = compute_f1(tp, fp, fn)
    macro = sum(per_sample_f1) / len(per_sample_f1) if per_sample_f1 else 0.0
    macro_nonempty = (sum(per_sample_f1_nonempty) / len(per_sample_f1_nonempty)
                      if per_sample_f1_nonempty else 0.0)
    return {
        "tp": tp, "fp": fp, "fn": fn,
        "precision": round(p, 4), "recall": round(r, 4),
        "micro_f1": round(micro, 4), "macro_f1": round(macro, 4),
        "macro_f1_nonempty": round(macro_nonempty, 4),
        "n_samples": len(gold_list),
        "n_true_empty": true_empty,
    }
''')

s = s.replace(
'''    print(f"  Micro F1:  {result['micro_f1']:.4f}")
    print(f"  Macro F1:  {result['macro_f1']:.4f}")
''',
'''    print(f"  Micro F1:  {result['micro_f1']:.4f}")
    print(f"  Macro F1:  {result['macro_f1']:.4f}")
    if 'macro_f1_nonempty' in result:
        print(f"  Macro F1*: {result['macro_f1_nonempty']:.4f}  (仅 gold/pred 非空 chunk)")
    if 'n_true_empty' in result:
        print(f"  空空正确 chunk: {result['n_true_empty']}")
''')

s = s.replace(
'''def evaluate_raw_extraction(items: List[DataItem],
                            extraction_results: List[Dict],
                            name: str = "原始抽取") -> Dict:
    """对统一抽取结果做字符串集合 F1 评估
    每个 chunk 一个样本（同一 DataItem 内多个 chunk 独立评估）。
    """
    gold_chunks = {}    # chunk_id -> gold set
    for item in items:
        for chunk in item.text_chunks:
            cid = chunk["id"]
            gold_chunks[cid] = get_gold_set_for_chunk(item, cid, use_norm=False)

    pred_chunks = {}
    for item_result in extraction_results:
        for ch in item_result.get("chunks", []):
            pred_chunks[ch["id"]] = set(
                e["entity"] for e in ch.get("reflected_entities", [])
            )

    gold_list, pred_list = [], []
    for cid in gold_chunks:
        gold_list.append(gold_chunks[cid])
        pred_list.append(pred_chunks.get(cid, set()))

    result = compute_set_f1(gold_list, pred_list)
    print_eval_report(name, result)
    return result
''',
'''def evaluate_raw_extraction(items: List[DataItem],
                            extraction_results: List[Dict],
                            name: str = "原始抽取") -> Dict:
    """对统一抽取结果做字符串集合 F1 评估。

    对 CMeEE/Yidu，gold 与 pred 都是原文实体字符串。
    对 IMCS，数据集中可用 gold 是 symptom_norm 标准词，而抽取 prompt 要求输出口语原文。
    因此这里先用规则把 raw 预测归一化后再与标准词 gold 对齐，否则会出现
    “拉肚子 vs 腹泻”这类系统性 FP/FN，导致 F1 被错误压低。
    """
    is_norm_dataset = bool(items and items[0].has_norm_field)
    oral_map, norm_vocab = ({}, set())
    if is_norm_dataset:
        oral_map, norm_vocab = _build_norm_resources()
        if items and getattr(items[0], 'dataset_type', '') == DATASET_IMCS:
            name = name + " | IMCS raw预测已规则归一化对齐gold"

    gold_chunks = {}    # chunk_id -> gold set
    for item in items:
        for chunk in item.text_chunks:
            cid = chunk["id"]
            gold_chunks[cid] = get_gold_set_for_chunk(item, cid, use_norm=is_norm_dataset)

    pred_chunks = {}
    for item_result in extraction_results:
        for ch in item_result.get("chunks", []):
            preds = set()
            for e in ch.get("reflected_entities", []):
                ent = e.get("entity", "")
                if not ent:
                    continue
                if is_norm_dataset:
                    normed = _rule_based_normalize(ent, oral_map, {}, norm_vocab).get("normed")
                    if normed:
                        preds.add(normed)
                else:
                    preds.add(ent)
            pred_chunks[ch["id"]] = preds

    gold_list, pred_list = [], []
    for cid in gold_chunks:
        gold_list.append(gold_chunks[cid])
        pred_list.append(pred_chunks.get(cid, set()))

    result = compute_set_f1(gold_list, pred_list)
    result["imcs_raw_pred_rule_normalized"] = is_norm_dataset
    print_eval_report(name, result)
    return result
''')

s = s.replace(
'''    # 8) 温度推断
    temp_match = re.search(r'(\d{2}\.?\d?)\s*[°℃度]', entity)
    if temp_match:
        try:
            t = float(temp_match.group(1))
            if 37.3 <= t <= 41.0:
                return {"normed": "发热", "method": "temperature_inference"}
        except ValueError:
            pass

    return {"normed": None, "method": "rule_fail"}
''',
'''    # 8) 温度推断：优先归到 IMCS 标准词表中的低热/中等度热/高热，
    # 避免把所有温度都归为“发热”造成标准词错配。
    temp_match = re.search(r'(\d{2}(?:\.\d)?)\s*[°℃度]?', entity)
    if temp_match:
        try:
            t = float(temp_match.group(1))
            if 37.3 <= t <= 38.0 and "低热" in norm_vocab:
                return {"normed": "低热", "method": "temperature_low"}
            if 38.0 < t <= 39.0 and "中等度热" in norm_vocab:
                return {"normed": "中等度热", "method": "temperature_medium"}
            if 39.0 < t <= 41.0 and "高热" in norm_vocab:
                return {"normed": "高热", "method": "temperature_high"}
            if 37.3 <= t <= 41.0 and "发热" in norm_vocab:
                return {"normed": "发热", "method": "temperature_fever"}
        except ValueError:
            pass

    # 9) 轻量模糊匹配：救回“咳漱/发熱/浠水”等边缘错别字，阈值保守。
    n_chars = set(c for c in entity if '\u4e00' <= c <= '\u9fff')
    if len(n_chars) >= 2:
        best_norm, best_score = None, 0.0
        for norm in norm_vocab:
            v_chars = set(c for c in norm if '\u4e00' <= c <= '\u9fff')
            if not v_chars:
                continue
            score = len(n_chars & v_chars) / max(len(n_chars), len(v_chars))
            if score > best_score:
                best_norm, best_score = norm, score
        if best_norm and best_score >= 0.75:
            return {"normed": best_norm, "method": "fuzzy_match"}

    return {"normed": None, "method": "rule_fail"}
''')

s = s.replace(
'''    vocab_sample = sorted(norm_vocab)
    if len(vocab_sample) > 80:
        vocab_sample = vocab_sample[:80]

    prompts = [
        UnifiedPromptFactory.build_normalize_prompt(oral, vocab_sample)
        for oral in todo
    ]
''',
'''    # 标准症状词表约百级规模，完整传入更安全；旧版截断前 80 个会漏掉正确候选。
    vocab_sample = sorted(norm_vocab)

    prompts = [
        UnifiedPromptFactory.build_normalize_prompt(oral, vocab_sample)
        for oral in todo
    ]
''')

p.write_text(s, encoding='utf-8')

# Patch unified_prompt.py to use full vocab sample
p = base / 'src' / 'unified_prompt.py'
s = p.read_text(encoding='utf-8')
s = s.replace('''    vocab_str = "、".join(norm_vocab_sample[:60])\n''', '''    vocab_str = "、".join(norm_vocab_sample)\n''')
p.write_text(s, encoding='utf-8')

# Patch unified_extractor.py
p = base / 'src' / 'unified_extractor.py'
s = p.read_text(encoding='utf-8')
s = s.replace('''from src.llm_client import get_client, parse_deepseek_answer\n''', '''from src.llm_client import get_client, parse_deepseek_answer\nfrom src.kg_alignment import get_oral_to_standard_map, build_imcs_norm_vocab\n''')

s = s.replace('''def _parse_imcs_list(raw: str) -> List[str]:\n    if not raw:\n        return []\n    raw = raw.strip().strip('"').strip("'")\n    if raw in ("无", "none", "None", "无症状", ""):\n        return []\n    parts = re.split(r'[、,，;；\\s]+', raw)\n    return [p.strip() for p in parts if p.strip() and p.strip() != "无"]\n''', '''def _parse_imcs_list(raw: str) -> List[str]:\n    if not raw:\n        return []\n    raw = raw.strip().strip('"').strip("'")\n    raw = re.sub(r'^(原文症状|症状|保留的症状|输出)[:：]\\s*', '', raw)\n    if raw in ("无", "none", "None", "无症状", ""):\n        return []\n    parts = re.split(r'[、,，;；\\s]+', raw)\n    cleaned = []\n    for p in parts:\n        p = re.sub(r'^(原文症状|症状|保留的症状)[:：]', '', p.strip())\n        if p and p != "无":\n            cleaned.append(p)\n    return cleaned\n''')

insert_after = '''def _entity_in_text(entity: str, text: str, context: str = "") -> bool:\n    """实体是否字面出现"""\n    if not entity:\n        return False\n    full = (text or "") + (context or "")\n    if entity in full:\n        return True\n    trimmed = _trim_boundary(entity)\n    return bool(trimmed) and trimmed in full\n'''
addition = insert_after + '''\n\n_IMCS_RULE_CACHE = None\n_SHORT_IMCS_TERMS = {"烧", "咳", "吐", "喘", "泻", "热"}\n\n\ndef _get_imcs_rule_terms():\n    """加载 IMCS 口语词典和标准词表，用于补充召回。"""\n    global _IMCS_RULE_CACHE\n    if _IMCS_RULE_CACHE is None:\n        try:\n            oral_terms = list(get_oral_to_standard_map().keys())\n            norm_terms = list(build_imcs_norm_vocab())\n        except Exception:\n            oral_terms, norm_terms = [], []\n        terms = sorted(set(oral_terms) | set(norm_terms), key=len, reverse=True)\n        _IMCS_RULE_CACHE = terms\n    return _IMCS_RULE_CACHE\n\n\ndef _is_negated_or_questioned(text: str, start: int, end: int, speaker: str = "") -> bool:\n    """保守过滤否定句和纯询问句中的症状候选。"""\n    left = text[max(0, start - 6):start]\n    right = text[end:min(len(text), end + 4)]\n    window = left + text[start:end] + right\n    if re.search(r'(不|没|无|未|没有|否认|不是|不伴|未见)$', left) or re.search(r'(不|吗|么|嘛|没有|有无|有没有)', window):\n        return True\n    # 医生问句通常不是患者已存在症状；医生判断/诊断句不在这里屏蔽。\n    if ("?" in text or "？" in text) and re.search(r'(吗|么|嘛|有无|有没有|是否|是不是|多少|怎么)', text):\n        return True\n    return False\n\n\ndef _supplement_imcs_entities(text: str, speaker: str, entities: List[Dict]) -> List[Dict]:\n    """基于词典对 IMCS 当前发言做召回补充，补的是原文口语/标准词表面词。\n\n    只锚定当前 sentence，不锚定 context，避免按 chunk 评估时跨轮串标。\n    """\n    if os.environ.get("MNER_IMCS_RULE_SUPPLEMENT", "1") == "0":\n        return entities\n    seen = {e.get("entity") for e in entities}\n    out = list(entities)\n    for term in _get_imcs_rule_terms():\n        if not term or term in seen:\n            continue\n        if len(term) < 2 and term not in _SHORT_IMCS_TERMS:\n            continue\n        pos = text.find(term)\n        if pos < 0:\n            continue\n        if _is_negated_or_questioned(text, pos, pos + len(term), speaker):\n            continue\n        out.append({"entity": term, "type": "sym", "source": "rule_supplement"})\n        seen.add(term)\n    return out\n'''
s = s.replace(insert_after, addition)

# IMCS parse: current sentence only + supplement
s = s.replace('''        elif dataset_type == DATASET_IMCS:\n            names = _parse_imcs_list(raw)\n            for n in names:\n                n_trim = _trim_boundary(n)\n                if not n_trim:\n                    continue\n                if not _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):\n                    continue\n                entities.append({"entity": n_trim, "type": "sym"})\n''', '''        elif dataset_type == DATASET_IMCS:\n            names = _parse_imcs_list(raw)\n            for n in names:\n                n_trim = _trim_boundary(n)\n                if not n_trim:\n                    continue\n                # IMCS 评估按当前 turn/chunk 对齐，不能把上文 context 中的症状归到当前 chunk。\n                if not _entity_in_text(n_trim, chunk["text"], ""):\n                    continue\n                entities.append({"entity": n_trim, "type": "sym"})\n            entities = _supplement_imcs_entities(chunk["text"], chunk.get("speaker", ""), entities)\n''')

s = s.replace('''                if _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):\n                    new_entities.append({"entity": n_trim, "type": "sym"})\n            return new_entities\n''', '''                if _entity_in_text(n_trim, chunk["text"], ""):\n                    new_entities.append({"entity": n_trim, "type": "sym"})\n            return _supplement_imcs_entities(chunk["text"], chunk.get("speaker", ""), new_entities)\n''', 1)

s = s.replace('''                    if _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):\n                        new_entities.append({"entity": n_trim, "type": "sym"})\n                result[i] = new_ents\n''', '''                    if _entity_in_text(n_trim, chunk["text"], ""):\n                        new_entities.append({"entity": n_trim, "type": "sym"})\n                result[i] = _supplement_imcs_entities(chunk["text"], chunk.get("speaker", ""), new_ents)\n''')

p.write_text(s, encoding='utf-8')

print('patch applied')
