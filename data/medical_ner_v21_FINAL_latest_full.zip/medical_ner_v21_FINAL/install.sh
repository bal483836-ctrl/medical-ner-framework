#!/bin/bash
# ============================================================================
# 5090 + cu128 终极方案（实测验证）
# ============================================================================
# 验证组合：
#   torch 2.10.0+cu128 + vllm 0.19.1 + AWQ Marlin
# 
# 关键点：
#   1. --index-url 必须是 pytorch cu128（让 pip 拉 cu128 编译版）
#   2. 删除源码 vllm（避免污染）
#   3. 禁用 torch._inductor 中有 bug 的文件
#   4. enforce_eager=True 绕开 torch.compile bug
# ============================================================================

set -e

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[0;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[INFO]${NC} $1"; }
ok()   { echo -e "${GREEN}[ OK ]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[FAIL]${NC} $1"; }

echo "═══════════════════════════════════════════════════════"
echo "  v21 FINAL 安装 - 5090 + cu128（实测可用）"
echo "═══════════════════════════════════════════════════════"

# ============================================================================
# Step 0: 环境准备
# ============================================================================

log "Step 0: 准备临时空间"
export TMPDIR=/root/autodl-tmp/pip_tmp
export PIP_CACHE_DIR=/root/autodl-tmp/pip_cache
mkdir -p $TMPDIR $PIP_CACHE_DIR
df -h / /root/autodl-tmp

# ============================================================================
# Step 1: 清掉源码 vllm（已知污染源）
# ============================================================================

log "Step 1: 检查并清理源码 vllm"
if [ -d /root/autodl-tmp/vllm ] && [ -f /root/autodl-tmp/vllm/setup.py ]; then
    mv /root/autodl-tmp/vllm /root/autodl-tmp/vllm.BAK.$(date +%s)
    ok "已移走源码 vllm（防止污染 import）"
else
    ok "源码 vllm 不存在"
fi
unset PYTHONPATH 2>/dev/null || true

# ============================================================================
# Step 2: 卸载冲突包
# ============================================================================

log "Step 2: 卸载冲突的旧版本"
pip uninstall -y \
    vllm \
    torch torchvision torchaudio xformers triton \
    autoawq flashinfer-python flashinfer-cubin \
    nvidia-cudnn-cu12 nvidia-cublas-cu12 nvidia-cufft-cu12 \
    nvidia-cuda-runtime-cu12 nvidia-cuda-nvrtc-cu12 nvidia-cuda-cupti-cu12 \
    nvidia-curand-cu12 nvidia-cusolver-cu12 nvidia-cusparse-cu12 \
    nvidia-cusparselt-cu12 nvidia-nccl-cu12 nvidia-nvtx-cu12 nvidia-nvjitlink-cu12 \
    nvidia-cufile-cu12 \
    2>&1 | tail -3 || true
ok "旧版本已清理"

# ============================================================================
# Step 3: 一次性装 vllm 0.19（让它拉对的 cu128 torch）
# ============================================================================

log "Step 3: 装 vllm 0.19 (5090 cu128 兼容版)"
log "  关键：--index-url 必须是 pytorch cu128"

pip install --timeout=900 \
    --index-url https://download.pytorch.org/whl/cu128 \
    --extra-index-url https://pypi.tuna.tsinghua.edu.cn/simple \
    "vllm>=0.11.0,<0.20.0"

# ============================================================================
# Step 4: 禁用 torch 中触发 duplicate template name 的 buggy 文件
# ============================================================================

log "Step 4: 禁用 torch._inductor 中的 buggy 文件"
BUGGY=/root/miniconda3/lib/python3.12/site-packages/torch/_inductor/kernel/mm_scaled_grouped.py
if [ -f "$BUGGY" ]; then
    mv "$BUGGY" "$BUGGY.disabled"
    ok "已禁用 mm_scaled_grouped.py"
elif [ -f "$BUGGY.disabled" ]; then
    ok "mm_scaled_grouped.py 已禁用过"
else
    warn "未找到 mm_scaled_grouped.py（可能 torch 版本不同，跳过）"
fi

# ============================================================================
# Step 5: 验证环境
# ============================================================================

log "Step 5: 端到端验证"

python -c "
import vllm
assert '/miniconda3/' in vllm.__file__, f'❌ vllm 不在 site-packages: {vllm.__file__}'
print(f'  vllm 路径:  {vllm.__file__}')
print(f'  vllm 版本:  {vllm.__version__}')

import torch
assert '+cu128' in torch.__version__, f'❌ torch 不是 cu128: {torch.__version__}'
print(f'  torch:      {torch.__version__}')
print(f'  GPU:        {torch.cuda.get_device_name(0)}')

x = torch.zeros(10).cuda()
assert (x+1).sum().item() == 10.0
print(f'  GPU 计算:   ✅ OK')

import vllm._C
print(f'  vllm._C:    ✅ OK')
" || { err "环境验证失败"; exit 1; }

# ============================================================================
# Step 6: 装其他依赖
# ============================================================================

log "Step 6: 装其他项目依赖"
pip install --timeout=600 \
    -i https://pypi.tuna.tsinghua.edu.cn/simple \
    "modelscope" "tqdm" "scikit-learn" \
    "sentence-transformers" 2>&1 | tail -3 || warn "部分包失败（非致命）"

# ============================================================================
# 完成
# ============================================================================

echo
ok "════════════════════════════════════════════════════════"
ok "  ✅ 安装完成！下一步："
ok ""
ok "  export MNER_DATA_ROOT=/root/autodl-tmp/MedNER_Project/new_data"
ok "  export MNER_MODEL_ROOT=/root/autodl-tmp/MedNER_Project/models"
ok ""
ok "  python run_pipeline.py --dataset imcs --split dev"
ok "════════════════════════════════════════════════════════"
