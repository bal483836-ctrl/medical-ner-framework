"""
全局配置 - v21（修订版）

🔧 此版本适配 Qwen2.5-7B-Instruct-AWQ 作副模型（稳妥备选）
   （Qwen/Qwen2.5-7B-Instruct-AWQ）

变化（相对原 v21）：
  - SECONDARY_QUANTIZATION 改为 "compressed-tensors"
  - 路径名保持不变（你下载时仍然存到 DeepSeek-R1-Distill-Qwen-14B-AWQ 目录即可）
"""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ==================== 数据集根路径 ====================

DATA_ROOT = os.environ.get("MNER_DATA_ROOT",
                           "/root/autodl-tmp/MedNER_Project/new_data")

# CMeEE_V2
CMEEE_TRAIN_PATH = os.path.join(DATA_ROOT, "CMeEE_V2", "CMeEE_V2_train_new.json")
CMEEE_DEV_PATH   = os.path.join(DATA_ROOT, "CMeEE_V2", "CMeEE_V2_dev_new.json")
CMEEE_TEST_PATH  = os.path.join(DATA_ROOT, "CMeEE_V2", "CMeEE_V2_test_new.json")

# IMCS_V2
IMCS_TRAIN_PATH  = os.path.join(DATA_ROOT, "IMCS_V2", "IMCS_V2_train_new.json")
IMCS_DEV_PATH    = os.path.join(DATA_ROOT, "IMCS_V2", "IMCS_V2_dev_new.json")
IMCS_TEST_PATH   = os.path.join(DATA_ROOT, "IMCS_V2", "IMCS_V2_test_new.json")

# Yidu
YIDU_TRAIN_PATH  = os.path.join(DATA_ROOT, "yidu", "new_yidu_4k_train.json")
YIDU_DEV_PATH    = os.path.join(DATA_ROOT, "yidu", "new_yidu_4k_dev.json")
YIDU_TEST_PATH   = os.path.join(DATA_ROOT, "yidu", "new_yidu_4k_test.json")


# ==================== 模型路径（v21 双 LLM，修订版）====================

MODEL_ROOT = os.environ.get("MNER_MODEL_ROOT",
                            "/root/autodl-tmp/MedNER_Project/models")

# 主模型：Qwen3-32B-AWQ（医学知识强，做主抽取）
PRIMARY_MODEL_PATH = os.environ.get(
    "MNER_PRIMARY_MODEL",
    os.path.join(MODEL_ROOT, "Qwen3-32B-AWQ"),
)
PRIMARY_QUANTIZATION = "awq_marlin"      # vLLM 上 5090 最快
PRIMARY_GPU_UTIL     = 0.62              # 约 20GB

# 副模型：Qwen2.5-7B-Instruct-AWQ（稳妥备选）
SECONDARY_MODEL_PATH = os.environ.get(
    "MNER_SECONDARY_MODEL",
    os.path.join(MODEL_ROOT, "Qwen2.5-7B-Instruct-AWQ"),
)
SECONDARY_QUANTIZATION = "awq_marlin"
SECONDARY_GPU_UTIL     = 0.20            # 约 5GB
# 注：Qwen2.5 不输出 <thinking> 标签，但代码 parse_deepseek_answer 已兼容此情况

# 兼容老代码
LLM_MODEL_PATH = PRIMARY_MODEL_PATH

MODEL_MACBERT_PATH   = os.path.join(MODEL_ROOT, "macbert")
EMBEDDING_MODEL_PATH = os.path.join(MODEL_ROOT, "bge-large-zh-v1.5")
EMBEDDING_BATCH_SIZE = 32
EMBEDDING_DIM        = 1024


# ==================== 输出 / 词典目录 ====================

OUTPUT_DIR = os.environ.get("MNER_OUTPUT_DIR",
                            os.path.join(BASE_DIR, "outputs"))
DICT_DIR   = os.path.join(BASE_DIR, "data", "dicts")


# ==================== 词典文件 ====================

IMCS_ORAL_TO_NORM_PATH = os.path.join(DICT_DIR, "imcs_oral_to_norm.json")
IMCS_SYMPTOM_NORM_PATH = os.path.join(DICT_DIR, "imcs_symptom_norm.json")

IMCS_OFFICIAL_DICT_PATH = os.environ.get(
    "MNER_IMCS_OFFICIAL_DICT",
    os.path.join(DATA_ROOT, "IMCS_V2", "imcs_symptom_dict.json"),
)
ENTITIES_DICT_PATH = os.environ.get(
    "MNER_ENTITIES_DICT",
    os.path.join(DATA_ROOT, "..", "data", "entities_dict.txt"),
)


# ==================== 文件前缀（中间产物） ====================

STEP1_PREFIX = "step1_raw_"
STEP2_PREFIX = "step2_aligned_"
STEP3_PREFIX = "step3_final_"
STEP4_PREFIX = "step4_normalized_"


# ==================== 评估配置 ====================

DUAL_F1_EVAL = True
F1_TARGET    = 0.80


# ==================== 相似度阈值 ====================

EXACT_MATCH_THRESHOLD = 1.0
HIGH_SIM_THRESHOLD    = 0.82
LOW_SIM_THRESHOLD     = 0.60


# ==================== LLM 参数 ====================

LLM_MAX_NEW_TOKENS    = 512
LLM_TEMPERATURE       = 0.1
LLM_TOP_P             = 0.9
LLM_REPETITION_PENALTY = 1.05
LLM_USE_4BIT          = True
LLM_USE_FLASH_ATTN    = False
LLM_DEVICE_MAP        = "auto"
LLM_MAX_MODEL_LEN     = 8192

REFLECTION_MAX_NEW_TOKENS = 2048


# ==================== 少样本 / 预学习配置 ====================

LEARN_SAMPLE_RATIO = 0.05
LEARN_SAMPLE_MAX   = 100
FEW_SHOT_COUNT     = 5
SKILL_REF_COUNT    = 5
FEW_SHOT_SEED      = 42


# ==================== CMeEE ====================

CMEEE_TYPE_MAP = {
    "dis": "疾病",      "sym": "症状",      "pro": "手术操作",
    "equ": "医疗设备",  "dru": "药物",      "ite": "检查项目",
    "bod": "身体部位",  "mic": "微生物类",  "dep": "科室与部门"
}
CMEEE_TARGET_TYPES = list(CMEEE_TYPE_MAP.keys())


# ==================== IMCS ====================

IMCS_TARGET_SYMPTOM_TYPES = ["1", "2"]


# ==================== Yidu ====================

YIDU_TYPE_MAP = {
    "Disease and Diagnosis": "疾病和诊断",
    "Imaging":               "影像检查",
    "Laboratory":            "实验室检验",
    "Medicine":              "药物",
    "Anatomy":               "解剖部位",
    "Operation":             "手术"
}


# ==================== 医学知识（来源可追溯）====================

FEVER_GRADE = {
    "low":    (37.3, 38.0, "低热"),
    "medium": (38.1, 39.0, "中等度热"),
    "high":   (39.1, 41.0, "高热"),
}


# ==================== 数据集映射表（兼容） ====================

ALL_SPLITS = [
    ("cmeee", "train", CMEEE_TRAIN_PATH, True),
    ("cmeee", "dev",   CMEEE_DEV_PATH,   True),
    ("cmeee", "test",  CMEEE_TEST_PATH,  True),
    ("imcs",  "train", IMCS_TRAIN_PATH,  True),
    ("imcs",  "dev",   IMCS_DEV_PATH,    True),
    ("imcs",  "test",  IMCS_TEST_PATH,   True),
    ("yidu",  "train", YIDU_TRAIN_PATH,  False),
    ("yidu",  "dev",   YIDU_DEV_PATH,    False),
    ("yidu",  "test",  YIDU_TEST_PATH,   False),
]
