# 医疗 NER v21 FINAL (5090 + cu128 实测验证版)

**专为 RTX 5090 (Blackwell sm_120) 优化，顺序加载双 LLM，单次跑通。**

## 🎯 核心改进（vs 之前版本）

| 改动 | 说明 |
|---|---|
| ⭐ **顺序加载策略** | 主模型跑完抽取 → 自动释放显存 → 加载副模型反思。**避免双模型同时占用 32GB** |
| ⭐ **真正可用的 vllm 版本** | vllm 0.19 + torch 2.10+cu128（实测验证），不是死锁的 0.10.1.1 |
| ⭐ **绕过 torch 2.10 inductor bug** | install.sh 自动禁用有 bug 的 `mm_scaled_grouped.py` + 强制 `enforce_eager=True` |
| ⭐ **断点续传完整** | extract / reflect / norm 三级断点 |
| ⭐ **纯 vLLM 路径** | 无 transformers fallback，性能最优 |

---

## 🚀 4 步部署

### 1. 解压

```bash
cd /root/autodl-tmp/MedNER_Project/better/
unzip medical_ner_v21_FINAL.zip
cd medical_ner_v21_FINAL
```

### 2. 一键装环境

```bash
bash install.sh
```

约 10-20 分钟。期望最后看到：

```
  vllm 路径:  /root/miniconda3/lib/python3.12/site-packages/vllm/__init__.py
  vllm 版本:  0.19.x
  torch:      2.10.x+cu128
  GPU:        NVIDIA GeForce RTX 5090
  GPU 计算:   ✅ OK
  vllm._C:    ✅ OK

  ✅ 安装完成！
```

### 3. 设环境变量

```bash
export MNER_DATA_ROOT=/root/autodl-tmp/MedNER_Project/new_data
export MNER_MODEL_ROOT=/root/autodl-tmp/MedNER_Project/models
```

### 4. 跑

```bash
python run_pipeline.py --dataset imcs --split dev
```

崩了？**直接重跑同一条命令，断点自动续传**。

---

## 🔄 顺序加载工作流程

```
┌─ Step 1: 加载主模型 (Qwen3-32B-AWQ, ~18GB) ─┐
│                                                │
│  独占 5090 显存：~28GB（含 KV cache）          │
│  跑完 1097 个 chunks 的抽取                    │
│                                                │
└────────────────────────────────────────────────┘
                  │
                  ▼
┌─ Step 2: 自动释放主模型 ─┐
│   🗑️  释放主模型显存...   │
│   GPU 显存 → ~1GB         │
└──────────────────────────┘
                  │
                  ▼
┌─ Step 3: 加载副模型 (DeepSeek-R1-Distill-14B, ~9GB) ─┐
│                                                       │
│  独占 5090 显存：~22GB（含 KV cache）                 │
│  跑完 1097 个 chunks 的反思                           │
│                                                       │
└───────────────────────────────────────────────────────┘
                  │
                  ▼
       归一化 + 双评估
```

---

## 📊 期望性能

| 数据集 | F1 (估算) |
|---|---|
| CMeEE 字符串 | **0.72~0.80** |
| IMCS 归一化 | **0.75~0.82** |

---

## 🛠️ 常用命令

```bash
# 标准跑
python run_pipeline.py --dataset imcs --split dev
python run_pipeline.py --dataset cmeee --split dev
python run_pipeline.py --dataset all --split dev

# 跳过反思（更快，但 F1 降 5-10%）
python run_pipeline.py --dataset imcs --split dev --no-reflection

# 跳过 LLM 归一化兜底（更快）
python run_pipeline.py --dataset imcs --split dev --no-llm-fallback

# 仅评估（不重跑 LLM）
python run_pipeline.py --dataset imcs --split dev --eval-only

# 自定义输入
python run_pipeline.py --input /any/path.json --train /any/train.json
```

---

## 🆘 故障排查

### 1. `install.sh` 验证失败

看具体错误：

| 错误关键词 | 原因 | 解决 |
|---|---|---|
| `libcudart.so.13` | pip 拉了 cu13 版本 | 重跑 `install.sh`，检查 `--index-url` 是 pytorch |
| `duplicate template name` | torch 2.10 inductor bug | install.sh 已自动 patch；如果还报错，确认 `mm_scaled_grouped.py.disabled` 存在 |
| `undefined symbol` | torch / vllm ABI 不兼容 | 重跑 install.sh |
| `No matching distribution` | 版本号不存在 | 改 vllm 范围（详见下） |

### 2. 跑流水线时 OOM

编辑 `config/config.py` 调小：

```python
PRIMARY_GPU_UTIL = 0.85   # 默认 0.92
SECONDARY_GPU_UTIL = 0.85
LLM_MAX_MODEL_LEN = 4096  # 默认 8192
```

### 3. `import vllm` 报 `No module named 'vllm'`

```bash
# 检查 site-packages
pip list | grep vllm

# 没有？重跑
bash install.sh
```

### 4. 磁盘满

```bash
df -h /
pip cache purge
conda clean --all -y
```

---

## 📁 文件结构

```
medical_ner_v21_FINAL/
├── install.sh                    ⭐ 一键安装（5090 + cu128 实测验证）
├── download_models.sh
├── check_env.py
├── run_pipeline.py
├── README.md
├── requirements.txt
├── config/
│   └── config.py                 ⭐ GPU_UTIL=0.92（顺序加载，独占显存）
├── src/
│   ├── llm_client.py             ⭐ 顺序加载客户端（主→副自动切换）
│   ├── unified_extractor.py      ⭐ 三级断点续传
│   ├── unified_normalize_eval.py
│   ├── unified_prompt.py
│   ├── dataset_detector.py
│   └── ...
├── data/dicts/
└── outputs/
```

---

## 一句话

```bash
bash install.sh && \
export MNER_DATA_ROOT=/root/autodl-tmp/MedNER_Project/new_data && \
export MNER_MODEL_ROOT=/root/autodl-tmp/MedNER_Project/models && \
python run_pipeline.py --dataset imcs --split dev
```
