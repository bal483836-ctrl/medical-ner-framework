from src.unified_normalize_eval import compute_set_f1, _rule_based_normalize
from src.kg_alignment import get_oral_to_standard_map, build_imcs_norm_vocab


def test_macro_empty_chunks():
    result = compute_set_f1([set(), {"腹泻"}], [set(), {"腹泻"}])
    assert result["micro_f1"] == 1.0, result
    assert result["macro_f1"] == 1.0, result
    assert result["macro_f1_nonempty"] == 1.0, result
    assert result["n_true_empty"] == 1, result


def test_raw_to_norm_rule():
    oral = get_oral_to_standard_map()
    vocab = set(build_imcs_norm_vocab())
    assert _rule_based_normalize("拉肚子", oral, {}, vocab)["normed"] == "腹泻"
    assert _rule_based_normalize("38.5度", oral, {}, vocab)["normed"] == "中等度热"
    assert _rule_based_normalize("39.5度", oral, {}, vocab)["normed"] == "高热"


if __name__ == "__main__":
    test_macro_empty_chunks()
    test_raw_to_norm_rule()
    print("smoke tests passed")
