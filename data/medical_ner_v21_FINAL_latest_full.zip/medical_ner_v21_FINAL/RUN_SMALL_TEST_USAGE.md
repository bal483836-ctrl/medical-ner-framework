# 小样本测试脚本使用说明

我已在项目根目录新增 `run_small_test.py`。这个脚本用于快速跑通当前 NER 流水线，只处理 **500 条 CMeEE** 和 **100 条 IMCS**，并把每个阶段的产物集中输出到一个独立目录中。

## 一、默认运行

在项目根目录执行：

```bash
python3.11 run_small_test.py
```

脚本默认会读取 `config/config.py` 中的路径：

| 数据集 | 默认测试输入 | 默认预学习输入 | 测试条数 |
|---|---|---|---:|
| CMeEE | `CMEEE_DEV_PATH` | `CMEEE_TRAIN_PATH` | 500 |
| IMCS | `IMCS_DEV_PATH` | `IMCS_TRAIN_PATH` | 100 |

输出目录默认为：

```text
outputs/small_test_YYYYMMDD_HHMMSS/
```

## 二、加速运行

如果只是先确认数据加载、主抽取和评估链路，可以跳过反思和 LLM 归一化兜底：

```bash
python3.11 run_small_test.py --no-reflection --no-llm-fallback
```

如果只想单独跑一个数据集，可以使用：

```bash
python3.11 run_small_test.py --only cmeee
python3.11 run_small_test.py --only imcs
```

## 三、指定数据路径

如果你的数据不在 `config/config.py` 默认路径下，可以显式指定：

```bash
python3.11 run_small_test.py \
  --cmeee-input /path/to/CMeEE_V2_dev_new.json \
  --imcs-input /path/to/IMCS_V2_dev_new.json \
  --cmeee-train /path/to/CMeEE_V2_train_new.json \
  --imcs-train /path/to/IMCS_V2_train_new.json
```

也可以用环境变量指定数据根目录：

```bash
export MNER_DATA_ROOT=/root/autodl-tmp/MedNER_Project/new_data
python3.11 run_small_test.py
```

## 四、每个阶段会输出什么

运行完成后，输出目录下会包含以下文件或目录：

| 产物 | 说明 |
|---|---|
| `samples/cmeee_dev_500.json` | CMeEE 小样本测试输入 |
| `samples/imcs_dev_100.json` | IMCS 小样本测试输入 |
| `samples/*_train_100.json` | 每个数据集用于 Step 0 预学习的小样本 train 文件 |
| `knowledge_*.json` | Step 0 预学习知识包，开启 `dump_knowledge=True` 自动导出 |
| `smalltest_*_step1_*.json` | Step 1/2/3 的抽取、反思、过滤后结果 |
| `smalltest_*_step5_*.json` | Step 5 的 IMCS 归一化结果；CMeEE 会保持等价结果 |
| `cmeee_result_summary.json` | CMeEE 单数据集指标和产物路径汇总 |
| `imcs_result_summary.json` | IMCS 单数据集指标和产物路径汇总 |
| `small_test_manifest.json` | 本次小测完整机器可读清单 |
| `small_test_report.md` | 本次小测 Markdown 报告，包含阶段产物表和 F1 指标表 |

## 五、常用参数

| 参数 | 默认值 | 作用 |
|---|---:|---|
| `--cmeee-limit` | 500 | CMeEE 测试条数 |
| `--imcs-limit` | 100 | IMCS 测试条数 |
| `--train-limit` | 100 | 每个数据集用于预学习的 train 截断条数，设为 `0` 跳过预学习 |
| `--output-dir` | 自动时间戳目录 | 指定本次测试输出目录 |
| `--batch-size` | 16 | vLLM 批处理大小 |
| `--no-reflection` | 关闭项 | 跳过 Step 2 反思 |
| `--no-llm-fallback` | 关闭项 | 跳过 IMCS LLM 归一化兜底 |
| `--only` | `all` | 可选 `all`、`cmeee`、`imcs` |

## 六、注意事项

这个脚本仍然调用原项目的真实模型推理流程，所以需要你的服务器上存在 `config/config.py` 或环境变量指定的本地模型路径。如果只是运行 `--help` 或语法检查，则不需要模型。

语法检查命令如下：

```bash
python3.11 -m py_compile run_small_test.py
python3.11 run_small_test.py --help
```

## 七、如果报 `ModuleNotFoundError: No module named 'config'`

这个错误通常表示你**只复制了 `run_small_test.py`，但没有在完整项目根目录运行**。完整项目根目录必须同时包含以下三个路径：

| 必需路径 | 作用 |
|---|---|
| `config/config.py` | 数据路径、模型路径和输出路径配置 |
| `run_pipeline.py` | 主流水线入口 |
| `src/dataset_detector.py` | 数据集适配与样本构造 |

新版脚本已经支持自动查找项目根目录，也支持显式指定项目根目录。你可以按下面方式执行：

```bash
cd /root/autodl-tmp/MedNER_Project/better
python3 run_small_test.py --project-dir /root/autodl-tmp/MedNER_Project/better
```

如果 `better` 目录只是放脚本的临时目录，而完整项目实际在上一层或其他目录，则把 `--project-dir` 改成真实完整项目目录，例如：

```bash
python3 /root/autodl-tmp/MedNER_Project/better/run_small_test.py \
  --project-dir /root/autodl-tmp/MedNER_Project/medical_ner_v21_FINAL
```

你也可以先检查当前目录是否完整：

```bash
ls config/config.py run_pipeline.py src/dataset_detector.py
```

如果这条命令有任何一个文件不存在，就说明当前目录不是完整项目根目录，需要复制完整项目或使用 `--project-dir` 指向完整项目。

## 八、如果 IMCS 阶段报 `json.decoder.JSONDecodeError: Extra data`

这个错误通常出现在 IMCS 的训练集或开发集不是标准 JSON 数组/标准 JSONL，而是带有前缀、制表符、连续 JSON 对象或混杂字符。旧版小样本脚本的 `_load_json()` 只兼容标准 JSON 和简单 JSONL，因此在生成 IMCS train 小样本时可能失败。

新版 `run_small_test.py` 已经增强数据加载器，兼容以下情况：标准 JSON 数组、单对象 JSON、JSONL、每行带 id 或 tab 前缀的 JSON、连续 JSON 对象，以及带少量文件头噪声的数据。你只需要把新版脚本覆盖到完整项目根目录后重新执行：

```bash
cd /root/autodl-tmp/MedNER_Project/better/medical_ner_v21_FINAL
python3 run_small_test.py --no-reflection --no-llm-fallback
```

如果你希望重新跑带反思的完整小样本测试，则执行：

```bash
python3 run_small_test.py
```

从你贴出的日志看，CMeEE 500 条已经完成并输出了阶段产物，失败发生在准备 IMCS train 小样本时。因此替换新版脚本后，不需要改模型配置，直接重跑即可。

## 九、参考 v20_4 数据格式后的兼容策略

本次更新不替换当前 v21 项目的模型调用、抽取、归一化和评估主逻辑。`run_small_test.py` 只在“小样本切片读取原始数据”这一步参考了 `medical_ner_v20_4` 的数据兼容策略：优先复用当前项目 `src.data_processor._load_json`，如果当前项目加载器未解析出记录或遇到异常，再使用脚本内置的增强兜底解析。

这样做的目的，是兼容服务器上可能存在的多种数据文件形态，包括标准 JSON 数组、JSONL、带少量前缀的 JSONL、带 BOM/控制字符的 JSON 文件，以及连续 JSON 对象。小样本文件生成之后，后续仍然交给当前 v21 的 `run_pipeline()` 执行，因此**逻辑和模型保持当前项目本身不变**。

如果你只想检查 IMCS 数据格式是否已经能切片，可以先运行：

```bash
python3 run_small_test.py --only imcs --no-reflection --no-llm-fallback
```

如果你想完整跑 500 条 CMeEE 和 100 条 IMCS，则运行：

```bash
python3 run_small_test.py
```
