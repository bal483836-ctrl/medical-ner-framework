"""
统一医疗 NER 流水线 - v21

设计原则（按用户决策）：
  1. 前 4 步不区分数据集：统一接口，内部自动按字段格式判断
  2. 预学习保留学习能力，自动识别字段
  3. 评估指标统一为字符串集合 F1
  4. 推理框架使用 vLLM
  5. 双 LLM 协作：Qwen3-32B-AWQ（主抽取）+ DeepSeek-R1-Distill-14B-AWQ（反思+归一化兜底）

流水线（6 步）：
  Step 0: 预学习（自动识别数据集，调对应 learner）
  Step 1: 统一主抽取（Qwen3-32B 批处理）
  Step 2: 反思（DeepSeek-14B CoT）
  Step 3: 规则过滤（边界修剪 + 类型校正）
  Step 4: 评估 ①（字符串集合 F1，原始抽取）
  Step 5: IMCS 归一化（仅当数据集有 norm 字段；含 LLM 兜底）
  Step 6: 评估 ②（字符串集合 F1，归一化后；非 IMCS 等价于评估 ①）

用法：
  # 自动检测数据集类型并运行
  python run_pipeline.py --input /path/to/any_dataset.json
  
  # 老的子集模式仍支持（自动调用对应文件）
  python run_pipeline.py --dataset cmeee --split dev
  python run_pipeline.py --dataset imcs --split dev
  
  # 跳过反思（仅主抽取）
  python run_pipeline.py --dataset cmeee --split dev --no-reflection
  
  # 跳过 LLM 归一化兜底
  python run_pipeline.py --dataset imcs --split dev --no-llm-fallback
"""
import argparse
import json
import os
import sys
import time
from typing import List, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.config import (
    OUTPUT_DIR, LEARN_SAMPLE_RATIO, LEARN_SAMPLE_MAX, FEW_SHOT_SEED,
    CMEEE_TRAIN_PATH, CMEEE_DEV_PATH, CMEEE_TEST_PATH,
    IMCS_TRAIN_PATH, IMCS_DEV_PATH, IMCS_TEST_PATH,
    YIDU_TRAIN_PATH, YIDU_DEV_PATH, YIDU_TEST_PATH,
)
from src.dataset_detector import (
    detect_dataset_type, build_data_item, DataItem, to_legacy_format,
    DATASET_CMEEE, DATASET_IMCS, DATASET_YIDU, DATASET_UNKNOWN,
)
from src.few_shot_learner import FewShotLearner, LearnedKnowledge
from src.unified_extractor import UnifiedExtractor
from src.unified_normalize_eval import (
    evaluate_raw_extraction, normalize_extraction_results, evaluate_normalized,
)
from src.data_processor import _load_json


# ==================== 数据加载 ====================

def load_dataset_file(path: str) -> List[dict]:
    """加载任意 JSON 数据集（自动兼容 JSON / JSONL）"""
    return _load_json(path)


def resolve_path(dataset: str, split: str) -> str:
    """老接口：dataset+split → file path"""
    table = {
        ("cmeee", "train"): CMEEE_TRAIN_PATH,
        ("cmeee", "dev"):   CMEEE_DEV_PATH,
        ("cmeee", "test"):  CMEEE_TEST_PATH,
        ("imcs",  "train"): IMCS_TRAIN_PATH,
        ("imcs",  "dev"):   IMCS_DEV_PATH,
        ("imcs",  "test"):  IMCS_TEST_PATH,
        ("yidu",  "train"): YIDU_TRAIN_PATH,
        ("yidu",  "dev"):   YIDU_DEV_PATH,
        ("yidu",  "test"):  YIDU_TEST_PATH,
    }
    if (dataset, split) not in table:
        raise ValueError(f"未知 dataset+split 组合: {dataset}/{split}")
    return table[(dataset, split)]


def select_learn_samples(train_data: list, ratio: float = LEARN_SAMPLE_RATIO,
                         max_n: int = LEARN_SAMPLE_MAX,
                         seed: int = FEW_SHOT_SEED) -> list:
    import random
    n = max(10, min(int(len(train_data) * ratio), max_n))
    rnd = random.Random(seed)
    return rnd.sample(train_data, min(n, len(train_data)))


# ==================== Step 3: 规则过滤（轻量） ====================

def _apply_simple_filters(extraction_results: List[dict],
                          dataset_type: str) -> List[dict]:
    """v21 简化版过滤：
      - 去掉空 / 纯标点 / 纯数字实体
      - 去重（同 chunk 内同 (entity, type) 只保留一个）
      - 不做激进类型校正（避免引入 v20.7 的 FP 问题）
    """
    UNIVERSAL_NOISE = {"无", "none", "None", "NULL", "null", "无实体",
                       "无症状", "暂无", "不详", ""}
    GENERIC_NOISE = {"疾病", "病人", "患者", "症状", "病例", "情况",
                     "结果", "方法", "过程", "原因", "效果", "作用"}

    import re as _re

    for item_result in extraction_results:
        for ch in item_result.get("chunks", []):
            cleaned = []
            seen = set()
            for e in ch.get("reflected_entities", []):
                name = e.get("entity", "").strip()
                etype = e.get("type", "")
                if not name or name in UNIVERSAL_NOISE:
                    continue
                if name in GENERIC_NOISE:
                    continue
                if _re.match(r'^[\d\s\W]+$', name):
                    continue
                # 去尾部助词
                name = _re.sub(r'[的等了吗啊呢吧呀嘛、，。；：!?\"]+$', '', name)
                name = name.strip()
                if not name:
                    continue
                key = (name, etype)
                if key in seen:
                    continue
                seen.add(key)
                cleaned.append({"entity": name, "type": etype})
            ch["reflected_entities"] = cleaned

        # 重算 pred 字符串
        pred = set()
        for ch in item_result.get("chunks", []):
            for e in ch.get("reflected_entities", []):
                pred.add(e["entity"])
        item_result["step1_pred_str"] = ",".join(sorted(pred))

    return extraction_results


# ==================== 主流水线 ====================

def run_pipeline(input_path: str,
                 train_path: Optional[str] = None,
                 output_prefix: str = "unified",
                 use_reflection: bool = True,
                 use_llm_fallback: bool = True,
                 use_batch: bool = True,
                 batch_size: int = 16,
                 eval_only: bool = False,
                 dump_knowledge: bool = False) -> dict:
    """统一流水线主入口

    Args:
        input_path: 待处理的数据集文件路径
        train_path: train 集路径（用于预学习）。None 时跳过预学习
        output_prefix: 输出文件前缀
        use_reflection: 是否启用副模型反思
        use_llm_fallback: 是否启用 LLM 归一化兜底
        use_batch: 是否启用 vLLM 批处理
        batch_size: 批大小
        eval_only: 仅评估已有结果（不重跑 LLM）
        dump_knowledge: 是否导出预学习知识（论文用）

    Returns:
        {"raw_eval": {...}, "normalized_eval": {...}}
    """
    t0 = time.time()
    print("\n" + "=" * 70)
    print(f"  统一医疗 NER 流水线 v21 · 输入: {input_path}")
    print("=" * 70)

    # ---------- 加载数据 ----------
    raw_data = load_dataset_file(input_path)
    if not raw_data:
        print(f"❌ 数据加载失败或为空: {input_path}")
        return {}

    dataset_type = detect_dataset_type(raw_data)
    print(f"  📊 数据集类型自动检测: {dataset_type} | 样本数: {len(raw_data)}")

    items: List[DataItem] = [
        build_data_item(raw, dataset_type, i)
        for i, raw in enumerate(raw_data)
    ]

    # ---------- 输出路径 ----------
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    fname = os.path.basename(input_path).replace(".json", "")
    step1_path = os.path.join(OUTPUT_DIR, f"{output_prefix}_step1_{fname}.json")
    step5_path = os.path.join(OUTPUT_DIR, f"{output_prefix}_step5_{fname}.json")

    # ---------- Step 0: 预学习 ----------
    knowledge = None
    if train_path and os.path.exists(train_path):
        train_data = load_dataset_file(train_path)
        if train_data:
            train_ds_type = detect_dataset_type(train_data)
            if train_ds_type != dataset_type:
                print(f"  ⚠️ train 与 test 数据集类型不一致 "
                      f"({train_ds_type} vs {dataset_type}), 仍尝试预学习")
            learn_samples = select_learn_samples(train_data)
            print(f"\n[Step 0] 预学习 | 学习样本: {len(learn_samples)} "
                  f"(来自 train, 占 {len(learn_samples)/len(train_data):.1%})")

            learner = FewShotLearner()
            ds_name_for_learner = (
                "cmeee" if dataset_type == DATASET_CMEEE
                else ("imcs" if dataset_type == DATASET_IMCS
                      else dataset_type)
            )
            # IMCS 用全集对齐口语 → 标准词
            full_alignment = train_data if dataset_type == DATASET_IMCS else None
            try:
                knowledge = learner.learn(
                    learn_samples=learn_samples,
                    dataset_name=ds_name_for_learner,
                    n_skill_refs=5,
                    full_alignment_samples=full_alignment,
                    call_llm_func=None,    # v21: 不在预学习里调 LLM（避免初始化延迟）
                    skill_cache_dir=os.path.join(OUTPUT_DIR, "knowledge"),
                    force_regenerate_skills=False,
                )
                print(f"\n--- 预学习摘要 ---")
                if hasattr(knowledge, "style_constraints"):
                    print(knowledge.style_constraints[:600])
                if dump_knowledge:
                    kp = os.path.join(OUTPUT_DIR, f"knowledge_{fname}.json")
                    knowledge.save(kp)
                    print(f"\n  💾 知识包已导出: {kp}")
            except Exception as e:
                print(f"  ⚠️ 预学习失败 ({e})，继续无 knowledge 模式")
                knowledge = None
    else:
        print(f"\n[Step 0] 跳过预学习（无 train 数据）")

    # ---------- Step 1+2: 统一抽取 + 反思 ----------
    if eval_only and os.path.exists(step1_path):
        print(f"\n[Step 1-2] eval-only 模式，加载已有结果: {step1_path}")
        with open(step1_path, "r", encoding="utf-8") as f:
            extraction_results = json.load(f)
    else:
        print(f"\n[Step 1-2] 统一抽取 + 反思")
        extractor = UnifiedExtractor(
            knowledge=knowledge,
            use_reflection=use_reflection,
            use_batch=use_batch,
            batch_size=batch_size,
        )
        extraction_results = extractor.extract(items, output_path=step1_path)

    # ---------- Step 3: 规则过滤 ----------
    print(f"\n[Step 3] 规则过滤")
    extraction_results = _apply_simple_filters(extraction_results, dataset_type)
    # 重新保存
    with open(step1_path, "w", encoding="utf-8") as f:
        json.dump(extraction_results, f, ensure_ascii=False, indent=2)

    # ---------- Step 4: 评估 1（原始抽取） ----------
    print(f"\n[Step 4] 评估 ① — 原始抽取（字符串集合 F1）")
    raw_eval = evaluate_raw_extraction(items, extraction_results,
                                        name=f"评估 ① 原始抽取 [{dataset_type}]")

    # ---------- Step 5: 归一化 ----------
    print(f"\n[Step 5] IMCS 归一化（如适用）")
    extraction_results = normalize_extraction_results(
        items, extraction_results,
        knowledge=knowledge,
        use_llm_fallback=use_llm_fallback,
        output_path=step5_path,
    )

    # ---------- Step 6: 评估 2（归一化后） ----------
    print(f"\n[Step 6] 评估 ② — 归一化后（字符串集合 F1）")
    norm_eval = evaluate_normalized(items, extraction_results,
                                     name=f"评估 ② 归一化后 [{dataset_type}]")

    # ---------- 汇总 ----------
    print(f"\n" + "=" * 70)
    print(f"  流水线总耗时: {time.time() - t0:.1f}s")
    print(f"  评估 ① F1: {raw_eval['micro_f1']:.4f}")
    print(f"  评估 ② F1: {norm_eval['micro_f1']:.4f}")
    print("=" * 70)

    return {
        "dataset_type": dataset_type,
        "n_items":      len(items),
        "raw_eval":     raw_eval,
        "normalized_eval": norm_eval,
        "step1_path":   step1_path,
        "step5_path":   step5_path,
    }


# ==================== CLI ====================

def main():
    parser = argparse.ArgumentParser(description="医疗 NER 统一流水线 v21")
    parser.add_argument("--input", type=str, default=None,
                        help="直接指定输入文件路径")
    parser.add_argument("--train", type=str, default=None,
                        help="train 集路径（预学习用）；不指定时自动匹配 --dataset")
    parser.add_argument("--dataset", choices=["cmeee", "imcs", "yidu", "all"],
                        default=None, help="兼容老接口")
    parser.add_argument("--split", choices=["train", "dev", "test"],
                        default="dev")
    parser.add_argument("--no-reflection", action="store_true",
                        help="跳过反思（仅主抽取）")
    parser.add_argument("--no-llm-fallback", action="store_true",
                        help="跳过 LLM 归一化兜底")
    parser.add_argument("--no-batch", action="store_true",
                        help="禁用 vLLM 批处理")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--eval-only", action="store_true",
                        help="仅评估已有结果")
    parser.add_argument("--dump-knowledge", action="store_true",
                        help="导出预学习知识包")
    parser.add_argument("--output-prefix", type=str, default="unified")
    args = parser.parse_args()

    # ---------- 输入决议 ----------
    if args.input:
        # 直接指定文件
        input_paths = [args.input]
        # 自动猜 train 路径：同目录下 *_train_*.json
        train_paths = [None]
        if not args.train:
            import glob
            dirname = os.path.dirname(args.input)
            candidates = glob.glob(os.path.join(dirname, "*train*.json"))
            if candidates:
                train_paths = [candidates[0]]
                print(f"  📁 自动匹配 train 文件: {candidates[0]}")
        else:
            train_paths = [args.train]
    elif args.dataset:
        # 老接口模式
        datasets = (["cmeee", "imcs", "yidu"]
                    if args.dataset == "all" else [args.dataset])
        input_paths = [resolve_path(ds, args.split) for ds in datasets]
        train_paths = [resolve_path(ds, "train") for ds in datasets]
    else:
        parser.error("必须指定 --input 或 --dataset")
        return

    results_summary = []
    for inp, tr in zip(input_paths, train_paths):
        if not os.path.exists(inp):
            print(f"\n⚠️ 跳过不存在的文件: {inp}")
            continue
        res = run_pipeline(
            input_path=inp,
            train_path=tr,
            output_prefix=args.output_prefix,
            use_reflection=not args.no_reflection,
            use_llm_fallback=not args.no_llm_fallback,
            use_batch=not args.no_batch,
            batch_size=args.batch_size,
            eval_only=args.eval_only,
            dump_knowledge=args.dump_knowledge,
        )
        results_summary.append({"input": inp, **res})

    # ---------- 总汇 ----------
    if len(results_summary) > 1:
        print("\n" + "=" * 70)
        print("  所有数据集汇总")
        print("=" * 70)
        for r in results_summary:
            print(f"  [{r.get('dataset_type'):>6}] "
                  f"原始 F1 = {r['raw_eval']['micro_f1']:.4f}, "
                  f"归一化 F1 = {r['normalized_eval']['micro_f1']:.4f}, "
                  f"输入: {os.path.basename(r['input'])}")

    # 保存汇总
    summary_path = os.path.join(OUTPUT_DIR,
                                 f"{args.output_prefix}_summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(results_summary, f, ensure_ascii=False, indent=2,
                  default=str)
    print(f"\n  📊 汇总已保存: {summary_path}")


if __name__ == "__main__":
    main()
