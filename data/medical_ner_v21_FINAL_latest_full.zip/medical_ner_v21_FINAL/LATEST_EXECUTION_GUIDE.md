# 最新版完整项目执行方法

本文档适用于当前交付的最新版 `medical_ner_v21_FINAL` 项目。该版本包含此前的 F1 修复、小样本测试入口 `run_small_test.py`、v20_4 数据格式兼容读取策略，以及对应的使用说明和轻量测试脚本。

## 一、代码包内容

最新版完整代码包是 `medical_ner_v21_FINAL_latest_full.zip`。解压后，项目根目录应至少包含以下关键文件和目录。

| 路径 | 作用 |
|---|---|
| `run_pipeline.py` | 当前项目主流水线入口，负责抽取、归一化、评估等完整流程 |
| `run_small_test.py` | 小样本测试入口，默认只跑 500 条 CMeEE 和 100 条 IMCS |
| `config/config.py` | 数据路径、模型路径、输出路径和运行参数配置 |
| `src/` | 当前项目的核心逻辑，包括数据识别、抽取、归一化和评估 |
| `RUN_SMALL_TEST_USAGE.md` | 小样本测试脚本的详细说明 |
| `F1_FIX_REPORT.md` | F1 低分原因诊断和修复说明 |
| `test_f1_fix_smoke.py` | F1 修复逻辑的轻量回归测试 |
| `test_small_loader_formats.py` | 小样本数据格式兼容性的轻量测试 |

请注意，**最新版代码没有替换你的模型调用和主流程逻辑**。小样本脚本只是在切片读取原始数据时增强了格式兼容能力，后续仍调用当前项目自己的 `run_pipeline()`。

## 二、在服务器上解压

建议把压缩包放到你的服务器项目目录，例如 `/root/autodl-tmp/MedNER_Project/`。

```bash
cd /root/autodl-tmp/MedNER_Project
unzip medical_ner_v21_FINAL_latest_full.zip
cd medical_ner_v21_FINAL
```

解压后先检查项目根目录是否完整。

```bash
ls config/config.py run_pipeline.py src/dataset_detector.py run_small_test.py
```

如果上面命令有任何一个文件不存在，说明当前目录不是完整项目根目录，需要重新进入正确目录或重新解压。

## 三、先做基础语法和轻量测试

进入完整项目根目录后，建议先执行以下命令。

```bash
python3 -m py_compile run_pipeline.py run_small_test.py config/config.py src/*.py
python3 test_f1_fix_smoke.py
python3 test_small_loader_formats.py
python3 run_small_test.py --help
```

这些命令用于确认代码可以加载、F1 修复逻辑正常、数据格式兜底解析正常，以及小样本脚本参数可用。它们不需要完整跑模型推理。

## 四、配置数据和模型路径

项目默认从 `config/config.py` 读取数据路径和模型路径。如果你的服务器数据根目录与配置不一致，可以优先用环境变量覆盖数据根目录。

```bash
export MNER_DATA_ROOT=/root/autodl-tmp/MedNER_Project/new_data
```

你也可以直接编辑配置文件。

```bash
vim config/config.py
```

重点检查以下内容是否指向真实存在的路径。

| 配置项 | 说明 |
|---|---|
| `CMEEE_TRAIN_PATH`、`CMEEE_DEV_PATH` | CMeEE 训练集和开发集路径 |
| `IMCS_TRAIN_PATH`、`IMCS_DEV_PATH` | IMCS 训练集和开发集路径 |
| 模型相关路径 | 你的本地大模型或推理服务路径 |
| `OUTPUT_DIR` | 输出目录；也可通过 `MNER_OUTPUT_DIR` 覆盖 |

## 五、推荐先跑小样本测试

为了快速检查链路，不建议一开始跑全量。建议先运行小样本测试。

### 1. 最快链路检查

这条命令会跳过反思和 IMCS 的 LLM 兜底归一化，用于快速确认数据能否读取、模型能否调用、阶段产物能否落盘。

```bash
python3 run_small_test.py --no-reflection --no-llm-fallback
```

### 2. 只检查 IMCS 数据格式和流程

如果你之前卡在 IMCS `JSONDecodeError: Extra data`，可以先只跑 IMCS。

```bash
python3 run_small_test.py --only imcs --no-reflection --no-llm-fallback
```

### 3. 完整小样本测试

这条命令会按默认规模运行：500 条 CMeEE 和 100 条 IMCS。

```bash
python3 run_small_test.py
```

运行完成后，结果默认输出到：

```text
outputs/small_test_YYYYMMDD_HHMMSS/
```

重点查看以下文件。

| 输出文件 | 说明 |
|---|---|
| `small_test_report.md` | 本次小样本测试的人类可读报告 |
| `small_test_manifest.json` | 本次小样本测试的完整机器可读清单 |
| `cmeee_result_summary.json` | CMeEE 的阶段产物和指标汇总 |
| `imcs_result_summary.json` | IMCS 的阶段产物和指标汇总 |
| `samples/` | 本次实际送入流水线的小样本数据 |

## 六、如果脚本不在项目根目录

如果你把 `run_small_test.py` 单独复制到了别的目录，请使用 `--project-dir` 指向完整项目目录。完整项目目录必须同时包含 `config/config.py`、`run_pipeline.py` 和 `src/dataset_detector.py`。

```bash
python3 /path/to/run_small_test.py \
  --project-dir /root/autodl-tmp/MedNER_Project/medical_ner_v21_FINAL \
  --no-reflection --no-llm-fallback
```

如果不确定完整项目在哪里，可以查找：

```bash
find /root/autodl-tmp -name run_pipeline.py -print
find /root/autodl-tmp -name config.py -path '*/config/config.py' -print
```

## 七、运行主流程

小样本跑通后，可以再使用主流程处理指定输入文件。

```bash
python3 run_pipeline.py --help
```

根据帮助信息传入你的真实输入文件、训练文件和输出前缀。若当前项目支持直接传入 `input_path` 和 `train_path` 参数，则使用方式类似：

```bash
python3 run_pipeline.py \
  --input-path /path/to/dev.json \
  --train-path /path/to/train.json \
  --output-prefix final_run
```

如果你的 `run_pipeline.py --help` 显示的是其他参数名称，请以帮助信息为准。

## 八、常见问题

| 报错或现象 | 处理方法 |
|---|---|
| `ModuleNotFoundError: No module named 'config'` | 当前目录不是完整项目根目录，进入包含 `config/config.py` 的目录运行，或使用 `--project-dir` |
| `python3: can't open file 'run_small_test.py'` | 当前目录没有该脚本，先进入完整项目目录或把新版脚本复制过去 |
| `JSONDecodeError: Extra data` | 使用本最新版 `run_small_test.py`；它已参考 v20_4 的数据格式做兼容读取 |
| CMeEE F1 很低且 precision 高、recall 低 | 说明模型抽取过少，需要继续检查提示词、候选召回或模型输出解析，但这不是脚本启动问题 |
| 找不到数据文件 | 检查 `MNER_DATA_ROOT` 或 `config/config.py` 中的 CMeEE/IMCS 路径 |

## 九、建议执行顺序

建议按以下顺序执行，能最快定位问题。

```bash
cd /root/autodl-tmp/MedNER_Project/medical_ner_v21_FINAL
ls config/config.py run_pipeline.py src/dataset_detector.py run_small_test.py
python3 -m py_compile run_pipeline.py run_small_test.py config/config.py src/*.py
python3 test_f1_fix_smoke.py
python3 test_small_loader_formats.py
python3 run_small_test.py --only imcs --no-reflection --no-llm-fallback
python3 run_small_test.py --no-reflection --no-llm-fallback
python3 run_small_test.py
```

如果最后一步跑得慢，说明已经进入真实模型推理阶段，这是正常现象。
