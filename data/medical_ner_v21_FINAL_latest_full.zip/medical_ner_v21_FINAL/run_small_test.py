#!/usr/bin/env python3
"""
小样本端到端测试脚本：只跑 500 条 CMeEE 和 100 条 IMCS，并输出每个阶段产物。

默认行为：
  - 从 config/config.py 中读取 CMeEE/IMCS 的 dev/train 路径；
  - 分别截取 dev 前 500 条 CMeEE、前 100 条 IMCS 作为测试输入；
  - 可选从 train 截取少量样本用于 Step 0 预学习，避免小测时扫描/学习过多数据；
  - 依次执行 Step 0~Step 6；
  - 在独立输出目录中保存：小样本输入、抽取结果、归一化结果、知识包、汇总 JSON、Markdown 报告。

典型用法：
  python3.11 run_small_test.py

常用加速：
  python3.11 run_small_test.py --no-reflection --no-llm-fallback

指定路径：
  python3.11 run_small_test.py \
    --cmeee-input /path/to/CMeEE_V2_dev_new.json \
    --imcs-input /path/to/IMCS_V2_dev_new.json \
    --cmeee-train /path/to/CMeEE_V2_train_new.json \
    --imcs-train /path/to/IMCS_V2_train_new.json
"""
import argparse
import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# 必须在导入 config/run_pipeline 前设置输出目录环境变量；main() 中会再次写入实际值。
# 注意：脚本可能被单独复制到其他目录，因此这里先记录脚本目录，真正的项目根目录在 main() 中自动发现。
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR
PROJECT_DATA_LOADER = None
sys.path.insert(0, str(SCRIPT_DIR))


def _looks_like_project_root(path: Path) -> bool:
    """判断目录是否像 medical_ner_v21_FINAL 项目根目录。"""
    return (
        (path / "config" / "config.py").exists()
        and (path / "run_pipeline.py").exists()
        and (path / "src" / "dataset_detector.py").exists()
    )


def _find_project_dir(cli_project_dir: Optional[str] = None) -> Path:
    """自动寻找项目根目录，支持脚本被复制到 better 等子目录后运行。"""
    candidates: List[Path] = []
    if cli_project_dir:
        candidates.append(Path(cli_project_dir).expanduser().resolve())

    # 当前脚本目录及所有父目录。
    candidates.extend([SCRIPT_DIR, *SCRIPT_DIR.parents])

    # 用户服务器上常见的项目位置兜底。
    common_roots = [
        Path.cwd(),
        Path("/root/autodl-tmp/MedNER_Project/better"),
        Path("/root/autodl-tmp/MedNER_Project/medical_ner_v21_FINAL"),
        Path("/root/autodl-tmp/MedNER_Project"),
    ]
    for root in common_roots:
        root = root.expanduser().resolve()
        candidates.append(root)
        # 只浅层查找，避免在服务器上递归扫太久。
        if root.exists() and root.is_dir():
            try:
                candidates.extend([p for p in root.iterdir() if p.is_dir()])
            except PermissionError:
                pass

    seen = set()
    for cand in candidates:
        if cand in seen:
            continue
        seen.add(cand)
        if _looks_like_project_root(cand):
            return cand

    searched = "\n".join(f"  - {p}" for p in list(seen)[:30])
    raise ModuleNotFoundError(
        "找不到项目根目录：需要同时存在 config/config.py、run_pipeline.py、src/dataset_detector.py。\n"
        "请确认你是在完整项目根目录运行，或用 --project-dir 指定完整项目目录，例如：\n"
        "  python3 run_small_test.py --project-dir /root/autodl-tmp/MedNER_Project/better\n\n"
        "已尝试查找的位置：\n" + searched
    )


def _load_json(path: str) -> list:
    """兼容标准 JSON、JSONL、带噪声前缀和连续 JSON 对象的数据加载器。"""
    if not os.path.exists(path):
        raise FileNotFoundError(path)

    content = None
    last_err: Optional[Exception] = None
    for encoding in ("utf-8-sig", "utf-8", "gbk", "latin-1"):
        try:
            with open(path, "r", encoding=encoding) as f:
                content = f.read().strip()
            break
        except (UnicodeDecodeError, UnicodeError) as exc:
            last_err = exc
            continue
    if content is None:
        raise UnicodeError(f"无法读取文件编码: {path}; last_error={last_err}")
    if not content:
        return []
    if content.startswith("\ufeff"):
        content = content[1:]

    # 1. 标准 JSON 数组或单对象。
    try:
        data = json.loads(content)
        return data if isinstance(data, list) else [data]
    except json.JSONDecodeError:
        pass

    # 2. 清理不可见字符后重试。
    cleaned = content.replace("\x00", "").replace("\r", "")
    cleaned = re.sub(r"[\x01-\x08\x0b\x0c\x0e-\x1f]", "", cleaned)
    try:
        data = json.loads(cleaned)
        return data if isinstance(data, list) else [data]
    except json.JSONDecodeError:
        pass

    # 3. 从首个 JSON 起始符开始解析，处理文件头/日志前缀。
    for start_char in ("[", "{"):
        start_pos = cleaned.find(start_char)
        if start_pos > 0:
            try:
                data = json.loads(cleaned[start_pos:])
                if isinstance(data, list):
                    return [d for d in data if isinstance(d, dict)]
                return [data] if isinstance(data, dict) else []
            except json.JSONDecodeError:
                pass

    # 4. JSONL：逐行尝试解析；如果一行前面有 id/tab 等前缀，则从该行第一个 { 或 [ 开始解析。
    out: List[dict] = []
    line_errors = 0
    for raw_line in cleaned.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        parsed = None
        for candidate in (line, line[line.find("{"):] if "{" in line else "", line[line.find("["):] if "[" in line else ""):
            if not candidate:
                continue
            try:
                parsed = json.loads(candidate)
                break
            except json.JSONDecodeError:
                continue
        if isinstance(parsed, dict):
            out.append(parsed)
        elif isinstance(parsed, list):
            out.extend([x for x in parsed if isinstance(x, dict)])
        else:
            line_errors += 1
    if out:
        if line_errors:
            print(f"  ⚠️ JSONL 加载时跳过 {line_errors} 行非 JSON 内容: {path}")
        return out

    # 5. 连续 JSON 对象或混杂文本：扫描每个可能的起点，用 raw_decode 抽取对象。
    decoder = json.JSONDecoder()
    results: List[dict] = []
    idx = 0
    while idx < len(cleaned):
        next_obj = len(cleaned)
        for ch in ("{", "["):
            pos = cleaned.find(ch, idx)
            if pos != -1:
                next_obj = min(next_obj, pos)
        if next_obj == len(cleaned):
            break
        idx = next_obj
        try:
            obj, end_idx = decoder.raw_decode(cleaned, idx)
            if isinstance(obj, dict):
                results.append(obj)
            elif isinstance(obj, list):
                results.extend([item for item in obj if isinstance(item, dict)])
            idx = max(end_idx, idx + 1)
        except json.JSONDecodeError:
            idx += 1
    if results:
        return results

    raise ValueError(f"文件格式无法识别或未解析出样本: {path}")


def _save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def _set_project_data_loader() -> None:
    """优先绑定当前项目自身的数据加载器；只做读取复用，不改变模型和主流程逻辑。"""
    global PROJECT_DATA_LOADER
    try:
        from src.data_processor import _load_json as project_load_json  # noqa: WPS433,E402
        PROJECT_DATA_LOADER = project_load_json
        print("数据加载器: 优先使用当前项目 src.data_processor._load_json；失败时使用 run_small_test 兜底解析。")
    except Exception as exc:
        PROJECT_DATA_LOADER = None
        print(f"  ⚠️ 未能导入当前项目数据加载器，将仅使用小测脚本兜底解析: {exc}")


def _load_with_project_format(path: str) -> List[dict]:
    """
    读取数据文件。

    设计原则：模型、抽取、归一化和评估全部仍走当前 v21 项目；这里仅参考 v20_4 的
    数据读取方式，优先复用当前项目自己的 src.data_processor._load_json。如果它在某些
    非标准文件上返回空，再用本脚本的增强解析兜底，避免小样本切片阶段提前失败。
    """
    if PROJECT_DATA_LOADER is not None:
        try:
            data = PROJECT_DATA_LOADER(path)
            if isinstance(data, list) and data:
                return [x for x in data if isinstance(x, dict)]
            if isinstance(data, list):
                print(f"  ⚠️ 当前项目数据加载器未解析出记录，尝试兜底解析: {path}")
        except Exception as exc:
            print(f"  ⚠️ 当前项目数据加载器读取失败，尝试兜底解析: {path}; error={exc}")
    data = _load_json(path)
    return [x for x in data if isinstance(x, dict)]


def _load_and_take(path: str, limit: int) -> List[dict]:
    if not path or not os.path.exists(path):
        raise FileNotFoundError(f"数据文件不存在: {path}")
    data = _load_with_project_format(path)
    if not isinstance(data, list):
        raise ValueError(f"数据文件应读取为 list，但实际是 {type(data)}: {path}")
    if not data:
        raise ValueError(f"数据文件为空或未解析出 dict 样本: {path}")
    return data[: min(limit, len(data))]


def _make_subset_file(src_path: str, limit: int, out_path: Path) -> Dict[str, Any]:
    data = _load_and_take(src_path, limit)
    _save_json(out_path, data)
    return {
        "source_path": src_path,
        "subset_path": str(out_path),
        "requested_limit": limit,
        "actual_count": len(data),
    }


def _safe_metric(eval_dict: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not eval_dict:
        return {}
    keys = [
        "tp", "fp", "fn", "precision", "recall", "micro_f1", "macro_f1",
        "macro_f1_nonempty", "n_samples", "n_true_empty",
        "imcs_raw_pred_rule_normalized",
    ]
    return {k: eval_dict.get(k) for k in keys if k in eval_dict}


def _existing_or_none(path: Optional[str]) -> Optional[str]:
    if path and os.path.exists(path):
        return path
    return None


def _write_markdown_report(report_path: Path, manifest: Dict[str, Any]) -> None:
    lines = []
    lines.append("# 小样本测试产出报告")
    lines.append("")
    lines.append(f"生成时间：{manifest.get('created_at')}  ")
    lines.append(f"输出目录：`{manifest.get('output_dir')}`")
    lines.append("")
    lines.append("## 一、测试规模")
    lines.append("")
    lines.append("| 数据集 | 请求条数 | 实际条数 | 小样本输入文件 |")
    lines.append("|---|---:|---:|---|")
    for ds, info in manifest.get("subsets", {}).items():
        lines.append(
            f"| {ds} | {info.get('requested_limit')} | {info.get('actual_count')} | "
            f"`{info.get('subset_path')}` |"
        )
    lines.append("")
    lines.append("## 二、阶段产物")
    lines.append("")
    lines.append("| 数据集 | Step 0 知识包 | Step 1/2/3 抽取与过滤结果 | Step 5 归一化结果 |")
    lines.append("|---|---|---|---|")
    for ds, result in manifest.get("results", {}).items():
        artifacts = result.get("artifacts", {})
        lines.append(
            f"| {ds} | `{artifacts.get('knowledge_path') or ''}` | "
            f"`{artifacts.get('step1_path') or ''}` | `{artifacts.get('step5_path') or ''}` |"
        )
    lines.append("")
    lines.append("## 三、指标汇总")
    lines.append("")
    lines.append("| 数据集 | 阶段 | Precision | Recall | Micro F1 | Macro F1 | Macro F1* | TP | FP | FN |")
    lines.append("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    for ds, result in manifest.get("results", {}).items():
        for stage_name, metric in [
            ("Step 4 原始抽取", result.get("raw_eval", {})),
            ("Step 6 归一化后", result.get("normalized_eval", {})),
        ]:
            lines.append(
                f"| {ds} | {stage_name} | {metric.get('precision', '')} | "
                f"{metric.get('recall', '')} | {metric.get('micro_f1', '')} | "
                f"{metric.get('macro_f1', '')} | {metric.get('macro_f1_nonempty', '')} | "
                f"{metric.get('tp', '')} | {metric.get('fp', '')} | {metric.get('fn', '')} |"
            )
    lines.append("")
    lines.append("## 四、说明")
    lines.append("")
    lines.append("本脚本不会改变原始数据文件。它会先在输出目录下生成小样本 JSON，再调用统一流水线运行。")
    lines.append("如果你的模型路径或数据路径不存在，脚本会在对应阶段报错；请先检查 `config/config.py` 或使用命令行参数显式指定路径。")
    lines.append("`Macro F1*` 表示只统计 gold 或 pred 非空的 chunk，用于排查实体抽取错误。")
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="只跑 500 条 CMeEE 和 100 条 IMCS 的小样本测试")
    parser.add_argument("--cmeee-input", default=None, help="CMeEE dev/test 输入文件；默认使用 config.CMEEE_DEV_PATH")
    parser.add_argument("--imcs-input", default=None, help="IMCS dev/test 输入文件；默认使用 config.IMCS_DEV_PATH")
    parser.add_argument("--cmeee-train", default=None, help="CMeEE train 文件；默认使用 config.CMEEE_TRAIN_PATH")
    parser.add_argument("--imcs-train", default=None, help="IMCS train 文件；默认使用 config.IMCS_TRAIN_PATH")
    parser.add_argument("--cmeee-limit", type=int, default=500, help="CMeEE 测试条数，默认 500")
    parser.add_argument("--imcs-limit", type=int, default=100, help="IMCS 测试条数，默认 100")
    parser.add_argument("--train-limit", type=int, default=100, help="每个数据集用于预学习的 train 截断条数；设为 0 则跳过预学习")
    parser.add_argument("--output-dir", default=None, help="输出目录；默认 outputs/small_test_时间戳")
    parser.add_argument("--output-prefix", default="smalltest", help="流水线输出文件前缀")
    parser.add_argument("--project-dir", default=None, help="完整项目根目录；当脚本被单独复制到其他目录时使用")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--no-reflection", action="store_true", help="跳过反思，加快测试")
    parser.add_argument("--no-llm-fallback", action="store_true", help="跳过 IMCS LLM 归一化兜底，加快测试")
    parser.add_argument("--no-batch", action="store_true", help="禁用批处理")
    parser.add_argument("--only", choices=["all", "cmeee", "imcs"], default="all", help="只运行某一个数据集")
    return parser.parse_args()


def main() -> None:
    global PROJECT_DIR
    args = parse_args()
    PROJECT_DIR = _find_project_dir(args.project_dir)
    if str(PROJECT_DIR) not in sys.path:
        sys.path.insert(0, str(PROJECT_DIR))
    print(f"项目根目录: {PROJECT_DIR}")

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(args.output_dir or PROJECT_DIR / "outputs" / f"small_test_{run_id}").resolve()
    sample_dir = output_dir / "samples"
    output_dir.mkdir(parents=True, exist_ok=True)

    # 让 run_pipeline 的 OUTPUT_DIR 也指向本次小测目录。
    os.environ["MNER_OUTPUT_DIR"] = str(output_dir)

    from config.config import (  # noqa: E402
        CMEEE_DEV_PATH, CMEEE_TRAIN_PATH, IMCS_DEV_PATH, IMCS_TRAIN_PATH,
    )
    _set_project_data_loader()
    from run_pipeline import run_pipeline  # noqa: E402

    cmeee_input = args.cmeee_input or CMEEE_DEV_PATH
    imcs_input = args.imcs_input or IMCS_DEV_PATH
    cmeee_train = args.cmeee_train or CMEEE_TRAIN_PATH
    imcs_train = args.imcs_train or IMCS_TRAIN_PATH

    manifest: Dict[str, Any] = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "output_dir": str(output_dir),
        "limits": {
            "cmeee_limit": args.cmeee_limit,
            "imcs_limit": args.imcs_limit,
            "train_limit": args.train_limit,
        },
        "subsets": {},
        "results": {},
    }

    jobs = []
    if args.only in ("all", "cmeee"):
        jobs.append(("cmeee", cmeee_input, cmeee_train, args.cmeee_limit))
    if args.only in ("all", "imcs"):
        jobs.append(("imcs", imcs_input, imcs_train, args.imcs_limit))

    for dataset_name, input_path, train_path, limit in jobs:
        print("\n" + "=" * 80)
        print(f"准备小样本：{dataset_name} | limit={limit}")
        print("=" * 80)

        subset_path = sample_dir / f"{dataset_name}_dev_{limit}.json"
        manifest["subsets"][dataset_name] = _make_subset_file(input_path, limit, subset_path)
        print(f"小样本输入已保存: {subset_path}")

        train_subset_path = None
        if args.train_limit > 0 and train_path and os.path.exists(train_path):
            train_subset_path = sample_dir / f"{dataset_name}_train_{args.train_limit}.json"
            train_info = _make_subset_file(train_path, args.train_limit, train_subset_path)
            manifest["subsets"][dataset_name]["train_subset"] = train_info
            print(f"预学习 train 小样本已保存: {train_subset_path}")
        else:
            print("跳过预学习 train 小样本：未提供 train 或 --train-limit=0")

        prefix = f"{args.output_prefix}_{dataset_name}_{limit}"
        started = time.time()
        res = run_pipeline(
            input_path=str(subset_path),
            train_path=str(train_subset_path) if train_subset_path else None,
            output_prefix=prefix,
            use_reflection=not args.no_reflection,
            use_llm_fallback=not args.no_llm_fallback,
            use_batch=not args.no_batch,
            batch_size=args.batch_size,
            eval_only=False,
            dump_knowledge=True,
        )
        elapsed = round(time.time() - started, 2)

        fname = subset_path.name.replace(".json", "")
        knowledge_path = output_dir / f"knowledge_{fname}.json"
        dataset_result = {
            "elapsed_seconds": elapsed,
            "dataset_type": res.get("dataset_type") if res else dataset_name,
            "n_items": res.get("n_items") if res else None,
            "raw_eval": _safe_metric(res.get("raw_eval") if res else None),
            "normalized_eval": _safe_metric(res.get("normalized_eval") if res else None),
            "artifacts": {
                "sample_input_path": str(subset_path),
                "train_subset_path": str(train_subset_path) if train_subset_path else None,
                "knowledge_path": str(knowledge_path) if knowledge_path.exists() else None,
                "step1_path": _existing_or_none(res.get("step1_path") if res else None),
                "step5_path": _existing_or_none(res.get("step5_path") if res else None),
            },
        }
        manifest["results"][dataset_name] = dataset_result
        _save_json(output_dir / f"{dataset_name}_result_summary.json", dataset_result)

        print("\n阶段产物：")
        for key, value in dataset_result["artifacts"].items():
            print(f"  - {key}: {value}")
        print("指标：")
        print(json.dumps({
            "raw_eval": dataset_result["raw_eval"],
            "normalized_eval": dataset_result["normalized_eval"],
        }, ensure_ascii=False, indent=2))

    manifest_path = output_dir / "small_test_manifest.json"
    report_path = output_dir / "small_test_report.md"
    _save_json(manifest_path, manifest)
    _write_markdown_report(report_path, manifest)

    print("\n" + "=" * 80)
    print("小样本测试完成")
    print("=" * 80)
    print(f"总清单: {manifest_path}")
    print(f"报告:   {report_path}")


if __name__ == "__main__":
    main()
