#!/bin/bash
# ============================================================================
# v21 模型下载脚本（ModelScope，AutoDL 优化）
# ============================================================================
# 用法：
#   bash download_models.sh             # 下载主+副模型（推荐方案 A）
#   bash download_models.sh primary     # 仅下载主模型
#   bash download_models.sh secondary   # 仅下载副模型
#   bash download_models.sh fallback    # 用 Qwen2.5-7B 作副模型（备选方案 B）
#
# 环境变量：
#   MNER_MODEL_ROOT  # 模型存放根目录（默认 /root/autodl-tmp/MedNER_Project/models）
# ============================================================================

set -e

# ---- 颜色 ----
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok()      { echo -e "${GREEN}[ OK ]${NC} $1"; }
log_warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error()   { echo -e "${RED}[FAIL]${NC} $1"; }

# ---- 模型根目录 ----
MNER_MODEL_ROOT="${MNER_MODEL_ROOT:-/root/autodl-tmp/MedNER_Project/models}"
mkdir -p "$MNER_MODEL_ROOT"

log_info "模型根目录: $MNER_MODEL_ROOT"

# ---- 磁盘空间检查 ----
check_disk_space() {
    local need_gb=$1
    local target_dir=$2
    local avail_gb=$(df -BG "$target_dir" 2>/dev/null | tail -1 | awk '{print $4}' | tr -d 'G')
    if [ -z "$avail_gb" ]; then
        log_warn "无法检测磁盘空间，跳过检查"
        return 0
    fi
    log_info "磁盘剩余: ${avail_gb}GB | 需要至少: ${need_gb}GB"
    if [ "$avail_gb" -lt "$need_gb" ]; then
        log_error "磁盘空间不足！需要至少 ${need_gb}GB"
        log_warn "建议清理: rm -rf ~/.cache/modelscope && conda clean --all -y"
        return 1
    fi
    return 0
}

# ---- 检查 modelscope 是否安装 ----
check_modelscope() {
    if ! command -v modelscope &> /dev/null; then
        log_warn "modelscope 未安装，正在安装..."
        pip install modelscope -U -q 2>&1 | tail -3
        if ! command -v modelscope &> /dev/null; then
            log_error "modelscope 安装失败，请手动安装: pip install modelscope -U"
            exit 1
        fi
    fi
    log_ok "modelscope 已就绪 ($(modelscope --version 2>&1 | head -1))"
}

# ---- 下载主模型 ----
download_primary() {
    local TARGET="$MNER_MODEL_ROOT/Qwen3-32B-AWQ"
    log_info "▸ 下载主模型: Qwen3-32B-AWQ → $TARGET"

    if [ -f "$TARGET/config.json" ] && [ -f "$TARGET/model.safetensors.index.json" ]; then
        log_ok "主模型已存在，跳过下载"
        return 0
    fi

    check_disk_space 22 "$MNER_MODEL_ROOT" || return 1

    modelscope download --model Qwen/Qwen3-32B-AWQ \
        --local_dir "$TARGET" || {
        log_error "主模型下载失败"
        return 1
    }
    log_ok "主模型下载完成"
}

# ---- 下载副模型（方案 A：DeepSeek-14B Int4）----
download_secondary_deepseek() {
    local TARGET="$MNER_MODEL_ROOT/DeepSeek-R1-Distill-Qwen-14B-AWQ"
    log_info "▸ 下载副模型: DeepSeek-R1-Distill-Qwen-14B-Int4-W4A16 → $TARGET"

    if [ -f "$TARGET/config.json" ] && [ -f "$TARGET/model.safetensors.index.json" ]; then
        log_ok "副模型已存在，跳过下载"
        return 0
    fi

    check_disk_space 12 "$MNER_MODEL_ROOT" || return 1

    modelscope download --model okwinds/DeepSeek-R1-Distill-Qwen-14B-Int4-W4A16 \
        --local_dir "$TARGET" || {
        log_warn "DeepSeek Int4 下载失败，尝试备选 Qwen2.5-7B"
        download_secondary_qwen
        return $?
    }
    log_ok "副模型 (DeepSeek Int4) 下载完成"
}

# ---- 下载副模型（方案 B：Qwen2.5-7B-AWQ）----
download_secondary_qwen() {
    local TARGET="$MNER_MODEL_ROOT/Qwen2.5-7B-Instruct-AWQ"
    log_info "▸ 下载副模型 (备选): Qwen2.5-7B-Instruct-AWQ → $TARGET"

    if [ -f "$TARGET/config.json" ] && [ -f "$TARGET/model.safetensors.index.json" ]; then
        log_ok "Qwen2.5-7B 已存在，跳过下载"
        return 0
    fi

    check_disk_space 8 "$MNER_MODEL_ROOT" || return 1

    modelscope download --model Qwen/Qwen2.5-7B-Instruct-AWQ \
        --local_dir "$TARGET" || {
        log_error "Qwen2.5-7B 也下载失败"
        return 1
    }
    log_ok "副模型 (Qwen2.5-7B-AWQ) 下载完成"

    log_warn "⚠️ 注意：你选择了备选副模型，请修改 config/config.py:"
    log_warn "    SECONDARY_MODEL_PATH = .../Qwen2.5-7B-Instruct-AWQ"
    log_warn "    SECONDARY_QUANTIZATION = 'awq_marlin'"
    log_warn "    SECONDARY_GPU_UTIL = 0.20"
    log_warn "或者直接用 patch 包里的 config_for_qwen25_7b.py 覆盖 config.py"
}

# ---- 下载 BGE Embedding（可选）----
download_bge() {
    local TARGET="$MNER_MODEL_ROOT/bge-large-zh-v1.5"
    log_info "▸ 下载 BGE 嵌入模型: bge-large-zh-v1.5"

    if [ -f "$TARGET/config.json" ]; then
        log_ok "BGE 已存在，跳过"
        return 0
    fi

    modelscope download --model AI-ModelScope/bge-large-zh-v1.5 \
        --local_dir "$TARGET" || {
        log_warn "BGE 下载失败（非致命，预学习中部分功能不可用）"
        return 0
    }
    log_ok "BGE 下载完成"
}

# ---- 下载 MacBERT（可选）----
download_macbert() {
    local TARGET="$MNER_MODEL_ROOT/macbert"
    log_info "▸ 下载 MacBERT (chinese-macbert-base)"

    if [ -f "$TARGET/config.json" ]; then
        log_ok "MacBERT 已存在，跳过"
        return 0
    fi

    modelscope download --model dienstag/chinese-macbert-base \
        --local_dir "$TARGET" || {
        log_warn "MacBERT 下载失败（非致命）"
        return 0
    }
    log_ok "MacBERT 下载完成"
}

# ============================================================================
# 主流程
# ============================================================================

ACTION="${1:-all}"

check_modelscope

case "$ACTION" in
    all)
        log_info "═══ 完整下载（主模型 + DeepSeek-14B 副模型 + 嵌入）═══"
        download_primary
        download_secondary_deepseek
        download_bge
        download_macbert
        ;;
    primary)
        download_primary
        ;;
    secondary)
        download_secondary_deepseek
        ;;
    fallback)
        log_info "═══ 备选方案：使用 Qwen2.5-7B 作副模型 ═══"
        download_primary
        download_secondary_qwen
        ;;
    bge)
        download_bge
        ;;
    macbert)
        download_macbert
        ;;
    *)
        log_error "未知参数: $ACTION"
        echo "用法: bash download_models.sh [all|primary|secondary|fallback|bge|macbert]"
        exit 1
        ;;
esac

# ============================================================================
# 汇总
# ============================================================================

echo ""
log_info "═══ 下载结果汇总 ═══"
for model_dir in "$MNER_MODEL_ROOT"/*/; do
    if [ -d "$model_dir" ]; then
        size=$(du -sh "$model_dir" 2>/dev/null | awk '{print $1}')
        log_ok "$(basename $model_dir): $size"
    fi
done

echo ""
log_info "下一步："
echo "  1. 检查 config/config.py 的模型路径是否正确"
echo "  2. 运行: python run_pipeline.py --dataset imcs --split dev"
