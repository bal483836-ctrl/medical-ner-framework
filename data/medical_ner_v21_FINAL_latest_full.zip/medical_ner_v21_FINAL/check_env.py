#!/usr/bin/env python3
"""
环境与配置检查脚本 - v21

跑流水线前先跑这个，提前发现问题：
  1. Python 依赖检查（vllm / transformers / modelscope）
  2. GPU 检查（型号、显存）
  3. 模型路径检查（主+副模型 + 嵌入 + MacBERT）
  4. 数据集路径检查
  5. config.py 合理性检查

用法：python check_env.py
"""
import os
import sys
import importlib
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ---- 颜色 ----
G = "\033[32m"; R = "\033[31m"; Y = "\033[33m"; B = "\033[34m"; N = "\033[0m"


def ok(msg):    print(f"  {G}✓{N} {msg}")
def fail(msg):  print(f"  {R}✗{N} {msg}")
def warn(msg):  print(f"  {Y}⚠{N} {msg}")
def info(msg):  print(f"  {B}ℹ{N} {msg}")


# ---- 检查项 ----

n_errors = 0
n_warnings = 0


def check_python_packages():
    print(f"\n{B}▸ Python 依赖{N}")
    global n_errors, n_warnings
    required = {
        "torch":             "torch>=2.4.0",
        "transformers":      "transformers>=4.45.0",
        "vllm":              "vllm>=0.6.0 (推荐)",
        "modelscope":        "modelscope (下载模型用)",
        "tqdm":              "tqdm",
        "numpy":             "numpy",
    }
    for pkg, spec in required.items():
        try:
            mod = importlib.import_module(pkg)
            ver = getattr(mod, "__version__", "unknown")
            ok(f"{pkg} ({ver})")
        except ImportError:
            if pkg in ("vllm",):
                warn(f"{pkg} 未安装 → 会退化到 transformers 后端，速度慢 3-5x")
                n_warnings += 1
            else:
                fail(f"{pkg} 未安装 → pip install {spec}")
                n_errors += 1


def check_gpu():
    print(f"\n{B}▸ GPU 环境{N}")
    global n_errors
    try:
        import torch
        if not torch.cuda.is_available():
            fail("CUDA 不可用")
            n_errors += 1
            return
        n = torch.cuda.device_count()
        for i in range(n):
            name = torch.cuda.get_device_name(i)
            mem = torch.cuda.get_device_properties(i).total_memory / 1024**3
            cap = torch.cuda.get_device_capability(i)
            cap_str = f"sm_{cap[0]}{cap[1]}"
            ok(f"GPU {i}: {name} | {mem:.1f}GB | {cap_str}")
            if mem < 30:
                warn(f"  显存 {mem:.1f}GB < 30GB，双模型可能 OOM；考虑用 Qwen2.5-7B 副模型")
    except Exception as e:
        fail(f"GPU 检查失败: {e}")
        n_errors += 1


def check_paths():
    print(f"\n{B}▸ 模型路径{N}")
    global n_errors, n_warnings

    # 加载 config
    try:
        from config import config as cfg
    except Exception as e:
        fail(f"无法加载 config.py: {e}")
        n_errors += 1
        return

    info(f"MODEL_ROOT = {cfg.MODEL_ROOT}")
    info(f"DATA_ROOT  = {cfg.DATA_ROOT}")

    # 主模型
    p = cfg.PRIMARY_MODEL_PATH
    if os.path.exists(os.path.join(p, "config.json")):
        size_gb = sum(f.stat().st_size for f in Path(p).rglob("*.safetensors")) / 1024**3
        ok(f"主模型: {p} (~{size_gb:.1f}GB)")
        info(f"  量化方式: {cfg.PRIMARY_QUANTIZATION}, gpu_util={cfg.PRIMARY_GPU_UTIL}")
    else:
        fail(f"主模型不存在: {p}")
        info(f"  执行: bash download_models.sh primary")
        n_errors += 1

    # 副模型
    p = cfg.SECONDARY_MODEL_PATH
    if os.path.exists(os.path.join(p, "config.json")):
        size_gb = sum(f.stat().st_size for f in Path(p).rglob("*.safetensors")) / 1024**3
        ok(f"副模型: {p} (~{size_gb:.1f}GB)")
        info(f"  量化方式: {cfg.SECONDARY_QUANTIZATION}, gpu_util={cfg.SECONDARY_GPU_UTIL}")
    else:
        warn(f"副模型不存在: {p}")
        info(f"  → 代码会自动退化为单模型模式（F1 可能降低 0.05-0.10）")
        info(f"  → 如需双模型：bash download_models.sh secondary")
        n_warnings += 1

    # 嵌入
    p = cfg.EMBEDDING_MODEL_PATH
    if os.path.exists(os.path.join(p, "config.json")):
        ok(f"嵌入模型: {p}")
    else:
        warn(f"嵌入模型不存在: {p} (非致命)")
        n_warnings += 1

    # MacBERT
    p = cfg.MODEL_MACBERT_PATH
    if os.path.exists(os.path.join(p, "config.json")):
        ok(f"MacBERT: {p}")
    else:
        warn(f"MacBERT 不存在: {p} (非致命)")
        n_warnings += 1


def check_data_paths():
    print(f"\n{B}▸ 数据集路径{N}")
    global n_errors

    try:
        from config import config as cfg
    except Exception:
        return

    datasets = [
        ("CMeEE train", cfg.CMEEE_TRAIN_PATH),
        ("CMeEE dev",   cfg.CMEEE_DEV_PATH),
        ("IMCS train",  cfg.IMCS_TRAIN_PATH),
        ("IMCS dev",    cfg.IMCS_DEV_PATH),
    ]
    for name, p in datasets:
        if os.path.exists(p):
            sz = os.path.getsize(p) / 1024**2
            ok(f"{name}: {p} ({sz:.1f}MB)")
        else:
            warn(f"{name} 不存在: {p}")


def check_vllm_quantization():
    """检查 vLLM 是否支持 config 里指定的量化方式"""
    print(f"\n{B}▸ vLLM 量化后端{N}")
    global n_warnings

    try:
        import vllm
    except ImportError:
        warn("vLLM 未安装，跳过此检查")
        return

    try:
        from config import config as cfg
    except Exception:
        return

    vllm_ver = vllm.__version__
    info(f"vLLM 版本: {vllm_ver}")

    # 简单提示：根据量化方式给版本建议
    for label, q in [("主模型", cfg.PRIMARY_QUANTIZATION),
                     ("副模型", cfg.SECONDARY_QUANTIZATION)]:
        if q == "awq_marlin":
            info(f"{label}: awq_marlin → 需要 vLLM >= 0.5.0，GPU 算力 >= 7.5")
        elif q == "compressed-tensors":
            if vllm_ver < "0.6":
                warn(f"{label}: compressed-tensors 需要 vLLM >= 0.6.0，当前 {vllm_ver}")
                info("  升级: pip install -U vllm")
                n_warnings += 1
            else:
                info(f"{label}: compressed-tensors → 支持")
        elif q == "gptq_marlin":
            info(f"{label}: gptq_marlin → 需要 vLLM >= 0.5.0")


def main():
    print(f"\n{B}{'=' * 50}{N}")
    print(f"{B}  医疗 NER v21 环境检查{N}")
    print(f"{B}{'=' * 50}{N}")

    check_python_packages()
    check_gpu()
    check_paths()
    check_data_paths()
    check_vllm_quantization()

    print(f"\n{B}{'=' * 50}{N}")
    if n_errors == 0 and n_warnings == 0:
        print(f"  {G}✓ 全部检查通过，可以运行 run_pipeline.py{N}")
    elif n_errors == 0:
        print(f"  {Y}⚠ {n_warnings} 个非致命警告，可以尝试运行{N}")
    else:
        print(f"  {R}✗ {n_errors} 个致命错误，请先修复{N}")
    print(f"{B}{'=' * 50}{N}\n")

    sys.exit(0 if n_errors == 0 else 1)


if __name__ == "__main__":
    main()
