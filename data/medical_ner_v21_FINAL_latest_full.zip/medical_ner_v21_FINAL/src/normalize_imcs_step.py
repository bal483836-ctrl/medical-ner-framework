"""
v20.3: IMCS Step 2 - 独立的归一化步骤

职责：
  接收 Step1 的口语症状输出，归一化为标准医学词。
  输出独立 JSON 文件，便于错误归因和消融。

策略：
  1. 4 级降级匹配（精确 / 数据集 oral_map / 学到 oral_map / 子串）
  2. 引入 normalization skills（来自 LearnedKnowledge）作为额外提示——
     但因为这是后处理而非 LLM 调用，skills 暂以日志形式记录，未来可扩展为
     "对未匹配上的口语词调用 LLM 二次归一化"
  3. 严格区分"成功归一" vs "归一失败保留原文"两种情况

输入字段：item['step1_sentence_entities']: [{'raw': '流清鼻涕', 'anchored': True}, ...]
输出字段：
  item['step2_normalized_entities']: [{'raw': ..., 'normed': ..., 'method': 'exact|oral|learned|substring|fail'}]
  item['step2_normed_output']: 标准词逗号分隔
"""
import json
import os
import re
import sys
from typing import Dict, List, Optional, Set
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.few_shot_learner import LearnedKnowledge
from src.kg_alignment import get_oral_to_standard_map, build_imcs_norm_vocab


# ==================== 核心归一化算法 ====================

def normalize_with_method(
    entity: str,
    oral_map: Dict[str, str],
    learned_oral_map: Dict[str, str],
    norm_vocab_set: Set[str],
) -> Dict:
    """
    v20.8 增强：更激进的归一化层级
    返回 {"normed": str|None, "method": str}
    """
    entity = entity.strip()
    if not entity:
        return {"normed": None, "method": "fail"}

    # 1) 已是标准词
    if entity in norm_vocab_set:
        return {"normed": entity, "method": "already_standard"}

    # 2) 数据集自带口语映射
    if entity in oral_map:
        return {"normed": oral_map[entity], "method": "oral_map"}

    # 3) 学习对齐到的口语映射
    if entity in learned_oral_map:
        return {"normed": learned_oral_map[entity], "method": "learned_oral"}

    # 4) 子串：实体含某标准词（取最长）—— "咳痰"含"痰"
    best, best_len = None, 0
    for norm in norm_vocab_set:
        if norm in entity and len(norm) > best_len:
            best, best_len = norm, len(norm)
    if best and best_len >= 1:  # v20.8: 改为 ≥1 字也行（覆盖"咳痰"→"痰"）
        return {"normed": best, "method": "substring_contains"}

    # 5) 子串：标准词含实体（如"咳"在"咳嗽"中）
    for norm in norm_vocab_set:
        if entity in norm and len(entity) >= 2:
            return {"normed": norm, "method": "substring_contained"}

    # 6) 程度前缀 / 动词前缀 / 部位前缀 去除
    # v20.8: 大幅扩展前缀清单
    prefixes = [
        # 程度词
        "有点", "有些", "比较", "非常", "轻微", "严重", "持续", "反复",
        "偶尔", "经常", "一直", "总是", "总", "老",
        # 动词前缀（v20.8 新增）
        "咳", "流", "拉", "吐", "拉了", "吐了", "流了", "咳了",
        # 部位前缀
        "喉咙有", "嗓子有", "鼻子有", "肚子", "胸口", "脑袋",
        "有", "无", "在",
    ]
    for prefix in prefixes:
        if entity.startswith(prefix) and len(entity) > len(prefix):
            rem = entity[len(prefix):]
            if rem in norm_vocab_set:
                return {"normed": rem, "method": "prefix_strip_standard"}
            if rem in oral_map:
                return {"normed": oral_map[rem], "method": "prefix_strip_oral"}
            if rem in learned_oral_map:
                return {"normed": learned_oral_map[rem], "method": "prefix_strip_learned"}
            # rem 再做子串匹配
            for norm in norm_vocab_set:
                if norm in rem and len(norm) >= 2:
                    return {"normed": norm, "method": "prefix_strip_substring"}

    # 7) 后缀去除（v20.8 新增）
    suffixes = [
        "了", "的", "啊", "呢", "吧", "正常", "不正常", "异常",
        "差不多", "可以", "不好", "好",
    ]
    for suffix in suffixes:
        if entity.endswith(suffix) and len(entity) > len(suffix):
            rem = entity[:-len(suffix)]
            if rem in norm_vocab_set:
                return {"normed": rem, "method": "suffix_strip_standard"}
            if rem in oral_map:
                return {"normed": oral_map[rem], "method": "suffix_strip_oral"}
            if rem in learned_oral_map:
                return {"normed": learned_oral_map[rem], "method": "suffix_strip_learned"}

    # 8) 数字温度（保留原始字符串供 Step3 解析）
    if re.search(r'\d{2}\.?\d?\s*[°℃度]', entity):
        return {"normed": entity, "method": "temperature_raw"}

    # 9) 字符重叠 ≥0.6 模糊匹配（v20.8 新增）—— 兜底救一些边缘案例
    n_chars = set(c for c in entity if '\u4e00' <= c <= '\u9fff')
    if len(n_chars) >= 2:
        best_norm = None; best_score = 0.0
        for norm in norm_vocab_set:
            v_chars = set(c for c in norm if '\u4e00' <= c <= '\u9fff')
            if not v_chars:
                continue
            overlap = len(n_chars & v_chars) / max(len(n_chars), len(v_chars))
            if overlap > best_score:
                best_norm, best_score = norm, overlap
        if best_norm and best_score >= 0.7:
            return {"normed": best_norm, "method": "fuzzy_match"}

    # 失败：保留原文为最后回退
    return {"normed": entity, "method": "fail_keep_raw"}


# ==================== Step 2 主入口 ====================

def normalize_imcs_step(
    step1_data: list,
    knowledge: LearnedKnowledge,
    output_path: str,
) -> list:
    """对 Step1 的 IMCS 输出做归一化"""
    print(f"\n📌 IMCS Step2 归一化（{len(step1_data)}条对话）")

    oral_map = get_oral_to_standard_map()
    norm_vocab_set = set(build_imcs_norm_vocab()) | set(knowledge.norm_vocab)
    learned_oral = knowledge.aligned_oral_to_norm

    print(f"  数据集 oral_map: {len(oral_map)} 条")
    print(f"  学到 oral_map: {len(learned_oral)} 条")
    print(f"  norm_vocab: {len(norm_vocab_set)} 词")

    # 统计各 method 的命中次数（论文消融用）
    method_counter = {}

    results = []
    for item in tqdm(step1_data, desc="IMCS-Step2"):
        # 收集所有 raw 候选（去重）
        raw_candidates = set()
        for turn in item.get('dialogue', []):
            for ent in turn.get('step1_sentence_entities', []):
                if isinstance(ent, dict) and ent.get('raw'):
                    raw_candidates.add(ent['raw'])
                elif isinstance(ent, str):
                    raw_candidates.add(ent)

        # 兜底：如果 step1_sentence_entities 缺失，尝试从 step1_raw_output 拆
        if not raw_candidates:
            for r in item.get('step1_raw_output', '').split(','):
                if r.strip():
                    raw_candidates.add(r.strip())

        # 逐个归一化
        normalized_entities = []
        normed_set = set()
        for raw in raw_candidates:
            res = normalize_with_method(raw, oral_map, learned_oral, norm_vocab_set)
            method = res['method']
            method_counter[method] = method_counter.get(method, 0) + 1

            normed = res['normed']
            if normed:
                normalized_entities.append({
                    'raw': raw, 'normed': normed, 'method': method
                })
                normed_set.add(normed)

        item['step2_normalized_entities'] = normalized_entities
        item['step2_normed_output'] = ",".join(sorted(normed_set))
        results.append(item)

    print(f"\n  归一化方法分布:")
    for m, c in sorted(method_counter.items(), key=lambda x: -x[1]):
        print(f"    {m}: {c}")

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"  ✅ Step2 保存至 {output_path}")

    return results
