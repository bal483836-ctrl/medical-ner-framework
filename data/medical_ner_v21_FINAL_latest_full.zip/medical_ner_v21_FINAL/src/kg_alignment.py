"""
KG / 词典对齐模块 - v20

修复：
  1. 路径不再硬编码，改用 config 中的可配置项（支持环境变量覆盖）
  2. 补齐 filter_hallucinations.py / cmeee_expand.py 引用的辅助函数：
     - get_oral_to_standard_map
     - build_imcs_norm_vocab
     - build_cmeee_entity_vocab
"""
import json
import os
import sys
from typing import Dict, List, Set

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import (
    DATA_ROOT, DICT_DIR,
    IMCS_ORAL_TO_NORM_PATH, IMCS_SYMPTOM_NORM_PATH,
    IMCS_OFFICIAL_DICT_PATH, ENTITIES_DICT_PATH,
)


# ==================== 加载 IMCS 口语→标准词映射 ====================

def get_oral_to_standard_map() -> Dict[str, str]:
    """加载 IMCS 数据集自带的口语映射表（404条）

    优先顺序：
      1. data/dicts/imcs_oral_to_norm.json （仓库内）
      2. IMCS_OFFICIAL_DICT_PATH 配置（外部 imcs_symptom_dict.json，{std: [orals]} 格式）
    """
    mapping: Dict[str, str] = {}

    # 1) 仓库自带的 oral_to_norm
    if os.path.exists(IMCS_ORAL_TO_NORM_PATH):
        try:
            with open(IMCS_ORAL_TO_NORM_PATH, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            # 格式可能是 {oral: norm} 或 {norm: [orals]}
            if isinstance(raw, dict):
                # 探测格式
                first_val = next(iter(raw.values())) if raw else None
                if isinstance(first_val, list):
                    # {norm: [orals]} 格式
                    for std, orals in raw.items():
                        for o in orals:
                            mapping[o] = std
                else:
                    # {oral: norm} 格式
                    for o, n in raw.items():
                        mapping[o] = n
        except Exception as e:
            print(f"  ⚠️ 加载 {IMCS_ORAL_TO_NORM_PATH} 失败: {e}")

    # 2) 外部官方字典（如配置）
    if IMCS_OFFICIAL_DICT_PATH and os.path.exists(IMCS_OFFICIAL_DICT_PATH):
        try:
            with open(IMCS_OFFICIAL_DICT_PATH, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            for std, orals in raw.items():
                for o in orals:
                    mapping.setdefault(o, std)
        except Exception:
            pass

    return mapping


# ==================== 构建 IMCS 标准词表 ====================

def build_imcs_norm_vocab() -> List[str]:
    """构建 IMCS 标准症状词表"""
    vocab: Set[str] = set()

    # 1) 仓库自带 imcs_symptom_norm.json
    if os.path.exists(IMCS_SYMPTOM_NORM_PATH):
        try:
            with open(IMCS_SYMPTOM_NORM_PATH, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            if isinstance(raw, list):
                vocab.update(raw)
            elif isinstance(raw, dict):
                vocab.update(raw.keys())
        except Exception as e:
            print(f"  ⚠️ 加载 {IMCS_SYMPTOM_NORM_PATH} 失败: {e}")

    # 2) 从 oral map 的标准词侧补充
    for std in get_oral_to_standard_map().values():
        if std:
            vocab.add(std)

    return sorted(vocab)


# ==================== 构建 CMeEE 词表 ====================

def build_cmeee_entity_vocab(extra_paths: List[str] = None) -> List[str]:
    """构建 CMeEE 实体词表（用于 Step 1.5 词汇扩展）

    数据来源：
      1. config 中 ENTITIES_DICT_PATH（如配置）
      2. 学习样本中已抽出的实体（这部分由调用方传入并 union）
    """
    vocab: Set[str] = set()

    if ENTITIES_DICT_PATH and os.path.exists(ENTITIES_DICT_PATH):
        try:
            with open(ENTITIES_DICT_PATH, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        vocab.add(line)
        except Exception:
            pass

    if extra_paths:
        for p in extra_paths:
            if os.path.exists(p):
                with open(p, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            vocab.add(line)

    return sorted(vocab)


# ==================== KGAligner（保留 v19 接口，但去掉硬编码） ====================

class KGAligner:
    """词典对齐 + LLM 二次判断"""

    def __init__(self, config=None):
        self.config = config
        self.imcs_oral_map = get_oral_to_standard_map()
        self.entities_dict = self._load_entities_dict()

    def _load_entities_dict(self) -> Set[str]:
        if not ENTITIES_DICT_PATH or not os.path.exists(ENTITIES_DICT_PATH):
            return set()
        try:
            with open(ENTITIES_DICT_PATH, 'r', encoding='utf-8') as f:
                return {line.strip() for line in f if line.strip()}
        except Exception:
            return set()

    def align_and_filter(self, entity: str, dataset_type: str, llm_judge_func=None):
        """
        Returns: (keep: bool, aligned_entity: Optional[str])
        """
        # 1) IMCS 归一化
        if dataset_type.lower() == "imcs" and entity in self.imcs_oral_map:
            return True, self.imcs_oral_map[entity]

        # 2) 命中已知实体词典
        if entity in self.entities_dict:
            return True, entity

        # 3) LLM 二次判断（慢，作为最后手段）
        if llm_judge_func:
            try:
                if llm_judge_func(entity):
                    return True, entity
            except Exception:
                pass

        # 4) 短词 / 单字默认丢弃，长词默认保留
        if len(entity) >= 3:
            return True, entity

        return False, None
