"""MacBERT 抽取器 - v20

变化：把 torch / transformers 改为懒加载（构造函数内导入），
这样无 GPU / 无 torch 环境也能 import 整个项目，便于本地调试。
"""
import os
from typing import List


class MacBERTExtractor:
    def __init__(self, model_path: str):
        self.is_ready = False
        self.tokenizer = None
        self.model = None
        self.device = None

        # 懒加载 torch
        try:
            import torch
            from transformers import AutoTokenizer, AutoModelForTokenClassification
        except ImportError as e:
            print(f"  ⚠️ MacBERT 依赖未安装 ({e})，跳过初始化")
            return

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"🔄 正在尝试加载 MacBERT: {model_path}")

        if not os.path.exists(model_path):
            print(f"  ❌ 路径不存在: {model_path}")
            return

        # 深度搜索核心文件
        actual_path = model_path
        core_files = ["vocab.txt", "config.json"]
        found_all = all(os.path.exists(os.path.join(actual_path, f)) for f in core_files)

        if not found_all:
            print(f"  🔎 主目录未找齐核心文件，开始深度搜索...")
            for root, _, files in os.walk(model_path):
                if all(f in files for f in core_files):
                    actual_path = root
                    print(f"  ✨ 找到核心文件于: {actual_path}")
                    found_all = True
                    break

        if not found_all:
            print(f"  ❌ 在 {model_path} 下未找到 vocab.txt / config.json")
            return

        try:
            self.tokenizer = AutoTokenizer.from_pretrained(actual_path, local_files_only=True, use_fast=False)
            self.model = AutoModelForTokenClassification.from_pretrained(actual_path, local_files_only=True)
            self.model.to(self.device)
            self.model.eval()
            self.is_ready = True
            print(f"  ✅ MacBERT 加载成功 ({actual_path})")
        except Exception as e:
            print(f"  ⚠️ MacBERT 实例化失败: {e}")

    def extract(self, text: str) -> List[str]:
        if not self.is_ready or not text:
            return []
        try:
            import torch
            inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=512).to(self.device)
            with torch.no_grad():
                outputs = self.model(**inputs).logits
            predictions = torch.argmax(outputs, dim=2)
            tokens = self.tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])
            entities, current_ent = [], ""
            for token, pred in zip(tokens, predictions[0]):
                if token in ["[CLS]", "[SEP]", "[PAD]"]:
                    continue
                if pred > 0:
                    if token.startswith("##"):
                        current_ent += token[2:]
                    else:
                        current_ent += token
                else:
                    if current_ent:
                        entities.append(current_ent)
                        current_ent = ""
            if current_ent:
                entities.append(current_ent)
            return list(set(entities))
        except Exception:
            return []
