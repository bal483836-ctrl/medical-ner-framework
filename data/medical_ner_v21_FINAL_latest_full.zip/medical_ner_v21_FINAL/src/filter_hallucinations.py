"""
Step 3 - 幻觉过滤 / 归一化 / 温度推断 - v20-P2

核心修复（B3 - Step3 反而降分）：
  问题：v20.0 的 Step3 在 CMeEE 上比 Step1.5 差（0.359 → 0.343）
  根因分析：
    - 样本 14 "泌尿系统" 被删了（FN 增加）
    - 样本 18 "脑"、"脑疝" 被删了（FN 增加）
    - 删除条件 "len(ent)==2 and not in learned_set 需要独立性" 太严
    
  修复策略：
    - 不再删 ent，仅做边界修剪
    - 独立性检查只在词扩展时使用，不在过滤端使用
    - 引入"前后扩展子串裁剪"：如果 pred 是 gold 词的扩展 (如"治疗脑室膜炎"中"脑室膜炎"才是 gold)
      尝试在已知词表中找最长合法子串
    - 保留 IMCS 的口语归一化和温度推断

新增（P2）：
  - 长实体保留：>10 字的实体不强制删除（CMeEE 标注规范允许）
  - IMCS 修复 B5：评估端口语归一化生效（在 normalize_and_evaluate 修，但 step3 也应用）
"""
import json
import os
import re
import sys
from typing import List, Set, Dict, Optional
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import OUTPUT_DIR, FEVER_GRADE, CMEEE_TARGET_TYPES
from src.few_shot_learner import LearnedKnowledge
from src.kg_alignment import get_oral_to_standard_map, build_imcs_norm_vocab


UNIVERSAL_NOISE = {"无", "none", "None", "NULL", "null", "无实体", "无症状", "暂无", "不详", ""}

# CMeEE 中常见的"上位词"，从未独立作为实体（FP 中反复出现），
# 但只在它们**没有**作为某个 gold 词的子串时才删除。
# 这里的列表来自 CMeEE_V2 train 集统计（频率 >50 但作为实体出现 <5%）
CMEEE_LIKELY_NOISE = {"疾病", "病人", "患者", "症状", "病例", "情况", "结果",
                       "方法", "过程", "原因", "效果", "作用"}


# ==================== 边界修剪辅助 ====================

def _trim_extension(pred: str, text: str, vocab_set: Set[str]) -> str:
    """如果 pred 是 vocab 中某个词的扩展（pred 包含某 vocab 词），
    且 pred 本身不在 vocab 中，尝试裁剪到最长 vocab 子串。
    
    例如 pred="治疗脑室膜炎"，vocab 含"脑室膜炎"，则裁剪为"脑室膜炎"。
    """
    if pred in vocab_set:
        return pred
    # 在 vocab 中找最长子串
    best = pred
    best_len = -1
    for v in vocab_set:
        if v in pred and len(v) > best_len and v in text:
            best = v
            best_len = len(v)
    return best


def _trim_helper_chars(name: str) -> str:
    """剔除尾部助词 / 标点"""
    # 多次剥离（"原位杂交技术研究" 后缀可能多层）
    for _ in range(3):
        new = re.sub(r'[的等了吗啊呢吧呀嘛、，。；：!?"]+$', '', name)
        new = re.sub(r'^[的等了吗啊呢吧呀嘛、，。；：!?"]+', '', new)
        if new == name:
            break
        name = new
    return name.strip()


def _filter_cmeee_entities(entities: list, text: str, knowledge) -> list:
    """v20.5+v20.6: 位置感知 + 类型校正

    新增 v20.6 类型校正：
      如果一个 entity name 在 train 中绝大多数（≥80%）标某个类型 T，
      但 pred 标的是另一类型 T'，且 T 在 pred 同名实体类型分布里也很少出现，
      则将类型修正为 T。
    """
    learned_set = knowledge.all_entities
    name_type_dist = getattr(knowledge, 'name_to_type_dist', {})

    # 第 1 遍：清洗
    cleaned = []
    for e in entities:
        if not isinstance(e, dict):
            continue
        name = (e.get('entity') or '').strip()
        if not name:
            continue
        if re.match(r'^[\d\s\W]+$', name):
            continue
        if name in UNIVERSAL_NOISE:
            continue
        if name in CMEEE_LIKELY_NOISE:
            in_learned_or_substr = (name in learned_set) or any(
                name in v and name != v for v in learned_set)
            if not in_learned_or_substr:
                continue
        cleaned.append(e)

    # 第 1.5 遍 (v20.6): 类型校正
    for e in cleaned:
        name = e.get('entity', '')
        pred_t = e.get('type')
        if name in name_type_dist:
            train_dist = name_type_dist[name]
            total = sum(train_dist.values())
            if total >= 2:  # 至少出现 2 次才有统计意义
                top_t, top_c = max(train_dist.items(), key=lambda x: x[1])
                top_ratio = top_c / total
                # train 中 ≥80% 是某类型 + pred 不在该类型 → 修正
                if top_ratio >= 0.8 and pred_t != top_t:
                    e['_type_corrected_from'] = pred_t  # 记录原类型供调试
                    e['type'] = top_t

    # 第 2 遍：位置三元组去重
    seen_keys = set()
    unique = []
    for e in cleaned:
        key = (e.get('start_idx'), e.get('end_idx'), e.get('type'))
        if key in seen_keys:
            continue
        seen_keys.add(key)
        unique.append(e)

    # 第 3 遍：短实体被同类型长实体覆盖则删
    by_type = {}
    for e in unique:
        by_type.setdefault(e.get('type'), []).append(e)

    final = []
    for e in unique:
        name = e.get('entity', '')
        if len(name) > 2:
            final.append(e)
            continue
        s, ee = e.get('start_idx'), e.get('end_idx')
        if s is None or ee is None:
            final.append(e)
            continue
        covered = False
        for other in by_type.get(e.get('type'), []):
            if other is e:
                continue
            os_, oe = other.get('start_idx'), other.get('end_idx')
            if os_ is None or oe is None:
                continue
            if os_ <= s and ee <= oe and (oe - os_) > (ee - s):
                covered = True
                break
        if not covered:
            final.append(e)

    return final


def _is_standalone(word: str, text: str) -> bool:
    """词在原文中至少有一处独立出现（前后非汉字）"""
    if word not in text:
        return False
    start = 0
    while True:
        idx = text.find(word, start)
        if idx == -1:
            break
        before = text[idx - 1] if idx > 0 else ""
        after = text[idx + len(word)] if idx + len(word) < len(text) else ""
        b_cjk = bool(re.match(r'[\u4e00-\u9fff]', before)) if before else False
        a_cjk = bool(re.match(r'[\u4e00-\u9fff]', after)) if after else False
        if not b_cjk or not a_cjk:
            return True
        start = idx + 1
    return False


# ==================== CMeEE 后处理 ====================

def post_process_cmeee(
    entities: List[str],
    text: str,
    knowledge: LearnedKnowledge,
) -> List[str]:
    """
    保守的过滤策略：
      1. 边界修剪（剥助词）
      2. 原文锚定
      3. 仅删除明显噪声词（CMEEE_LIKELY_NOISE 中且不是任何 gold 词的子串）
      4. 不再因长度做删除
      5. 长实体（>=15字）保留
    """
    learned_set = knowledge.all_entities

    filtered = []
    seen = set()

    for ent in entities:
        if not ent or ent in UNIVERSAL_NOISE:
            continue

        # 边界修剪
        ent = _trim_helper_chars(ent)
        if not ent or ent in seen:
            continue

        # 删除纯数字 / 纯标点
        if re.match(r'^[\d\s\W]+$', ent):
            continue

        # 原文锚定（如修剪后变形了，再次检查）
        if ent not in text:
            # 尝试在词表中找最长子串
            ent_trimmed = _trim_extension(ent, text, learned_set)
            if ent_trimmed != ent and ent_trimmed in text and ent_trimmed not in seen:
                ent = ent_trimmed
            else:
                continue

        # 删除"上位词"且非任何已知实体子串
        if ent in CMEEE_LIKELY_NOISE:
            # 仅当该词在 learned_set 中也没出现，且也不是 learned_set 中长词的子串
            is_legitimate = (ent in learned_set) or any(
                ent in v and ent != v for v in learned_set
            )
            if not is_legitimate:
                continue

        seen.add(ent)
        filtered.append(ent)

    return filtered


# ==================== IMCS 后处理 ====================

def normalize_imcs_entity(
    entity: str,
    oral_map: Dict[str, str],
    learned_oral_map: Dict[str, str],
    norm_vocab_set: Set[str],
) -> Optional[str]:
    """4 级降级归一化"""
    entity = entity.strip()
    if not entity:
        return None

    # 1) 已是标准词
    if entity in norm_vocab_set:
        return entity

    # 2) 数据集自带口语映射
    if entity in oral_map:
        return oral_map[entity]

    # 3) 学习对齐到的口语映射
    if entity in learned_oral_map:
        return learned_oral_map[entity]

    # 4) 子串：实体含某标准词
    best, best_len = None, 0
    for norm in norm_vocab_set:
        if norm in entity and len(norm) > best_len:
            best, best_len = norm, len(norm)
    if best and best_len >= 2:
        return best

    # 5) 子串：标准词含实体
    for norm in norm_vocab_set:
        if entity in norm and len(entity) >= 2:
            return norm

    # 6) 前缀去除
    prefixes = ["有点", "有些", "比较", "非常", "轻微", "严重", "持续",
                "反复", "偶尔", "经常"]
    for prefix in prefixes:
        if entity.startswith(prefix) and len(entity) > len(prefix):
            rem = entity[len(prefix):]
            if rem in norm_vocab_set:
                return rem
            if rem in oral_map:
                return oral_map[rem]
            if rem in learned_oral_map:
                return learned_oral_map[rem]

    return entity


def post_process_imcs(
    entities: List[str],
    full_text: str,
    knowledge: LearnedKnowledge,
) -> List[str]:
    """v20.1 增强：增加文本锚定 + 学到映射的反向验证

    核心改动：
      1. 已归一化的标准词，需要在原文中能"溯源"到一个口语形式（即原文中
         某个 2-7 字短语能映射到这个标准词）。否则视为 LLM 幻觉。
      2. 学到的口语映射作为反向验证字典：如果一个 pred=X，但原文中既无 X，
         也无任何能映射到 X 的口语词，那就是 LLM 凭医学常识编的，删除。
    """
    oral_map = get_oral_to_standard_map()
    norm_vocab_set = set(build_imcs_norm_vocab()) | set(knowledge.norm_vocab)
    learned_oral = knowledge.aligned_oral_to_norm

    # 反向索引：标准词 → 所有可能的口语形式（来自 oral_map + learned_oral）
    reverse_norm_to_orals = {}
    for o, n in oral_map.items():
        reverse_norm_to_orals.setdefault(n, set()).add(o)
    for o, n in learned_oral.items():
        reverse_norm_to_orals.setdefault(n, set()).add(o)
    # 标准词本身也是一个"口语"（自映射）
    for n in norm_vocab_set:
        reverse_norm_to_orals.setdefault(n, set()).add(n)

    filtered = []
    seen = set()
    for ent in entities:
        if not ent or ent in UNIVERSAL_NOISE:
            continue
        if re.match(r'^\d+[\d\.%℃°]*$', ent):
            continue

        normed = normalize_imcs_entity(ent, oral_map, learned_oral, norm_vocab_set)
        if normed is None:
            continue
        if normed not in norm_vocab_set and len(normed) <= 2:
            continue
        if normed in seen:
            continue

        # 文本锚定验证：normed 必须能在 full_text 中追溯到出处
        # 例外：温度推断的 "发热/低热/中等度热/高热" 由后续 extract_temperature_entities 控制
        if normed in {"发热", "低热", "中等度热", "高热"}:
            seen.add(normed)
            filtered.append(normed)
            continue

        traced = False
        # 1) 标准词本身在原文出现
        if normed in full_text:
            traced = True
        # 2) 反向索引中某口语形式在原文出现
        if not traced:
            possible_orals = reverse_norm_to_orals.get(normed, set())
            for oral in possible_orals:
                if oral and oral in full_text:
                    traced = True
                    break
        # 3) 严格 char-overlap：原文中 2-7 字片段与 normed 重合度 ≥ 0.6
        if not traced:
            n_chars = set(c for c in normed if '\u4e00' <= c <= '\u9fff')
            if len(n_chars) >= 2:
                for w in range(max(2, len(normed) - 1), min(8, len(normed) + 2)):
                    if w > len(full_text):
                        break
                    for i in range(len(full_text) - w + 1):
                        cand = full_text[i:i + w]
                        c_chars = set(c for c in cand if '\u4e00' <= c <= '\u9fff')
                        if not c_chars:
                            continue
                        overlap = len(c_chars & n_chars) / max(len(c_chars), len(n_chars))
                        if overlap >= 0.6:
                            traced = True
                            break
                    if traced:
                        break

        if not traced:
            continue  # 视为 LLM 幻觉，删除

        seen.add(normed)
        filtered.append(normed)

    return filtered


def extract_temperature_entities(full_text: str) -> List[str]:
    """《诊断学》第9版温度分级 - 仅在有具体数字时推断"""
    temp_patterns = [
        r'(\d{2}\.?\d?)\s*[°℃度]',
        r'体温[\s:：]*(\d{2}\.?\d?)',
        r'温度[\s:：]*(\d{2}\.?\d?)',
        r'烧到[\s]*(\d{2}\.?\d?)',
    ]
    temps = set()
    for pat in temp_patterns:
        for m in re.findall(pat, full_text):
            try:
                t = float(m)
                if 35.0 <= t <= 42.0:
                    temps.add(t)
            except ValueError:
                continue

    out = []
    for t in temps:
        for _, (low, high, label) in FEVER_GRADE.items():
            if low <= t <= high:
                out.append(label)
                break

    # 如果只有"发烧/发热"字样而无数字，归为"发热"
    if not temps and re.search(r'发烧|发热|烧了|烧到', full_text):
        out.append("发热")

    return list(set(out))


# ==================== Step 3 主入口 ====================

def filter_and_verify(
    step_data: list,
    is_imcs: bool,
    output_path: str,
    knowledge: LearnedKnowledge,
) -> list:
    """v20.3 改动：
       - IMCS：优先用 step2_normed_output（已归一化）作为输入
       - CMeEE：保持原逻辑（step1_enriched_output）
    """
    results = []
    for item in tqdm(step_data, desc=f"Step3 ({'IMCS' if is_imcs else 'CMeEE'})"):
        if is_imcs:
            # v20.8: 优先从 step2_normalized_entities 取**仅成功归一化的**
            # 排除 fail_keep_raw（未归一化的口语词常是 FP 大头）
            step2_ents = item.get('step2_normalized_entities', [])
            if step2_ents:
                # 仅保留归一化成功的（非 fail_keep_raw）
                # 但 fuzzy_match / suffix_strip 等仍保留
                successfully_normed = [
                    e['normed'] for e in step2_ents
                    if e.get('method') != 'fail_keep_raw' and e.get('normed')
                ]
                candidate_list = list(set(successfully_normed))
            else:
                # 回退老逻辑
                candidates_str = (item.get('step2_normed_output', '') or
                                  item.get('step1_raw_output', ''))
                candidate_list = [c.strip() for c in candidates_str.split(',') if c.strip()]
        else:
            # v20.4：CMeEE 优先用带位置的 step1_entities（保留 type+span 信息）
            candidate_list = []
            step1_ents = item.get('step1_entities', [])
            if step1_ents:
                # 同时保留位置和名字
                candidate_list = step1_ents
            else:
                candidates_str = (item.get('step1_enriched_output', '') or
                                  item.get('step1_raw_output', ''))
                # 退化为字符串模式
                for c in candidates_str.split(','):
                    if c.strip():
                        candidate_list.append({'entity': c.strip()})

        if is_imcs:
            full_text = (item.get("self_report", "") + " " +
                         " ".join(t.get("sentence", "") for t in item.get("dialogue", [])))
        else:
            full_text = item.get("text", "")

        if not candidate_list:
            item['step3_final_output'] = ""
            item['step3_entities'] = []
            results.append(item)
            continue

        if not is_imcs:
            # ============ v20.5 位置感知过滤 ============
            step1_entities = item.get('step1_entities', [])
            enriched_str = item.get('step1_enriched_output', '') or ''

            # v20.6: P5 - 多位置自动扩展
            # 对 step1 已抽出的每个 (name, type)，扫原文找出所有未记录的同位置
            existing_keys = set((e['start_idx'], e['end_idx'], e['type'])
                                for e in step1_entities)
            multi_pos_added = []
            name_type_pairs = set((e['entity'], e['type']) for e in step1_entities)
            for name, t in name_type_pairs:
                if not name or len(name) < 2:
                    continue  # 单字不做多位置扩展（容易引入 FP）
                pos = 0
                while True:
                    idx = full_text.find(name, pos)
                    if idx == -1:
                        break
                    end_idx = idx + len(name)
                    key = (idx, end_idx, t)
                    if key not in existing_keys:
                        multi_pos_added.append({
                            'start_idx': idx,
                            'end_idx': end_idx,
                            'type': t,
                            'entity': name,
                            '_source': 'multi_pos',
                        })
                        existing_keys.add(key)
                    pos = idx + 1

            # 收集 enriched 中新增（不在 step1）的实体
            step1_names = set(e.get('entity') for e in step1_entities if e.get('entity'))
            new_in_enriched = []
            for c in enriched_str.split(','):
                c = c.strip()
                if c and c not in step1_names and c in full_text and c not in {"无","无实体",""}:
                    new_in_enriched.append(c)

            # 为新增实体匹配位置（暂无类型，默认从 train 学到的最常见类型）
            type_by_vocab = {}
            for t, vocab in knowledge.entity_vocab_by_type.items():
                for v in vocab:
                    if v not in type_by_vocab:
                        type_by_vocab[v] = t

            new_entities = []
            for name in new_in_enriched:
                t = type_by_vocab.get(name)
                if not t:
                    continue
                pos = 0
                while True:
                    idx = full_text.find(name, pos)
                    if idx == -1:
                        break
                    new_entities.append({
                        'start_idx': idx,
                        'end_idx': idx + len(name),
                        'type': t,
                        'entity': name,
                        '_source': 'enriched',
                    })
                    pos = idx + 1

            all_candidates = list(step1_entities) + multi_pos_added + new_entities
            kept = _filter_cmeee_entities(all_candidates, full_text, knowledge)

            item['step3_entities'] = kept
            item['step3_final_output'] = ",".join(sorted(set(e['entity'] for e in kept)))
        else:
            cand_names = [c['entity'] if isinstance(c, dict) else c for c in candidate_list]
            filtered = post_process_imcs(cand_names, full_text, knowledge)
            temps = extract_temperature_entities(full_text)
            seen = set(filtered)
            for t in temps:
                if t not in seen:
                    filtered.append(t)
                    seen.add(t)
            item['step3_final_output'] = ",".join(filtered)

        results.append(item)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"  ✅ Step3 保存至 {output_path}")
    return results


# v19 兼容
_post_process_cmeee = post_process_cmeee
_post_process_imcs = post_process_imcs
_extract_temperature_entities = extract_temperature_entities
