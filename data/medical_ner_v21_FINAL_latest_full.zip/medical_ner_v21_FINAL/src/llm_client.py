"""
双 LLM 客户端 - v21 顺序加载版（5090 + cu128，方案 C）

设计原则（v21 方案 C）：
  - 主副模型不同时驻留显存
  - 主模型跑完所有抽取 → 显式 free → 加载副模型 → 跑所有反思
  - 实现：内部维护 _phase 状态，按需加载/释放
  - 单一 vLLM 路径，无 transformers fallback
"""
import os
import re
import sys
import gc
import threading
from typing import Optional, List

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import (
    PRIMARY_MODEL_PATH, PRIMARY_QUANTIZATION, PRIMARY_GPU_UTIL,
    SECONDARY_MODEL_PATH, SECONDARY_QUANTIZATION, SECONDARY_GPU_UTIL,
    LLM_MAX_NEW_TOKENS, LLM_TEMPERATURE, LLM_TOP_P,
    LLM_REPETITION_PENALTY, LLM_MAX_MODEL_LEN,
    REFLECTION_MAX_NEW_TOKENS,
)

_dual_client = None
_client_lock = threading.Lock()


# ==================== 输出清洗 ====================

def clean_llm_output(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
    text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL)
    text = re.sub(r'<\|.*?\|>', '', text)
    prefixes = ["实体：", "实体:", "答案：", "答案:", "输出：", "输出:",
                "通过审核的实体：", "通过审核的实体:", "判断结果：", "判断结果:",
                "JSON：", "JSON:", "```json", "```"]
    for p in prefixes:
        if text.startswith(p):
            text = text[len(p):]
    if text.endswith("```"):
        text = text[:-3]
    return text.strip()


def parse_deepseek_answer(raw: str) -> str:
    if not raw:
        return ""
    m = re.search(r'<answer>(.*?)</answer>', raw, re.DOTALL)
    if m:
        return m.group(1).strip()
    return clean_llm_output(raw)


# ==================== vLLM 顺序加载客户端 ====================

class _VLLMSequentialClient:
    """5090 32GB 不够双模型同时驻留 → 顺序加载策略
    
    流程：
      1. 初始化时不加载任何模型
      2. 调用 call_primary 时按需加载主模型（如果当前不是主模型）
      3. 调用 call_secondary 时主动卸载主模型，加载副模型
      4. 用户可手动调 switch_to_primary / switch_to_secondary / unload
    """

    def __init__(self, primary_path: str, secondary_path: str,
                 enable_secondary: bool = True):
        # 路径校验
        if not os.path.exists(primary_path):
            raise RuntimeError(f"主模型路径不存在: {primary_path}")
        if enable_secondary and not os.path.exists(secondary_path):
            raise RuntimeError(f"副模型路径不存在: {secondary_path}")
        
        self.primary_path = primary_path
        self.secondary_path = secondary_path
        self.enable_secondary = enable_secondary
        
        from vllm import LLM, SamplingParams
        self.LLM = LLM
        self.SamplingParams = SamplingParams
        
        # 当前驻留的模型："primary" / "secondary" / None
        self._phase = None
        self.primary = None
        self.secondary = None

    # -------- 显存管理 --------

    def _free_gpu(self):
        """彻底清掉 GPU 显存"""
        import torch
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    def _unload_current(self):
        """卸载当前驻留模型"""
        if self.primary is not None:
            print("  🗑️  释放主模型显存...")
            del self.primary
            self.primary = None
        if self.secondary is not None:
            print("  🗑️  释放副模型显存...")
            del self.secondary
            self.secondary = None
        self._free_gpu()
        self._phase = None

    def switch_to_primary(self):
        """切到主模型 - 必要时加载，幂等"""
        if self._phase == "primary" and self.primary is not None:
            return
        
        self._unload_current()
        
        print(f"\n🔄 [vLLM·顺序加载] 加载主模型: {self.primary_path}")
        print(f"   量化: {PRIMARY_QUANTIZATION} | GPU 利用率: {PRIMARY_GPU_UTIL}")
        self.primary = self.LLM(
            model=self.primary_path,
            quantization=PRIMARY_QUANTIZATION,
            max_model_len=LLM_MAX_MODEL_LEN,
            gpu_memory_utilization=PRIMARY_GPU_UTIL,
            trust_remote_code=True,
            enforce_eager=True,   # 5090 + torch 2.10 必须 eager 避免 inductor bug
            dtype="auto",
            disable_log_stats=True,
        )
        self._phase = "primary"
        print(f"   ✅ 主模型加载成功（当前显存独占）")

    def switch_to_secondary(self):
        """切到副模型 - 主动卸载主模型，加载副模型"""
        if not self.enable_secondary:
            raise RuntimeError("副模型未启用，无法切换")
        if self._phase == "secondary" and self.secondary is not None:
            return
        
        self._unload_current()
        
        print(f"\n🔄 [vLLM·顺序加载] 加载副模型: {self.secondary_path}")
        print(f"   量化: {SECONDARY_QUANTIZATION} | GPU 利用率: {SECONDARY_GPU_UTIL}")
        self.secondary = self.LLM(
            model=self.secondary_path,
            quantization=SECONDARY_QUANTIZATION,
            max_model_len=LLM_MAX_MODEL_LEN,
            gpu_memory_utilization=SECONDARY_GPU_UTIL,
            trust_remote_code=True,
            enforce_eager=True,
            dtype="auto",
            disable_log_stats=True,
        )
        self._phase = "secondary"
        print(f"   ✅ 副模型加载成功（当前显存独占）")

    def unload(self):
        """显式释放所有 GPU 资源"""
        self._unload_current()

    # -------- Prompt 格式化 --------

    def _format_qwen_prompt(self, user_text: str, system: str = None) -> str:
        sys_part = ""
        if system:
            sys_part = f"<|im_start|>system\n{system}<|im_end|>\n"
        return (
            f"{sys_part}"
            f"<|im_start|>user\n{user_text}<|im_end|>\n"
            f"<|im_start|>assistant\n"
        )

    def _format_deepseek_prompt(self, user_text: str) -> str:
        return (
            f"<|im_start|>user\n{user_text}<|im_end|>\n"
            f"<|im_start|>assistant\n"
        )

    # -------- 主模型推理 --------

    def call_primary(self, prompt: str, max_tokens: int = None,
                     temperature: float = None,
                     stop: Optional[List[str]] = None) -> str:
        self.switch_to_primary()
        if max_tokens is None: max_tokens = LLM_MAX_NEW_TOKENS
        if temperature is None: temperature = LLM_TEMPERATURE
        formatted = self._format_qwen_prompt(prompt)
        params = self.SamplingParams(
            temperature=max(temperature, 0.01),
            top_p=LLM_TOP_P,
            repetition_penalty=LLM_REPETITION_PENALTY,
            max_tokens=max_tokens,
            stop=stop or ["<|im_end|>"],
        )
        outputs = self.primary.generate([formatted], params, use_tqdm=False)
        text = outputs[0].outputs[0].text if outputs else ""
        return clean_llm_output(text)

    def call_primary_batch(self, prompts: List[str], max_tokens: int = None,
                           temperature: float = None,
                           stop: Optional[List[str]] = None) -> List[str]:
        self.switch_to_primary()
        if max_tokens is None: max_tokens = LLM_MAX_NEW_TOKENS
        if temperature is None: temperature = LLM_TEMPERATURE
        formatted = [self._format_qwen_prompt(p) for p in prompts]
        params = self.SamplingParams(
            temperature=max(temperature, 0.01),
            top_p=LLM_TOP_P,
            repetition_penalty=LLM_REPETITION_PENALTY,
            max_tokens=max_tokens,
            stop=stop or ["<|im_end|>"],
        )
        outputs = self.primary.generate(formatted, params, use_tqdm=True)
        return [clean_llm_output(o.outputs[0].text) for o in outputs]

    # -------- 副模型推理 --------

    def call_secondary(self, prompt: str, max_tokens: int = None,
                       temperature: float = None,
                       parse_cot: bool = True,
                       stop: Optional[List[str]] = None) -> str:
        self.switch_to_secondary()
        if max_tokens is None: max_tokens = REFLECTION_MAX_NEW_TOKENS
        if temperature is None: temperature = 0.3
        formatted = self._format_deepseek_prompt(prompt)
        params = self.SamplingParams(
            temperature=max(temperature, 0.01),
            top_p=0.95,
            repetition_penalty=LLM_REPETITION_PENALTY,
            max_tokens=max_tokens,
            stop=stop or ["<|im_end|>"],
        )
        outputs = self.secondary.generate([formatted], params, use_tqdm=False)
        text = outputs[0].outputs[0].text if outputs else ""
        if parse_cot:
            return parse_deepseek_answer(text)
        return clean_llm_output(text)

    def call_secondary_batch(self, prompts: List[str], max_tokens: int = None,
                             temperature: float = None,
                             parse_cot: bool = True,
                             stop: Optional[List[str]] = None) -> List[str]:
        self.switch_to_secondary()
        if max_tokens is None: max_tokens = REFLECTION_MAX_NEW_TOKENS
        if temperature is None: temperature = 0.3
        formatted = [self._format_deepseek_prompt(p) for p in prompts]
        params = self.SamplingParams(
            temperature=max(temperature, 0.01),
            top_p=0.95,
            repetition_penalty=LLM_REPETITION_PENALTY,
            max_tokens=max_tokens,
            stop=stop or ["<|im_end|>"],
        )
        outputs = self.secondary.generate(formatted, params, use_tqdm=True)
        if parse_cot:
            return [parse_deepseek_answer(o.outputs[0].text) for o in outputs]
        return [clean_llm_output(o.outputs[0].text) for o in outputs]


# ==================== 对外接口 ====================

def get_client(enable_secondary: bool = True):
    """获取双 LLM 客户端单例（顺序加载策略）"""
    global _dual_client
    if _dual_client is not None:
        return _dual_client

    with _client_lock:
        if _dual_client is not None:
            return _dual_client
        _dual_client = _VLLMSequentialClient(
            primary_path=PRIMARY_MODEL_PATH,
            secondary_path=SECONDARY_MODEL_PATH,
            enable_secondary=enable_secondary,
        )
    return _dual_client


# ==================== 向后兼容接口 ====================

def call_llm(prompt: str, max_tokens: int = None,
             temperature: float = None) -> str:
    return get_client().call_primary(prompt, max_tokens=max_tokens,
                                      temperature=temperature)


def call_llm_primary(prompt: str, **kw) -> str:
    return get_client().call_primary(prompt, **kw)


def call_llm_secondary(prompt: str, **kw) -> str:
    return get_client().call_secondary(prompt, **kw)


def call_llm_batch(prompts: List[str], use_secondary: bool = False, **kw) -> List[str]:
    client = get_client()
    if use_secondary:
        return client.call_secondary_batch(prompts, **kw)
    return client.call_primary_batch(prompts, **kw)
