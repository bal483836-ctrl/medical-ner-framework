"""
数据加载与预处理模块 - v6.1 修复版
修复内容：
  1. _load_json 兼容 JSONL 格式（每行一个JSON对象）
  2. extract_imcs_gold 过滤 symptom_type=0（否定/询问症状）
  3. 学习样本选择中也正确过滤 type=0
"""
import json
import os
import sys
import re
import random
from typing import List, Tuple, Set, Dict
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import (
    CMEEE_TRAIN_PATH, CMEEE_DEV_PATH, CMEEE_TEST_PATH,
    IMCS_TRAIN_PATH, IMCS_DEV_PATH, IMCS_TEST_PATH,
    YIDU_TRAIN_PATH, YIDU_DEV_PATH, YIDU_TEST_PATH,
    CMEEE_TYPE_MAP, FEW_SHOT_SEED,
    LEARN_SAMPLE_RATIO, LEARN_SAMPLE_MAX,
    FEW_SHOT_COUNT, SKILL_REF_COUNT,
    IMCS_TARGET_SYMPTOM_TYPES
)

# ==================== 数据加载 ====================

def _load_json(path: str) -> list:
    """
    加载 JSON 文件，自动兼容多种格式：
    1. 标准 JSON 数组: [{"key": "val"}, ...]
    2. JSONL 格式: 每行一个完整 JSON 对象
    
    增强处理：
    - 自动去除 BOM 头
    - 尝试多种编码（utf-8, utf-8-sig, gbk, latin-1）
    - 对格式化 JSON 不会错误回退到 JSONL 模式
    """
    if not os.path.exists(path):
        print(f"  ⚠️ 文件不存在: {path}")
        return []
    
    # 尝试多种编码读取
    content = None
    for encoding in ['utf-8-sig', 'utf-8', 'gbk', 'latin-1']:
        try:
            with open(path, 'r', encoding=encoding) as f:
                content = f.read().strip()
            if content:
                break
        except (UnicodeDecodeError, UnicodeError):
            continue
    
    if not content:
        print(f"  ⚠️ 文件为空或无法读取: {path}")
        return []
    
    # 去除可能残留的 BOM
    if content.startswith('\ufeff'):
        content = content[1:]
    
    # 策略1：尝试标准 JSON 解析
    try:
        data = json.loads(content)
        if isinstance(data, list):
            print(f"  📖 标准 JSON 加载成功: {len(data)} 条记录")
            return data
        else:
            return [data]
    except json.JSONDecodeError as e:
        print(f"  ⚠️ 标准 JSON 解析失败: {e}")
    
    # 策略2：清理不可见字符后重试标准 JSON
    cleaned = content.replace('\x00', '').replace('\r', '')
    # 去除控制字符（保留换行和制表符）
    cleaned = re.sub(r'[\x01-\x08\x0b\x0c\x0e-\x1f]', '', cleaned)
    try:
        data = json.loads(cleaned)
        if isinstance(data, list):
            print(f"  📖 清理后 JSON 加载成功: {len(data)} 条记录")
            return data
        else:
            return [data]
    except json.JSONDecodeError:
        pass
    
    # 策略2.5：尝试从第一个 [ 或 { 开始解析（处理文件开头有额外字符的情况）
    for start_char in ['[', '{']:
        start_pos = cleaned.find(start_char)
        if start_pos > 0:
            try:
                data = json.loads(cleaned[start_pos:])
                if isinstance(data, list):
                    data = [d for d in data if isinstance(d, dict)]
                    print(f"  📖 跳过前{start_pos}字符后 JSON 加载成功: {len(data)} 条记录")
                    return data
                elif isinstance(data, dict):
                    return [data]
            except json.JSONDecodeError:
                continue
    
    # 策略3：尝试 JSONL 格式（每行一个完整 JSON 对象）
    # 先检查前10行是否有完整 JSON 对象，避免对格式化 JSON 误判
    lines = cleaned.split('\n')
    test_lines = [l.strip() for l in lines[:20] if l.strip()]
    jsonl_success = 0
    for tl in test_lines:
        try:
            obj = json.loads(tl)
            if isinstance(obj, dict):
                jsonl_success += 1
        except json.JSONDecodeError:
            pass
    
    # 只有当前20行中至少有3行是完整JSON对象时，才认为是JSONL格式
    if jsonl_success >= 3:
        results = []
        error_count = 0
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    results.append(obj)
            except json.JSONDecodeError:
                error_count += 1
        if results:
            print(f"  📖 以 JSONL 格式加载: {len(results)} 条记录 ({error_count} 行跳过)")
            return results
    
    # 策略4：尝试用 json.JSONDecoder 逐个解析（处理连续JSON对象无换行的情况）
    decoder = json.JSONDecoder()
    results = []
    idx = 0
    while idx < len(cleaned):
        # 跳过空白和分隔符
        while idx < len(cleaned) and cleaned[idx] in ' \t\n\r,;':
            idx += 1
        if idx >= len(cleaned):
            break
        # 跳过数组括号
        if cleaned[idx] in '[]':
            idx += 1
            continue
        try:
            obj, end_idx = decoder.raw_decode(cleaned, idx)
            if isinstance(obj, dict):
                results.append(obj)
            elif isinstance(obj, list):
                # 从列表中只提取字典类型的元素
                results.extend([item for item in obj if isinstance(item, dict)])
            # 跳过字符串、数字等非字典类型
            idx = end_idx
        except json.JSONDecodeError:
            idx += 1
    
    if results:
        print(f"  📖 逐对象解析加载: {len(results)} 条记录")
        return results
    
    print(f"  ⚠️ 文件格式无法识别: {path}")
    return []


def load_cmeee(split: str = "dev") -> list:
    path_map = {"train": CMEEE_TRAIN_PATH, "dev": CMEEE_DEV_PATH, "test": CMEEE_TEST_PATH}
    data = _load_json(path_map.get(split, CMEEE_DEV_PATH))
    # 注入金标准字符串用于评估
    for item in data:
        if 'entities' in item:
            names = [e.get('entity', '') for e in item['entities'] if e.get('entity')]
            item['gold_entities_str'] = ",".join(names)
    return data

def load_imcs(split: str = "dev") -> list:
    path_map = {"train": IMCS_TRAIN_PATH, "dev": IMCS_DEV_PATH, "test": IMCS_TEST_PATH}
    data = _load_json(path_map.get(split, IMCS_DEV_PATH))
    # 注入金标准字符串用于评估
    for item in data:
        golds = extract_imcs_gold(item)
        item['gold_entities_str'] = ",".join(golds)
    return data

def load_yidu(split: str = "dev") -> list:
    path_map = {"train": YIDU_TRAIN_PATH, "dev": YIDU_DEV_PATH, "test": YIDU_TEST_PATH}
    return _load_json(path_map.get(split, YIDU_DEV_PATH))


# ==================== 金标准提取 ====================

def extract_cmeee_gold_names(item: dict) -> List[str]:
    """从 CMeEE 样本中提取金标准实体名列表"""
    names = []
    for ent in item.get("entities", []):
        name = ent.get("entity", "").strip()
        if name:
            names.append(name)
    return names

def extract_imcs_gold(item: dict) -> List[str]:
    """
    从 IMCS 样本中提取文档级金标准症状词（归一化后的标准词）。
    
    重要：只提取 symptom_type 为 "1"（患者确认）或 "2"（医生推断）的症状。
    type="0" 表示否定/询问的症状（如医生问但患者否认），不应计入金标准。
    """
    golds = set()
    for turn in item.get("dialogue", []):
        norms = turn.get("symptom_norm", [])
        types = turn.get("symptom_type", [])
        for i, n in enumerate(norms):
            if not n or not n.strip():
                continue
            stype = types[i] if i < len(types) else "1"
            if stype in IMCS_TARGET_SYMPTOM_TYPES:
                golds.add(n.strip())
    return list(golds)

def extract_imcs_gold_all_types(item: dict) -> List[str]:
    """提取所有类型的症状词（包括type=0），仅用于学习映射关系，不用于评估。"""
    golds = set()
    for turn in item.get("dialogue", []):
        for n in turn.get("symptom_norm", []):
            if n and n.strip():
                golds.add(n.strip())
    return list(golds)

def extract_yidu_gold_names(item: dict) -> List[str]:
    names = []
    for ent in item.get("entities", []):
        name = ent.get("entity", "").strip()
        if name:
            names.append(name)
    return names


# ==================== 学习样本选择（5%，不超过100条）====================

def _compute_learn_sample_count(total: int) -> int:
    n = int(total * LEARN_SAMPLE_RATIO)
    n = max(n, 10)
    n = min(n, LEARN_SAMPLE_MAX)
    return min(n, total)

def select_learn_samples_cmeee(data: list) -> list:
    if not data:
        return []
    n = _compute_learn_sample_count(len(data))
    random.seed(FEW_SHOT_SEED)
    # 按实体类型分组
    type_to_items = {}
    for item in data:
        types_in_item = set()
        for ent in item.get("entities", []):
            t = ent.get("type", "")
            if t:
                types_in_item.add(t)
        for t in types_in_item:
            if t not in type_to_items:
                type_to_items[t] = []
            type_to_items[t].append(item)
    # 分层采样
    selected_ids = set()
    selected = []
    for t, items in type_to_items.items():
        random.shuffle(items)
        for item in items:
            item_id = id(item)
            if item_id not in selected_ids:
                selected_ids.add(item_id)
                selected.append(item)
                break
    remaining = [item for item in data if id(item) not in selected_ids]
    remaining.sort(key=lambda x: len(x.get("entities", [])), reverse=True)
    for item in remaining:
        if len(selected) >= n:
            break
        selected_ids.add(id(item))
        selected.append(item)
    random.shuffle(selected)
    print(f"  📊 CMeEE 学习样本: {len(selected)}/{len(data)} 条 ({len(selected)/len(data)*100:.1f}%)")
    return selected

def select_learn_samples_imcs(data: list) -> list:
    if not data:
        return []
    n = _compute_learn_sample_count(len(data))
    random.seed(FEW_SHOT_SEED)
    scored = []
    for item in data:
        golds = extract_imcs_gold(item)
        turns_with_symptom = 0
        for t in item.get("dialogue", []):
            norms = t.get("symptom_norm", [])
            types = t.get("symptom_type", [])
            for i, nm in enumerate(norms):
                stype = types[i] if i < len(types) else "1"
                if stype in IMCS_TARGET_SYMPTOM_TYPES and nm and nm.strip():
                    turns_with_symptom += 1
                    break
        score = len(golds) * 2 + turns_with_symptom
        scored.append((score, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    candidates = [item for _, item in scored[:n * 2]]
    selected = random.sample(candidates, min(n, len(candidates)))
    print(f"  📊 IMCS 学习样本: {len(selected)}/{len(data)} 条 ({len(selected)/len(data)*100:.1f}%)")
    return selected


# ==================== Skills参考样本选择 ====================

def select_skill_refs_cmeee(learn_samples: list, n_skills: int = None) -> list:
    if n_skills is None:
        n_skills = SKILL_REF_COUNT
    if not learn_samples:
        return []
    candidates = []
    for item in learn_samples:
        entities = item.get("entities", [])
        if len(entities) < 2:
            continue
        names = [e.get("entity", "") for e in entities]
        types = set(e.get("type", "") for e in entities)
        score = 0
        for i, n1 in enumerate(names):
            for n2 in names[i+1:]:
                if n1 in n2 or n2 in n1:
                    score += 3
        single_chars = [n for n in names if len(n) == 1]
        if single_chars:
            score += 2
        score += len(types)
        if 3 <= len(entities) <= 8:
            score += 2
        candidates.append((score, item))
    candidates.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in candidates[:n_skills]]

def select_skill_refs_imcs(learn_samples: list, n_skills: int = None) -> list:
    if n_skills is None:
        n_skills = SKILL_REF_COUNT
    if not learn_samples:
        return []
    candidates = []
    for item in learn_samples:
        score = 0
        has_temp = False
        has_oral_diff = False
        for turn in item.get("dialogue", []):
            sentence = turn.get("sentence", "")
            norms = turn.get("symptom_norm", [])
            types = turn.get("symptom_type", [])
            if re.search(r'\d{2}\.?\d?[°℃度]', sentence):
                has_temp = True
                score += 3
            for i, norm in enumerate(norms):
                stype = types[i] if i < len(types) else "1"
                if stype in IMCS_TARGET_SYMPTOM_TYPES and norm and norm not in sentence:
                    has_oral_diff = True
                    score += 2
        golds = extract_imcs_gold(item)
        score += len(golds)
        if has_temp or has_oral_diff:
            candidates.append((score, item))
    if len(candidates) < n_skills:
        for item in learn_samples:
            if all(id(item) != id(c[1]) for c in candidates):
                golds = extract_imcs_gold(item)
                candidates.append((len(golds), item))
    candidates.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in candidates[:n_skills]]


# ==================== Prompt Few-Shot 示例构建 ====================

def build_cmeee_few_shot_examples(data: list, n: int = None) -> list:
    if n is None:
        n = FEW_SHOT_COUNT
    if not data:
        return []
    candidates = []
    for item in data:
        entities = item.get("entities", [])
        if len(entities) >= 3:
            types = set(e.get("type", "") for e in entities)
            candidates.append((len(types), len(entities), item))
    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
    if len(candidates) < n:
        existing_ids = set(id(c[2]) for c in candidates)
        for item in data:
            if id(item) not in existing_ids:
                candidates.append((0, 0, item))
            if len(candidates) >= n * 3:
                break
    random.seed(FEW_SHOT_SEED)
    pool = [item for _, _, item in candidates[:n * 3]]
    return random.sample(pool, min(n, len(pool)))

def build_imcs_few_shot_examples(data: list, n: int = None) -> list:
    if n is None:
        n = FEW_SHOT_COUNT
    if not data:
        return []
    candidates = []
    for item in data:
        golds = extract_imcs_gold(item)
        if len(golds) >= 3:
            candidates.append(item)
    if len(candidates) < n:
        candidates = data[:n * 3]
    random.seed(FEW_SHOT_SEED)
    return random.sample(candidates, min(n, len(candidates)))

def build_yidu_few_shot_examples(data: list, n: int = None) -> list:
    if n is None:
        n = FEW_SHOT_COUNT
    if not data:
        return []
    candidates = [item for item in data if len(item.get("entities", [])) >= 3]
    if len(candidates) < n:
        candidates = data[:n * 3]
    random.seed(FEW_SHOT_SEED)
    return random.sample(candidates, min(n, len(candidates)))


# ==================== Prompt 格式化 ====================

def format_cmeee_few_shot_prompt(examples: list) -> str:
    if not examples:
        return "（无示例）"
    lines = []
    for i, item in enumerate(examples, 1):
        text = item.get("text", "")
        entities = extract_cmeee_gold_names(item)
        entities_str = ",".join(entities) if entities else "无"
        lines.append(f"示例{i}：")
        lines.append(f"文本：{text}")
        lines.append(f"实体：{entities_str}")
        lines.append("")
    return "\n".join(lines)

def format_cmeee_skill_refs(skill_refs: list) -> str:
    if not skill_refs:
        return ""
    lines = ["【标注技能参考（展示特殊标注模式）】："]
    for i, item in enumerate(skill_refs, 1):
        text = item.get("text", "")
        entities = item.get("entities", [])
        names = [e.get("entity", "") for e in entities]
        lines.append(f"技能参考{i}：")
        lines.append(f"文本：{text}")
        lines.append(f"实体：{','.join(names)}")
        notes = []
        for j, n1 in enumerate(names):
            for n2 in names[j+1:]:
                if n1 in n2:
                    notes.append(f'"{n2}"和"{n1}"同时标注（嵌套）')
                elif n2 in n1:
                    notes.append(f'"{n1}"和"{n2}"同时标注（嵌套）')
        singles = [n for n in names if len(n) == 1]
        if singles:
            notes.append(f'单字实体"{",".join(singles)}"被独立标注')
        if notes:
            lines.append(f"模式说明：{'; '.join(notes[:3])}")
        lines.append("")
    return "\n".join(lines)

def format_imcs_few_shot_prompt(examples: list) -> str:
    """只展示 type=1,2 的症状词"""
    if not examples:
        return "（无示例）"
    lines = []
    for i, item in enumerate(examples, 1):
        lines.append(f"示例{i}：")
        shown_turns = 0
        for turn in item.get("dialogue", []):
            norms = turn.get("symptom_norm", [])
            types = turn.get("symptom_type", [])
            confirmed_norms = []
            for j, n in enumerate(norms):
                stype = types[j] if j < len(types) else "1"
                if stype in IMCS_TARGET_SYMPTOM_TYPES and n and n.strip():
                    confirmed_norms.append(n.strip())
            if confirmed_norms and shown_turns < 3:
                sentence = turn.get("sentence", "")
                speaker = turn.get("speaker", "")
                norms_str = ",".join(list(set(confirmed_norms)))
                lines.append(f"  发言({speaker})：{sentence}")
                lines.append(f"  实体：{norms_str}")
                shown_turns += 1
        if shown_turns == 0:
            if item.get("dialogue"):
                turn = item["dialogue"][0]
                lines.append(f"  发言({turn.get('speaker', '')})：{turn.get('sentence', '')}")
                lines.append(f"  实体：无")
        lines.append("")
    return "\n".join(lines)

def format_imcs_skill_refs(skill_refs: list) -> str:
    if not skill_refs:
        return ""
    lines = ["【标注技能参考（展示特殊标注模式）】："]
    for i, item in enumerate(skill_refs, 1):
        lines.append(f"技能参考{i}：")
        for turn in item.get("dialogue", []):
            sentence = turn.get("sentence", "")
            norms = turn.get("symptom_norm", [])
            types = turn.get("symptom_type", [])
            confirmed_norms = []
            for j, n in enumerate(norms):
                stype = types[j] if j < len(types) else "1"
                if stype in IMCS_TARGET_SYMPTOM_TYPES and n and n.strip():
                    confirmed_norms.append(n.strip())
            if confirmed_norms:
                speaker = turn.get("speaker", "")
                norms_str = ",".join(list(set(confirmed_norms)))
                lines.append(f"  发言({speaker})：{sentence}")
                lines.append(f"  标准词：{norms_str}")
                notes = []
                for norm in confirmed_norms:
                    if norm not in sentence:
                        notes.append(f'原文无"{norm}"直接出现，需从语义推断')
                if re.search(r'\d{2}\.?\d?[°℃度]', sentence):
                    notes.append("含温度值，需推断发热等级")
                if notes:
                    lines.append(f"  模式说明：{'; '.join(notes[:3])}")
                break
        lines.append("")
    return "\n".join(lines)

def format_yidu_few_shot_prompt(examples: list) -> str:
    if not examples:
        return "（无示例）"
    lines = []
    for i, item in enumerate(examples, 1):
        text = item.get("text", "")[:200]
        entities = extract_yidu_gold_names(item)
        entities_str = ",".join(entities) if entities else "无"
        lines.append(f"示例{i}：")
        lines.append(f"文本：{text}")
        lines.append(f"实体：{entities_str}")
        lines.append("")
    return "\n".join(lines)


# ==================== 实体清洗 ====================

def clean_entity_list(raw_str: str) -> List[str]:
    if not raw_str or raw_str.strip() in ("无", "none", "None", "NULL", "null", "无实体"):
        return []
    entities = re.split(r'[,，、;；\n\r\t]+', raw_str)
    NOISE = {"无", "none", "None", "NULL", "null", "无实体", "无症状", "暂无", "不详", ""}
    cleaned = []
    seen = set()
    for ent in entities:
        ent = ent.strip()
        # 1. 过滤 LLM 可能输出的解释性内容，如 "咳嗽 (症状)" -> "咳嗽"
        ent = re.sub(r'[\(（][^\(\)（）]*[\)）]$', '', ent)
        # 2. 过滤前导序号或标签，如 "1. 咳嗽" 或 "实体: 咳嗽"
        ent = re.sub(r'^[\d\.\s、]+', '', ent)
        ent = re.sub(r'^(实体|症状|疾病|药物|检查|手术|部位)[:：]\s*', '', ent)
        
        ent = re.sub(r'^[^\w\u4e00-\u9fff]+', '', ent)
        ent = re.sub(r'[^\w\u4e00-\u9fff]+$', '', ent)
        ent = ent.strip()
        
        if not ent or ent in NOISE or len(ent) < 1:
            continue
        if ent in seen:
            continue
        seen.add(ent)
        cleaned.append(ent)
    return cleaned


# ==================== 边界吸附 ====================

def fuzzy_find_boundary(text: str, entity: str) -> Tuple[int, int, str]:
    if not text or not entity:
        return -1, -1, entity
    idx = text.find(entity)
    if idx != -1:
        return idx, idx + len(entity), entity
    cleaned = re.sub(r'[，。、；：！？,.;:!?]+$', '', entity).strip()
    if cleaned and cleaned != entity:
        idx = text.find(cleaned)
        if idx != -1:
            return idx, idx + len(cleaned), cleaned
    stripped = entity.strip('"\'""''()（）[]【】')
    if stripped and stripped != entity:
        idx = text.find(stripped)
        if idx != -1:
            return idx, idx + len(stripped), stripped
    return -1, -1, entity
