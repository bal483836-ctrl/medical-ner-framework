"""
向量模型与余弦相似度计算模块 - 优化版 v4

支持：
  - sentence-transformers（推荐）
  - FlagEmbedding（BAAI官方）
  - TF-IDF 回退方案
  - 本地知识图谱词汇表构建
"""
import os
import sys
import numpy as np
import threading
from typing import List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import EMBEDDING_MODEL_PATH, EMBEDDING_BATCH_SIZE, EMBEDDING_DIM

# BGE 查询端指令前缀
BGE_QUERY_INSTRUCTION = "为这个句子生成表示以用于检索相关文章："

# 全局模型缓存
_emb_model = None
_emb_lock  = threading.Lock()


# ==================== 模型加载 ====================

def get_embedding_model():
    """懒加载向量模型（单例）"""
    global _emb_model
    if _emb_model is not None:
        return _emb_model

    with _emb_lock:
        if _emb_model is not None:
            return _emb_model

        print(f"\n🔄 正在加载本地向量模型: {EMBEDDING_MODEL_PATH}")

        # 方式1：sentence-transformers
        try:
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer(EMBEDDING_MODEL_PATH)
            _emb_model = ("sentence_transformers", model)
            print(f"   ✅ 向量模型加载成功（sentence-transformers）")
            return _emb_model
        except Exception as e:
            print(f"   ⚠️ sentence-transformers 加载失败: {e}")

        # 方式2：FlagEmbedding
        try:
            from FlagEmbedding import FlagModel
            model = FlagModel(
                EMBEDDING_MODEL_PATH,
                query_instruction_for_retrieval=BGE_QUERY_INSTRUCTION,
                use_fp16=True
            )
            _emb_model = ("flag_embedding", model)
            print(f"   ✅ 向量模型加载成功（FlagEmbedding）")
            return _emb_model
        except Exception as e:
            print(f"   ⚠️ FlagEmbedding 加载失败: {e}")

        # 方式3：TF-IDF 回退
        print(f"   ⚠️ 使用 TF-IDF 回退方案")
        _emb_model = ("tfidf", None)
        return _emb_model


# ==================== 向量编码 ====================

def encode_texts(texts: List[str], model_tuple, is_query: bool = False) -> np.ndarray:
    """
    将文本列表编码为向量

    Args:
        texts: 文本列表
        model_tuple: (model_type, model) 元组
        is_query: 是否为查询端（BGE需要加前缀）

    Returns:
        numpy 向量矩阵
    """
    model_type, model = model_tuple

    if model_type == "sentence_transformers":
        if is_query:
            texts = [BGE_QUERY_INSTRUCTION + t for t in texts]
        embeddings = model.encode(texts, batch_size=EMBEDDING_BATCH_SIZE, show_progress_bar=False)
        return np.array(embeddings)

    elif model_type == "flag_embedding":
        if is_query:
            embeddings = model.encode_queries(texts)
        else:
            embeddings = model.encode(texts)
        return np.array(embeddings)

    elif model_type == "tfidf":
        return _tfidf_encode(texts)

    return np.zeros((len(texts), EMBEDDING_DIM))


def _tfidf_encode(texts: List[str]) -> np.ndarray:
    """TF-IDF 回退编码"""
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        vectorizer = TfidfVectorizer(analyzer='char', ngram_range=(1, 3), max_features=EMBEDDING_DIM)
        matrix = vectorizer.fit_transform(texts).toarray()
        return matrix
    except ImportError:
        # 简单字符编码
        result = np.zeros((len(texts), EMBEDDING_DIM))
        for i, text in enumerate(texts):
            for j, char in enumerate(text[:EMBEDDING_DIM]):
                result[i][j] = ord(char) / 65536.0
        return result


# ==================== 相似度计算 ====================

def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """计算两个向量的余弦相似度"""
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return float(np.dot(a, b) / (norm_a * norm_b))


def find_best_matches(
    query: str,
    candidates: List[str],
    model_tuple,
    top_k: int = 3
) -> List[Tuple[str, float]]:
    """
    找到与查询最相似的候选词

    Args:
        query: 查询文本
        candidates: 候选词列表
        model_tuple: 向量模型
        top_k: 返回前K个

    Returns:
        [(候选词, 相似度分数)] 列表
    """
    if not query or not candidates:
        return []

    # 编码
    query_vec = encode_texts([query], model_tuple, is_query=True)
    cand_vecs = encode_texts(candidates, model_tuple, is_query=False)

    # 计算相似度
    scores = []
    for i, cand in enumerate(candidates):
        sim = cosine_similarity(query_vec[0], cand_vecs[i])
        scores.append((cand, sim))

    # 排序
    scores.sort(key=lambda x: x[1], reverse=True)
    return scores[:top_k]


# ==================== 知识图谱词汇表构建 ====================

def build_local_kg_vocab(data: list, dataset_type: str = "cmeee") -> List[str]:
    """
    从数据集中构建本地知识图谱词汇表

    Args:
        data: 数据列表
        dataset_type: 数据集类型 ("cmeee" / "imcs")

    Returns:
        词汇表列表
    """
    vocab = set()

    if dataset_type == "cmeee":
        for item in data:
            for ent in item.get("entities", []):
                name = ent.get("entity", "").strip()
                if name:
                    vocab.add(name)

    elif dataset_type == "imcs":
        for item in data:
            for turn in item.get("dialogue", []):
                for norm in turn.get("symptom_norm", []):
                    if norm and norm.strip():
                        vocab.add(norm.strip())

    return sorted(list(vocab))
