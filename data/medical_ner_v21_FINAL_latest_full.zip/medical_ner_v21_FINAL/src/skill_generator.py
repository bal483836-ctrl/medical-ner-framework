"""
LLM Skill Generator - v20.2 新增

设计目标：
  让 LLM 看 30-50 条 (text, entities) 配对，归纳出操作性的 NER 提取技巧。
  这些 skills 拼进 Step 1 的 prompt 中，作为"师徒经验"指导 LLM 抽取。

关键设计：
  1. 缓存机制：第一次生成后存到 outputs/knowledge/llm_skills_{dataset}.json
     避免每次跑流水线都重调 LLM
  2. 回退机制：LLM 生成失败时，返回静态后备 skills（仍能跑通）
  3. 共享设计：CMeEE 和 IMCS 各自生成的 skills 都属于"提取技巧"
     IMCS 额外多一层"归一化技巧"，二者拼接

为什么要 LLM 生成而非静态规则？
  - 静态规则不知道数据集长什么样
  - LLM 看过样本后能产出"看到 X 模式则做 Y"这种数据感知规则
  - 写论文时可作为"meta-learning prompt construction"贡献点
"""
import json
import os
import re
from typing import List, Dict, Optional


# ==================== 静态后备 skills（LLM 失败时使用）====================

_FALLBACK_NER_SKILLS = """【技巧1】穷尽召回单字身体部位：原文出现独立的「血/心/肝/肺/肾/尿/胸/腹/脑」等单字时，作为 bod 抽出
【技巧2】整段抽取长描述：原文含 5 字以上的医学过程描述（如「血常规周围血白细胞计数可以增高」），整段作为一个 sym 实体
【技巧3】嵌套同抽：长实体若含 train 见过的医学短词且原文也独立出现，两者都抽（如"葡萄球菌肺炎"+"葡萄球菌"）
【技巧4】英文缩写保留：CT、ERCP、BUN、GFR、MRI、CRP、CTA、PCR 等英文缩写即使在中文文本中也作为独立实体抽出
【技巧5】前后缀模式：「急性 X」「慢性 X」「左侧/右侧/双侧 X」「亚急性 X」「先天性 X」整体作为 dis；后缀含「炎/症/病/癌/瘤」者整体作为 dis
【技巧6】指标类边界：心率、血压、血糖、体温、菌落数、肌张力、白细胞计数 → ite（指标），不是 sym
【技巧7】操作类边界：化疗、全身用药、针灸、原位杂交技术、血液透析 → pro（操作），不是 dru/sym
【技巧8】上位词不抽：单独出现的"疾病、症状、患者、并发症、情况、效果、原因、方法"不抽（这些是描述词不是实体）
【技巧9】否定 / 询问不抽：原文出现「不/没/没有/否认」+症状词时不抽该症状；问句中的症状词也不抽
【技巧10】边界精确：实体不带尾部"了/的/吗/啊/呢"，不带前缀"治疗/我们的/明显的"等修饰"""

_FALLBACK_NORM_SKILLS = """【技巧1】动词类口语映射：「拉 X」→ 腹泻；「流 X」→ 鼻流涕；「咳 X」→ 咳嗽；「吐 X」→ 呕吐
【技巧2】程度修饰词去除：「有点 X」「比较 X」「非常 X」「轻微 X」「严重 X」「持续 X」「反复 X」「偶尔 X」→ 去前缀
【技巧3】数字温度推断：体温 ≥39.1°C → 高热；38.1-39.0°C → 中等度热；37.3-38.0°C → 低热；只有"发烧/烧了"无数字时直接归"发热"
【技巧4】否定语境过滤：原文中口语词前后有「不/没/没有/未/否认」时，该症状不输出
【技巧5】询问句过滤：当前发言以「？」「呢」「吗」结尾且含症状词时，该症状不输出
【技巧6】同义合并：「精神不好/萎靡/没精神/烦躁不安」→ 精神软；「吃奶少/喂奶差/胃口不好」→ 食欲不振
【技巧7】子串映射：口语词含已知标准词时（如「流清鼻涕」含「鼻涕」相关）→ 取最长子串匹配的标准词
【技巧8】不凭医学常识猜测：仅当原文含口语描述时才输出对应标准词，不要从症状推断病因（"反复发烧" ≠ 细菌感染）"""


# ==================== Skill 生成器 ====================

class SkillGenerator:
    """用 LLM 从样本归纳 NER skills

    用法：
        gen = SkillGenerator(call_llm_func=call_llm)
        ner_skills = gen.generate_ner_skills(samples, dataset='cmeee', cache_path=...)
        norm_skills = gen.generate_normalization_skills(samples, cache_path=...)  # 仅 IMCS
    """

    def __init__(self, call_llm_func=None):
        """call_llm_func 是延迟注入的，避免本模块强依赖 LLM"""
        self.call_llm = call_llm_func
        self.timeout_seconds = 120  # LLM 生成 skills 的最大耐心

    # ---------- 提取 NER skills（CMeEE / IMCS 共用框架）----------

    def generate_ner_skills(
        self,
        samples: List[Dict],
        dataset: str,
        cache_path: Optional[str] = None,
        n_demo: int = 30,
        force_regenerate: bool = False,
    ) -> str:
        """
        Args:
            samples: 学习样本（带 entities 标注）
            dataset: 'cmeee' / 'imcs'
            cache_path: 缓存文件路径，若存在则直接读
            n_demo: 给 LLM 看的示例数（30 条左右是 prompt 长度的甜点区间）
            force_regenerate: 强制重新生成
        Returns:
            skills 文本，可直接拼进抽取 prompt
        """
        # 1. 尝试读缓存
        if cache_path and not force_regenerate and os.path.exists(cache_path):
            try:
                with open(cache_path, 'r', encoding='utf-8') as f:
                    cached = json.load(f)
                if cached.get('skills') and cached.get('dataset') == dataset:
                    print(f"  ✓ 复用缓存的 NER skills: {cache_path}")
                    return cached['skills']
            except Exception as e:
                print(f"  ⚠️ 缓存读取失败: {e}")

        # 2. 无 LLM 或调用失败时直接回退
        if self.call_llm is None:
            print(f"  ⚠️ call_llm 未注入，使用静态后备 skills")
            return _FALLBACK_NER_SKILLS.strip()

        # 3. 选择多样化样本作为 demo
        demos = self._select_diverse_demos(samples, dataset, n_demo)

        # 4. 构造元 prompt 让 LLM 归纳
        meta_prompt = self._build_ner_meta_prompt(demos, dataset)

        # 5. 调用 LLM
        try:
            print(f"  🤖 用 LLM 生成 {dataset} NER skills（看 {len(demos)} 条样本）...")
            raw_response = self.call_llm(meta_prompt, max_tokens=1024)
            skills = self._parse_skills_response(raw_response)
            if not skills or len(skills) < 50:
                raise ValueError("LLM 输出过短或解析失败")
        except Exception as e:
            print(f"  ⚠️ LLM 生成失败 ({e})，使用静态后备")
            skills = _FALLBACK_NER_SKILLS.strip()

        # 6. 写缓存
        if cache_path:
            try:
                os.makedirs(os.path.dirname(cache_path), exist_ok=True)
                with open(cache_path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'dataset': dataset,
                        'n_demo': len(demos),
                        'skills': skills,
                    }, f, ensure_ascii=False, indent=2)
                print(f"  💾 缓存写入: {cache_path}")
            except Exception as e:
                print(f"  ⚠️ 缓存写入失败: {e}")

        return skills

    # ---------- 归一化 skills（仅 IMCS）----------

    def generate_normalization_skills(
        self,
        samples: List[Dict],
        aligned_oral_to_norm: Dict[str, str],
        cache_path: Optional[str] = None,
        n_demo: int = 25,
        force_regenerate: bool = False,
    ) -> str:
        if cache_path and not force_regenerate and os.path.exists(cache_path):
            try:
                with open(cache_path, 'r', encoding='utf-8') as f:
                    cached = json.load(f)
                if cached.get('skills'):
                    print(f"  ✓ 复用缓存的归一化 skills: {cache_path}")
                    return cached['skills']
            except Exception:
                pass

        if self.call_llm is None:
            return _FALLBACK_NORM_SKILLS.strip()

        # 收集"口语 ≠ 标准词"的有教学价值样本
        teaching_pairs = self._collect_oralnorm_teaching_pairs(samples, n_demo)
        meta_prompt = self._build_norm_meta_prompt(teaching_pairs, aligned_oral_to_norm)

        try:
            print(f"  🤖 用 LLM 生成 IMCS 归一化 skills（看 {len(teaching_pairs)} 条对齐对）...")
            raw_response = self.call_llm(meta_prompt, max_tokens=1024)
            skills = self._parse_skills_response(raw_response)
            if not skills or len(skills) < 50:
                raise ValueError("LLM 输出过短")
        except Exception as e:
            print(f"  ⚠️ LLM 归一化 skills 生成失败 ({e})，使用静态后备")
            skills = _FALLBACK_NORM_SKILLS.strip()

        if cache_path:
            try:
                os.makedirs(os.path.dirname(cache_path), exist_ok=True)
                with open(cache_path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'n_demo': len(teaching_pairs),
                        'skills': skills,
                    }, f, ensure_ascii=False, indent=2)
            except Exception:
                pass

        return skills

    # ==================== 内部辅助 ====================

    def _select_diverse_demos(self, samples: List[Dict], dataset: str, n: int) -> List[Dict]:
        """选有教学价值的多样化样本"""
        scored = []
        for item in samples:
            score = 0
            if dataset == "cmeee":
                ents = [e for e in item.get("entities", []) if e.get("entity")]
                if not ents:
                    continue
                ent_names = [e["entity"] for e in ents]
                ent_types = set(e.get("type") for e in ents)
                # 嵌套 / 单字 / 多类型 / 长实体加分
                for i, e1 in enumerate(ent_names):
                    for j, e2 in enumerate(ent_names):
                        if i != j and e1 != e2 and e1 in e2:
                            score += 2
                            break
                if any(len(n) == 1 for n in ent_names):
                    score += 2
                if any(len(n) >= 8 for n in ent_names):
                    score += 3  # 长实体很有教学价值
                score += len(ent_types)
                tlen = len(item.get("text", ""))
                if 30 <= tlen <= 200:
                    score += 1
            else:  # imcs
                for turn in item.get("dialogue", []):
                    norms = [n for n in turn.get("symptom_norm", []) if n]
                    types = turn.get("symptom_type", [])
                    score += min(len(norms), 3)
                    # 口语 ≠ 标准词
                    sentence = turn.get("sentence", "")
                    for j, nm in enumerate(norms):
                        t = types[j] if j < len(types) else "1"
                        if t in ("1", "2") and nm and nm not in sentence:
                            score += 2
            scored.append((score, item))

        scored.sort(key=lambda x: -x[0])
        return [it for _, it in scored[:n]]

    def _collect_oralnorm_teaching_pairs(self, samples: List[Dict], n: int) -> List[Dict]:
        """收集"口语 ≠ 标准词"的对话片段作为归一化教学样本"""
        pairs = []
        for item in samples:
            for turn in item.get("dialogue", []):
                sentence = turn.get("sentence", "")
                norms = turn.get("symptom_norm", [])
                types = turn.get("symptom_type", [])
                kept_pairs = []
                for j, nm in enumerate(norms):
                    if not nm or not nm.strip():
                        continue
                    t = types[j] if j < len(types) else "1"
                    if t not in ("1", "2"):
                        continue
                    # 只收集差异样本
                    if nm not in sentence:
                        kept_pairs.append(nm)
                if kept_pairs:
                    pairs.append({
                        'sentence': sentence[:80],
                        'norms': kept_pairs,
                    })
                    if len(pairs) >= n:
                        return pairs
        return pairs

    def _build_ner_meta_prompt(self, demos: List[Dict], dataset: str) -> str:
        if dataset == "cmeee":
            ds_desc = "中文医学文献的 9 类实体识别"
            demo_lines = []
            for i, item in enumerate(demos[:20], 1):
                text = item.get("text", "")[:120]
                ents = item.get("entities", [])
                ent_strs = [f"{e['entity']}[{e['type']}]" for e in ents
                           if e.get('entity') and e.get('type')][:8]
                demo_lines.append(f"{i}. 原文: {text}\n   实体: {'; '.join(ent_strs)}")
        else:  # imcs
            ds_desc = "儿科医患对话中的症状识别（v20.3 起改为抽原文形态，不归一化）"
            demo_lines = []
            for i, item in enumerate(demos[:15], 1):
                turns_with_symp = []
                for turn in item.get("dialogue", []):
                    norms = [n for n in turn.get("symptom_norm", []) if n]
                    types = turn.get("symptom_type", [])
                    valid = [n for k, n in enumerate(norms)
                            if k < len(types) and types[k] in ("1", "2") and n]
                    if valid:
                        turns_with_symp.append(
                            f"     - {turn.get('sentence','')[:60]} → 标准词:{'、'.join(valid)}"
                        )
                if turns_with_symp:
                    demo_lines.append(f"{i}. 对话片段:\n" + "\n".join(turns_with_symp[:3]))

        demos_text = "\n\n".join(demo_lines)

        return f"""你是 NER 专家。仔细观察以下 {ds_desc} 标注样本，归纳出 6-10 条**可立即执行的抽取技巧**。

# 任务说明
观察样本中实体的标注模式，总结**"看到什么模式 → 应该做什么"**这种可直接指导 LLM 的判断规则。

# 样本
{demos_text}

# 输出要求

## 必须 6-10 条技巧，且每条必须满足
1. **具体可执行**——告诉 LLM 看到什么文本特征该怎么做，不能是抽象建议
2. **基于上述样本观察**——不能凭空写
3. **每条 1-2 句话**——不要长篇大论

## 优秀技巧示例
✅ "前后缀模式：看到「急性 X」、「慢性 X」、「左侧/右侧 X」时，整体作为 dis 实体抽出"
✅ "嵌套规则：长 dis 实体含 mic 词（如「葡萄球菌肺炎」含「葡萄球菌」）→ 两者都抽"
✅ "符号边界：英文缩写（CT、ERCP、BUN）即使在中文中也作为独立实体抽出"

## 拒绝的模糊技巧
❌ "应该仔细分析每个实体" （废话）
❌ "实体平均长度 4.2 字" （只是统计无操作性）
❌ "不要漏掉重要的实体" （没说怎么不漏）

# 输出格式
直接输出 6-10 条编号技巧，每条以"【技巧X】"开头描述模式名，然后冒号后说明具体怎么做。**不要任何前缀解释**：

【技巧1】..."""

    def _build_norm_meta_prompt(self, teaching_pairs: List[Dict],
                                  aligned_map: Dict[str, str]) -> str:
        pair_lines = []
        for i, p in enumerate(teaching_pairs[:20], 1):
            pair_lines.append(f"{i}. 对话: {p['sentence']}\n   标准症状: {'、'.join(p['norms'])}")

        align_lines = []
        for o, n in list(aligned_map.items())[:15]:
            align_lines.append(f"  {o} → {n}")

        return f"""你是医学术语归一化专家。观察以下儿科对话样本中"口语→标准词"的映射模式，归纳出**模式级**的归一化技巧。

# 任务背景
v20.3 起，IMCS 流水线分两阶段：(1) 从原文抽口语形态 (2) 后处理归一化为标准词。
你现在生成的技巧用于阶段 (2)——指导后处理算法或 LLM 判断如何把口语映射到标准词。

# 数据样本

## 口语 ≠ 标准词的对话样本
{chr(10).join(pair_lines)}

## 已通过算法对齐的口语映射
{chr(10).join(align_lines)}

# 任务：归纳 6-10 条模式级技巧

## 优秀技巧示例
✅ "动词类口语 → 标准词：「拉 X」→ 腹泻；「流 X」→ 鼻流涕；「咳 X」→ 咳嗽"
✅ "程度词去除：「有点 X」「严重 X」「老是 X」→ 去掉前缀的 X"
✅ "数字温度推断：38.5度 / 烧到 39 度 → 高热（≥39.1）/ 中等度热（38.1-39）/ 低热（37.3-38）"
✅ "否定语境识别：当口语前后含「不」「没」「没有」「未」时，该症状不输出"
✅ "询问句过滤：医生 turn 含「？」/「呢」/「吗」+症状词时，该症状不输出"

## 拒绝的模糊技巧
❌ "归一化时要严谨" （废话）
❌ "拉肚子→腹泻" （只是字典查询，不是模式）

# 输出格式
直接输出 6-10 条编号技巧，每条以"【技巧X】"开头：

【技巧1】..."""

    def _parse_skills_response(self, raw: str) -> str:
        """从 LLM 输出中提取干净的 skills 文本"""
        if not raw:
            return ""
        # 去除 think tag (Qwen3)
        raw = re.sub(r'<think>.*?</think>', '', raw, flags=re.DOTALL).strip()
        # 去除"以下是..."这种前缀
        raw = re.sub(r'^[^0-9]*?(?=\d+[\.\、])', '', raw)
        return raw.strip()
