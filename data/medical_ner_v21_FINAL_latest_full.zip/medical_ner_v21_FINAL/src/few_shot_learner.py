"""
预学习核心模块 - v20

设计目标：
  1. 真正"丰富"的预学习：从学习样本中自动提取 10+ 类知识
  2. 严格可追溯：所有规则均来自 train 集 5%（≤100条）的统计 / 对齐
  3. 替换 v19 中所有硬编码（特别是 IMCSPatternLearner._heuristic_mapping）
  4. 输出统一的 LearnedKnowledge 对象供整条流水线复用

学习的知识类别（CMeEE）：
  - 按类型的实体词表       entity_vocab_by_type
  - 按类型的长度分布       length_dist_by_type        (mean / std / p95)
  - 前缀修饰词             prefix_modifiers
  - 后缀修饰词             suffix_modifiers
  - 嵌套对                 nesting_pairs
  - 单字实体集合           single_char_entities
  - 类型共现频率           type_cooccurrence
  - 边界负面词             negative_words
  - Skill 参考样本         skill_refs

学习的知识类别（IMCS）：
  - 真正对齐学到的口语映射 aligned_oral_to_norm
    （核心修复：用编辑距离 + 字符重叠算法从 train 文本-标注对中挖掘
     而不是 v19 那种伪装成"自动学习"的硬编码字典）
  - 标准词表               norm_vocab
  - 每个标准词的口语变体   oral_variants_per_norm
  - 实体密度               entity_density
"""
import re
import os
import json
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Set, Tuple, Optional


# ==================== 通用工具 ====================

CN_PUNCT = set("，。；：、！？""''（）《》【】「」…—-·,.;:!?\"'()<>[]")
CN_FILLER = set("了的吗啊呢吧呀嘛哦哈哎咯哟")


def _char_set(s: str) -> Set[str]:
    return set(c for c in s if '\u4e00' <= c <= '\u9fff')


def _char_overlap(a: str, b: str) -> float:
    """两字符串的字符重叠率 (Jaccard on Chinese chars)"""
    sa, sb = _char_set(a), _char_set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


# ==================== 统一的学习结果对象 ====================

@dataclass
class LearnedKnowledge:
    dataset: str = ""
    n_learn_samples: int = 0

    # ---------- CMeEE ----------
    entity_vocab_by_type: Dict[str, List[str]] = field(default_factory=dict)
    length_dist_by_type: Dict[str, Dict[str, float]] = field(default_factory=dict)
    prefix_modifiers: List[str] = field(default_factory=list)
    suffix_modifiers: List[str] = field(default_factory=list)
    nesting_pairs: List[Tuple[str, str]] = field(default_factory=list)
    single_char_entities: List[str] = field(default_factory=list)
    type_cooccurrence: Dict[str, int] = field(default_factory=dict)
    avg_entity_length: float = 0.0
    single_char_ratio: float = 0.0
    min_expand_length: int = 2

    # ---------- IMCS ----------
    aligned_oral_to_norm: Dict[str, str] = field(default_factory=dict)
    norm_vocab: List[str] = field(default_factory=list)
    oral_variants_per_norm: Dict[str, List[str]] = field(default_factory=dict)
    entity_density: float = 0.0
    temperature_mention_examples: List[str] = field(default_factory=list)

    # ---------- 通用 ----------
    skill_refs: List[Dict] = field(default_factory=list)
    style_constraints: str = ""
    negative_words: List[str] = field(default_factory=list)

    # ---------- v20.2 新增：LLM 生成的 skills ----------
    learned_ner_skills: str = ""        # 从样本归纳的 NER 提取技巧（CMeEE+IMCS 各自一份）
    learned_norm_skills: str = ""       # 仅 IMCS：归一化技巧

    # ---------- v20.6 新增：类型校正用反向索引 ----------
    name_to_type_dist: Dict[str, Dict[str, int]] = field(default_factory=dict)
    # name → {type: count}，用于"如果一个词在 train 中绝大多数标 dis，那 LLM 标 sym 多半是错"

    def to_dict(self) -> dict:
        d = asdict(self)
        d['nesting_pairs'] = [list(p) for p in self.nesting_pairs]
        return d

    def save(self, path: str):
        import os
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)

    @property
    def all_entities(self) -> Set[str]:
        out = set()
        for ents in self.entity_vocab_by_type.values():
            out.update(ents)
        return out


# ==================== CMeEE 预学习 ====================

class CMeEELearner:
    _CANDIDATE_PREFIXES = ["急性", "慢性", "亚急性", "原发性", "继发性",
                           "左侧", "右侧", "双侧", "上行", "下行",
                           "先天性", "后天性"]
    _CANDIDATE_SUFFIXES = ["炎", "症", "病", "癌", "瘤", "术", "检查", "试验",
                           "综合征", "障碍", "畸形", "损伤", "疼痛"]

    def __init__(self, samples: List[dict]):
        self.samples = samples
        self.knowledge = LearnedKnowledge(dataset="cmeee", n_learn_samples=len(samples))

    def learn(self) -> LearnedKnowledge:
        self._learn_vocab_and_lengths()
        self._learn_modifiers()
        self._learn_nesting()
        self._learn_cooccurrence()
        self._learn_negative_words()
        self._learn_min_expand_length()
        self._build_constraints_text()
        return self.knowledge

    def _learn_vocab_and_lengths(self):
        vocab_by_type = defaultdict(set)
        lengths_by_type = defaultdict(list)
        all_lengths = []
        single_chars = set()
        name_to_types = defaultdict(Counter)  # v20.6: name → type counts

        for item in self.samples:
            for ent in item.get("entities", []):
                name = (ent.get("entity") or "").strip()
                etype = ent.get("type") or ""
                if not name or not etype:
                    continue
                vocab_by_type[etype].add(name)
                lengths_by_type[etype].append(len(name))
                all_lengths.append(len(name))
                if len(name) == 1:
                    single_chars.add(name)
                name_to_types[name][etype] += 1

        # v20.6: 存反向索引（仅保留出现 >= 1 的）
        self.knowledge.name_to_type_dist = {
            n: dict(types) for n, types in name_to_types.items()
        }
        self.knowledge.entity_vocab_by_type = {k: sorted(v) for k, v in vocab_by_type.items()}
        self.knowledge.length_dist_by_type = {
            k: {
                "mean": round(statistics.mean(v), 2),
                "std": round(statistics.stdev(v), 2) if len(v) > 1 else 0.0,
                "p95": int(sorted(v)[int(len(v) * 0.95)]) if v else 0,
                "max": max(v) if v else 0,
                "count": len(v),
            }
            for k, v in lengths_by_type.items()
        }
        self.knowledge.avg_entity_length = round(statistics.mean(all_lengths), 2) if all_lengths else 0.0
        all_unique = self.knowledge.all_entities
        self.knowledge.single_char_ratio = round(len(single_chars) / len(all_unique), 4) if all_unique else 0.0
        self.knowledge.single_char_entities = sorted(single_chars)

    def _learn_modifiers(self):
        all_entities = self.knowledge.all_entities
        prefix_freq = Counter()
        suffix_freq = Counter()

        for ent in all_entities:
            for p in self._CANDIDATE_PREFIXES:
                if ent.startswith(p) and len(ent) > len(p):
                    prefix_freq[p] += 1
            for s in self._CANDIDATE_SUFFIXES:
                if ent.endswith(s) and len(ent) > len(s):
                    suffix_freq[s] += 1

        self.knowledge.prefix_modifiers = [p for p, c in prefix_freq.most_common() if c >= 2]
        self.knowledge.suffix_modifiers = [s for s, c in suffix_freq.most_common() if c >= 2]

    def _learn_nesting(self):
        pairs = set()
        for item in self.samples:
            ent_names = list({(e.get("entity") or "").strip()
                              for e in item.get("entities", [])
                              if (e.get("entity") or "").strip()})
            for i, e1 in enumerate(ent_names):
                for j, e2 in enumerate(ent_names):
                    if i != j and e1 != e2 and e1 in e2 and len(e1) >= 1:
                        pairs.add((e2, e1))
        self.knowledge.nesting_pairs = sorted(pairs)[:30]

    def _learn_cooccurrence(self):
        cooccur = Counter()
        for item in self.samples:
            types = list({e.get("type") for e in item.get("entities", []) if e.get("type")})
            for i, t1 in enumerate(types):
                for t2 in types[i + 1:]:
                    cooccur["+".join(sorted([t1, t2]))] += 1
        self.knowledge.type_cooccurrence = dict(cooccur.most_common(20))

    def _learn_negative_words(self):
        non_entity_words = Counter()
        for item in self.samples:
            text = item.get("text", "")
            ent_names = [(e.get("entity") or "") for e in item.get("entities", [])]
            tmp = text
            for n in sorted(set(ent_names), key=len, reverse=True):
                if n:
                    tmp = tmp.replace(n, " [E] ")
            for m in re.finditer(r'[\u4e00-\u9fff]{2,4}', tmp):
                non_entity_words[m.group()] += 1
        all_entity_chars = self.knowledge.all_entities
        self.knowledge.negative_words = [
            w for w, c in non_entity_words.most_common(30)
            if c >= 3 and w not in all_entity_chars
        ][:15]

    def _learn_min_expand_length(self):
        self.knowledge.min_expand_length = (
            1 if self.knowledge.single_char_ratio > 0.05 else 2
        )

    def _build_constraints_text(self):
        k = self.knowledge
        lines = [f"【从学习样本（{k.n_learn_samples}条）中自动提取的 CMeEE 标注规范】"]

        type_summary = ", ".join(
            f"{t}({d['count']}条/均长{d['mean']}字)"
            for t, d in k.length_dist_by_type.items()
        )
        lines.append(f"• 类型分布：{type_summary}")

        if k.prefix_modifiers:
            lines.append(f"• 常见前缀修饰：{ '、'.join(k.prefix_modifiers[:8]) }（应连同实体一起提取）")
        if k.suffix_modifiers:
            lines.append(f"• 常见后缀指示：{ '、'.join(k.suffix_modifiers[:8]) }")

        if k.nesting_pairs:
            sample_pairs = "、".join(f"{a}∈{b}" for b, a in k.nesting_pairs[:3])
            lines.append(f"• 嵌套模式：发现 {len(k.nesting_pairs)} 对嵌套，例如 {sample_pairs}")
            lines.append(f"  → 抽取时若长实体含已知短实体，请同时输出两者")

        if k.single_char_ratio > 0.05:
            lines.append(f"• 单字实体占比 {k.single_char_ratio:.1%}（如{ '、'.join(k.single_char_entities[:5]) }），允许提取")
        else:
            lines.append(f"• 单字实体占比 {k.single_char_ratio:.1%}，原则上不提取单字")

        if k.negative_words:
            lines.append(f"• 严禁提取以下高频非实体词：{ '、'.join(k.negative_words[:10]) }")

        k.style_constraints = "\n".join(lines)


# ==================== IMCS 预学习 ====================

class IMCSLearner:
    """关键修复：用真正的对齐算法挖掘口语→标准词映射。"""

    def __init__(self, samples: List[dict]):
        self.samples = samples
        self.knowledge = LearnedKnowledge(dataset="imcs", n_learn_samples=len(samples))

    def learn(self) -> LearnedKnowledge:
        self._learn_norm_vocab()
        self._mine_oral_norm_alignment()
        self._collect_temperature_examples()
        self._compute_density()
        self._build_constraints_text()
        return self.knowledge

    def _learn_norm_vocab(self):
        norms = set()
        for item in self.samples:
            for turn in item.get("dialogue", []):
                for n in turn.get("symptom_norm", []):
                    if n and n.strip():
                        norms.add(n.strip())
        self.knowledge.norm_vocab = sorted(norms)

    def _mine_oral_norm_alignment(self):
        """从 (sentence, symptom_norm) 对中挖掘口语→标准词映射 - v20.1 增强

        算法升级：
          1. 窗口扩到 2-7 字（覆盖"流清鼻涕"、"拉稀屎"等长口语）
          2. 阈值降到 0.25（更多召回）
          3. 多 norm 同句时去重（避免同一口语映射多个 norm）
          4. 同时收集"完全包含"型映射（如句中"流鼻涕"对应"鼻流涕"）
          5. 整词匹配优先（"鼻涕" → "鼻流涕"，比 char-overlap 简单的"鼻涕"->其他更可靠）
        """
        pair_count = Counter()
        per_norm_orals = defaultdict(Counter)

        for item in self.samples:
            for turn in item.get("dialogue", []):
                sentence = turn.get("sentence", "")
                norms = [n for n in turn.get("symptom_norm", []) if n and n.strip()]
                if not sentence or not norms:
                    continue

                # 仅处理只有 1-2 个 norm 的轮次（多 norm 时对齐不可靠）
                if len(norms) > 2:
                    continue

                for norm in norms:
                    if norm in sentence:
                        continue

                    # ---------- 候选 1：char-overlap 滑动窗口 ----------
                    best_oral, best_score = None, 0.0
                    for w in range(2, 8):
                        if w > len(sentence):
                            break
                        for i in range(len(sentence) - w + 1):
                            cand = sentence[i:i + w]
                            if any(c in CN_PUNCT or c in CN_FILLER or c.isdigit() for c in cand):
                                continue
                            if not all('\u4e00' <= c <= '\u9fff' for c in cand):
                                continue
                            overlap = _char_overlap(cand, norm)
                            length_penalty = 0.10 * abs(len(cand) - len(norm))
                            score = overlap - length_penalty
                            if score > best_score:
                                best_oral, best_score = cand, score

                    # ---------- 候选 2：char-set 包含（"鼻涕" 在 "流清鼻涕" 中等）----------
                    # 找句中包含 norm 一半以上字符的 2-6 字短语
                    n_chars = _char_set(norm)
                    if len(n_chars) >= 2:
                        for w in range(2, 7):
                            for i in range(len(sentence) - w + 1):
                                cand = sentence[i:i + w]
                                if any(c in CN_PUNCT or c in CN_FILLER for c in cand):
                                    continue
                                if not all('\u4e00' <= c <= '\u9fff' for c in cand):
                                    continue
                                c_chars = _char_set(cand)
                                shared = len(c_chars & n_chars)
                                if shared >= max(2, len(n_chars) - 1):
                                    score2 = shared / max(len(c_chars), len(n_chars)) - 0.05
                                    if score2 > best_score:
                                        best_oral, best_score = cand, score2

                    if best_oral and best_score >= 0.25:
                        pair_count[(best_oral, norm)] += 1
                        per_norm_orals[norm][best_oral] += 1

        # 一个口语只映射到出现次数最多的标准词
        # 但如果某口语映射到的 (norm, count) 比次优大幅领先才记录
        oral_norm_candidates = defaultdict(list)
        for (oral, norm), c in pair_count.items():
            oral_norm_candidates[oral].append((norm, c))

        cleaned_map = {}
        for oral, candidates in oral_norm_candidates.items():
            candidates.sort(key=lambda x: -x[1])
            if len(candidates) == 1:
                cleaned_map[oral] = candidates[0][0]
            elif candidates[0][1] >= candidates[1][1] * 1.5:  # 显著领先
                cleaned_map[oral] = candidates[0][0]
            # 否则不要这个映射（可能是噪声）

        self.knowledge.aligned_oral_to_norm = cleaned_map
        self.knowledge.oral_variants_per_norm = {
            norm: [oral for oral, _ in orals.most_common(5)]
            for norm, orals in per_norm_orals.items() if orals
        }

    def _collect_temperature_examples(self):
        temp_pattern = re.compile(r'\d{2}\.?\d?\s*[°℃度]')
        examples = []
        for item in self.samples:
            for turn in item.get("dialogue", []):
                s = turn.get("sentence", "")
                if temp_pattern.search(s):
                    examples.append(s)
                    if len(examples) >= 5:
                        return
        self.knowledge.temperature_mention_examples = examples

    def _compute_density(self):
        total_turns = 0
        turns_with_norm = 0
        for item in self.samples:
            for turn in item.get("dialogue", []):
                total_turns += 1
                if any(n and n.strip() for n in turn.get("symptom_norm", [])):
                    turns_with_norm += 1
        self.knowledge.entity_density = round(
            turns_with_norm / total_turns, 4) if total_turns else 0.0

    def _build_constraints_text(self):
        k = self.knowledge
        lines = [f"【从学习样本（{k.n_learn_samples}条对话）中自动提取的 IMCS 标注规范】"]
        lines.append(f"• 标准症状词表大小：{len(k.norm_vocab)}")
        lines.append(f"• 含症状轮次比例：{k.entity_density:.1%}（其余轮次输出空）")
        lines.append("• 必须将口语描述归一化为标准医学术语（不输出口语原词）")

        if k.aligned_oral_to_norm:
            sample = list(k.aligned_oral_to_norm.items())[:8]
            mapping_str = "、".join(f"{o}→{n}" for o, n in sample)
            lines.append(f"• 自动对齐的口语映射（共 {len(k.aligned_oral_to_norm)} 条）：{mapping_str}")

        if k.temperature_mention_examples:
            lines.append("• 温度推断：体温≥37.3°C 应推断为发热（《诊断学》第9版）")

        k.style_constraints = "\n".join(lines)


# ==================== Skill 参考样本智能选择 ====================

class SkillRefSelector:

    @staticmethod
    def select_cmeee(samples: List[dict], n: int = 5) -> List[dict]:
        scored = []
        for item in samples:
            ents = [e for e in item.get("entities", []) if e.get("entity")]
            if not ents:
                continue
            ent_names = [e["entity"] for e in ents]
            ent_types = set(e.get("type") for e in ents if e.get("type"))

            score = 0
            for i, e1 in enumerate(ent_names):
                for j, e2 in enumerate(ent_names):
                    if i != j and e1 != e2 and e1 in e2:
                        score += 3
                        break
            if any(len(n) == 1 for n in ent_names):
                score += 2
            score += len(ent_types)
            tlen = len(item.get("text", ""))
            if 30 <= tlen <= 150:
                score += 2

            scored.append((score, item))

        scored.sort(key=lambda x: -x[0])
        return [it for _, it in scored[:n]]

    @staticmethod
    def select_imcs(samples: List[dict], n: int = 5) -> List[dict]:
        temp_re = re.compile(r'\d{2}\.?\d?\s*[°℃度]')
        scored = []
        for item in samples:
            score = 0
            n_norms = 0
            has_temp = False
            has_oral_diff = False
            for turn in item.get("dialogue", []):
                s = turn.get("sentence", "")
                norms = [x for x in turn.get("symptom_norm", []) if x]
                n_norms += len(norms)
                if temp_re.search(s):
                    has_temp = True
                for nm in norms:
                    if nm and nm not in s:
                        has_oral_diff = True
                        break

            if has_temp: score += 4
            if has_oral_diff: score += 3
            score += min(n_norms, 5)
            if 5 <= len(item.get("dialogue", [])) <= 25:
                score += 2

            scored.append((score, item))

        scored.sort(key=lambda x: -x[0])
        return [it for _, it in scored[:n]]


# ==================== 对外统一入口 ====================

class FewShotLearner:
    """对外统一入口（保持与 v19 调用兼容）"""

    def learn(self, learn_samples: List[dict], dataset_name: str,
              n_skill_refs: int = 5,
              full_alignment_samples: Optional[List[dict]] = None,
              call_llm_func=None,
              skill_cache_dir: Optional[str] = None,
              force_regenerate_skills: bool = False) -> LearnedKnowledge:
        """
        learn_samples: 5%学习样本（≤100），用于学统计、style 等
        full_alignment_samples: 可选——全集 train（仅 IMCS 用）做口语对齐
        call_llm_func: 可选——传入 call_llm 即启用 v20.2 LLM 生成 skills
        skill_cache_dir: 缓存目录，默认 outputs/knowledge
        force_regenerate_skills: 强制重新调 LLM 生成 skills（默认读缓存）
        """
        if dataset_name == "cmeee":
            knowledge = CMeEELearner(learn_samples).learn()
            knowledge.skill_refs = SkillRefSelector.select_cmeee(learn_samples, n_skill_refs)
        elif dataset_name == "imcs":
            knowledge = IMCSLearner(learn_samples).learn()
            knowledge.skill_refs = SkillRefSelector.select_imcs(learn_samples, n_skill_refs)
            # 用全集再跑一次对齐，覆盖 5% 样本的对齐结果
            if full_alignment_samples is not None:
                print(f"  🔬 用全集 {len(full_alignment_samples)} 条做口语对齐（替换 5% 样本对齐）")
                full_learner = IMCSLearner(full_alignment_samples)
                full_learner._learn_norm_vocab()
                full_learner._mine_oral_norm_alignment()
                knowledge.norm_vocab = full_learner.knowledge.norm_vocab
                knowledge.aligned_oral_to_norm = full_learner.knowledge.aligned_oral_to_norm
                knowledge.oral_variants_per_norm = full_learner.knowledge.oral_variants_per_norm
                full_learner.knowledge.entity_density = knowledge.entity_density
                full_learner.knowledge.temperature_mention_examples = knowledge.temperature_mention_examples
                full_learner.knowledge.n_learn_samples = knowledge.n_learn_samples
                full_learner._build_constraints_text()
                knowledge.style_constraints = full_learner.knowledge.style_constraints
        else:
            knowledge = LearnedKnowledge(dataset=dataset_name, n_learn_samples=len(learn_samples))
            return knowledge

        # ============ v20.2：用 LLM 生成 skills ============
        # 即使 call_llm_func 为 None，generate_* 也会回退到静态 skills
        try:
            from src.skill_generator import SkillGenerator
            gen = SkillGenerator(call_llm_func=call_llm_func)

            cache_dir = skill_cache_dir
            if cache_dir is None:
                from config.config import OUTPUT_DIR
                cache_dir = os.path.join(OUTPUT_DIR, "knowledge")

            ner_cache = os.path.join(cache_dir, f"llm_ner_skills_{dataset_name}.json")
            knowledge.learned_ner_skills = gen.generate_ner_skills(
                learn_samples, dataset_name, ner_cache,
                force_regenerate=force_regenerate_skills,
            )

            if dataset_name == "imcs":
                norm_cache = os.path.join(cache_dir, "llm_norm_skills_imcs.json")
                # 归一化用全集样本（如果有），更全面
                norm_samples = full_alignment_samples if full_alignment_samples else learn_samples
                knowledge.learned_norm_skills = gen.generate_normalization_skills(
                    norm_samples, knowledge.aligned_oral_to_norm, norm_cache,
                    force_regenerate=force_regenerate_skills,
                )
        except Exception as e:
            print(f"  ⚠️ Skill 生成完全失败: {e}（继续，仅缺 LLM skills）")

        return knowledge

    # ---- 兼容 v19 旧接口（防止老代码 import 报错）----

    def learn_style(self, learn_samples: list, dataset_name: str) -> str:
        return self.learn(learn_samples, dataset_name).style_constraints

    def get_skills(self, samples: list, n_skills: int = 5) -> str:
        refs = SkillRefSelector.select_cmeee(samples, n_skills)
        out = []
        for i, item in enumerate(refs, 1):
            text = item.get("text", "")
            ents = item.get("entities", [])
            ent_str = "; ".join(
                f"{e.get('entity', '')}[{e.get('type', '')}]"
                for e in ents if e.get("entity")
            )
            out.append(f"示例{i}\n原文：{text}\n实体：{ent_str}")
        return "\n\n".join(out)

    def learn_dataset_patterns(self, dataset_name: str, learn_samples: list) -> dict:
        k = self.learn(learn_samples, dataset_name)
        return {
            "prompt_constraints": k.style_constraints,
            "min_expand_length": k.min_expand_length,
            "single_char_ratio": k.single_char_ratio,
            "avg_entity_length": k.avg_entity_length,
            "learned_entity_set": list(k.all_entities),
            "learned_oral_map": k.aligned_oral_to_norm,
            "norm_vocab_from_samples": k.norm_vocab,
        }
