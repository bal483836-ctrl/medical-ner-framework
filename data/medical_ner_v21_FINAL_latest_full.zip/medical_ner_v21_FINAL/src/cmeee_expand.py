"""
Step 1.5 - CMeEE 词汇扩展 - v20

设计原则：
  1. 不使用任何硬编码黑名单
  2. min_expand_length 由 LearnedKnowledge.min_expand_length 决定
  3. 独立性检查是通用语言学规则
"""
import re
from typing import List, Set


def is_independent_in_text(word: str, text: str, existing_entities: Set[str]) -> bool:
    """检查一个词在原文中是否独立出现（非更长实体的子串）"""
    if word not in text:
        return False

    if len(word) <= 3:
        for ent in existing_entities:
            if len(ent) > len(word) and word in ent and ent in text:
                return False

    start = 0
    while True:
        idx = text.find(word, start)
        if idx == -1:
            break
        before = text[idx - 1] if idx > 0 else ""
        after = text[idx + len(word)] if idx + len(word) < len(text) else ""
        b_cjk = bool(re.match(r'[\u4e00-\u9fff]', before)) if before else False
        a_cjk = bool(re.match(r'[\u4e00-\u9fff]', after)) if after else False
        if not b_cjk or not a_cjk:
            return True
        start = idx + 1
    return False


def enrich_step1_with_expansion(
    data: list,
    vocab_set: Set[str],
    min_expand_length: int = 2,
    long_word_min_len: int = 5,
) -> list:
    """对 Step1 的 CMeEE 结果进行词表扩展

    策略：
      - 长词 (>=long_word_min_len)：直接扫原文，命中即加
      - 中等词 (min_expand_length ~ long_word_min_len-1)：需通过独立性检查
      - 短词 (<min_expand_length)：跳过
    """
    expanded_count = 0

    for item in data:
        text = item.get("text", "")
        if not text:
            item['step1_enriched_output'] = item.get('step1_raw_output', '')
            continue

        existing_str = item.get('step1_raw_output', '')
        existing_entities = set(s.strip() for s in existing_str.split(",") if s.strip())

        new_entities = set()

        for vocab_word in vocab_set:
            if not vocab_word or vocab_word in existing_entities:
                continue
            if re.match(r'^[\d\s\W]+$', vocab_word):
                continue

            wlen = len(vocab_word)
            if wlen < min_expand_length:
                continue

            if vocab_word not in text:
                continue

            if wlen < long_word_min_len:
                if is_independent_in_text(vocab_word, text, existing_entities):
                    new_entities.add(vocab_word)
            else:
                new_entities.add(vocab_word)

        all_entities = existing_entities | new_entities
        all_entities.discard("")
        item['step1_enriched_output'] = ",".join(sorted(all_entities))

        if new_entities:
            expanded_count += 1

    print(f"  📊 词汇表扩展: {expanded_count}/{len(data)} 条样本被扩展 "
          f"(min_len={min_expand_length}, long_min={long_word_min_len})")
    return data
