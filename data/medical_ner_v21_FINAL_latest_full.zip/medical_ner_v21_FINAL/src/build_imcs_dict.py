import json
import os
from collections import Counter


def build_imcs_dictionary(file_paths, output_dir):
    """从 IMCS 的多个数据分割（train/dev/test）中构建完整归一化词典。"""
    oral_to_norm = {}
    norm_vocab = Counter()

    common_mappings = {
        "发热": ["发烧", "烧了", "体温高", "热度"],
        "咳嗽": ["咳", "嗓子痒"],
        "腹泻": ["拉肚子", "拉稀", "大便稀"],
        "腹痛": ["肚子疼", "胃疼", "肚子难受"],
        "呕吐": ["吐了", "喷奶"],
    }

    try:
        for path in file_paths:
            if not os.path.exists(path):
                print(f"⚠️ 警告: 跳过不存在的文件 {path}")
                continue

            print(f"正在处理: {path}")
            data = []
            with open(path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    continue
                if content.startswith("["):
                    try:
                        data = json.loads(content)
                    except json.JSONDecodeError:
                        for line in content.split("\n"):
                            if line.strip():
                                data.append(json.loads(line))
                else:
                    for line in content.split("\n"):
                        if line.strip():
                            data.append(json.loads(line))

            for item in data:
                dialogue = item.get("dialogue", [])
                for turn in dialogue:
                    sentence = turn.get("sentence", "")
                    norms = turn.get("symptom_norm", []) or []
                    if isinstance(norms, str):
                        norms = [norms]

                    for norm in norms:
                        if not norm:
                            continue
                        norm_vocab[norm] += 1
                        for std, orals in common_mappings.items():
                            if norm == std:
                                for oral in orals:
                                    if oral in sentence:
                                        oral_to_norm[oral] = std

        os.makedirs(output_dir, exist_ok=True)
        with open(os.path.join(output_dir, "imcs_oral_to_norm.json"), "w", encoding="utf-8") as f:
            json.dump(oral_to_norm, f, ensure_ascii=False, indent=2)
        with open(os.path.join(output_dir, "imcs_norm_vocab.json"), "w", encoding="utf-8") as f:
            json.dump(list(norm_vocab.keys()), f, ensure_ascii=False, indent=2)

        print("✅ 词典构建完成！")
        print(f"   - 发现口语映射: {len(oral_to_norm)} 条")
        print(f"   - 标准词库规模: {len(norm_vocab)} 个")
        return oral_to_norm, norm_vocab
    except Exception as e:
        print(f"❌ 词典构建失败: {e}")
        raise


if __name__ == "__main__":
    DATA_ROOT = "/root/autodl-tmp/MedNER_Project/new_data/IMCS_V2"
    FILE_PATHS = [
        os.path.join(DATA_ROOT, "IMCS_V2_train_new.json"),
        os.path.join(DATA_ROOT, "IMCS_V2_dev_new.json"),
        os.path.join(DATA_ROOT, "IMCS_V2_test_new.json"),
    ]
    OUTPUT_DIR = "/home/ubuntu/medical_ner_project/medical_ner_v3_optimized/data/dicts"
    build_imcs_dictionary(FILE_PATHS, OUTPUT_DIR)
