"""
归一化 + 评估模块 - v20-P2

v20.0 → v20.1 修复：
  B5 - IMCS 字面F1=归一化F1：
    根因：评估端的归一化只做 1 级（oral_map.get），
    没有用 filter_hallucinations 中的 4 级降级。
    现在：评估端也调用 normalize_imcs_entity，与 step3 完全一致

补齐 final_validate 引用的 6 个函数（v19 中均缺失）：
  compute_f1_from_lists / evaluate_imcs_raw / evaluate_imcs_normalized
  print_evaluation_report / _build_full_oral_map / generate_error_analysis
"""
import json
import os
import sys
from collections import Counter
from typing import List, Dict, Tuple, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import OUTPUT_DIR, IMCS_TARGET_SYMPTOM_TYPES


# ==================== F1 计算 ====================

def compute_f1(tp: int, fp: int, fn: int) -> Tuple[float, float, float]:
    p = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    r = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * p * r / (p + r) if (p + r) > 0 else 0.0
    return p, r, f1


def compute_f1_from_lists(gold_list: List[set], pred_list: List[set]) -> Dict:
    tp = fp = fn = 0
    per_sample_f1 = []
    for gold, pred in zip(gold_list, pred_list):
        c_tp = len(gold & pred)
        c_fp = len(pred - gold)
        c_fn = len(gold - pred)
        tp += c_tp
        fp += c_fp
        fn += c_fn
        _, _, f1 = compute_f1(c_tp, c_fp, c_fn)
        per_sample_f1.append(f1)

    p, r, micro = compute_f1(tp, fp, fn)
    macro = sum(per_sample_f1) / len(per_sample_f1) if per_sample_f1 else 0.0
    return {
        "tp": tp, "fp": fp, "fn": fn,
        "precision": p, "recall": r,
        "micro_f1": micro, "macro_f1": macro,
        "n_samples": len(gold_list),
    }


def print_evaluation_report(name: str, result: Dict):
    print(f"\n{'=' * 60}")
    print(f"【{name} 评估报告】")
    print(f"{'=' * 60}")
    print(f"  样本数: {result['n_samples']}")
    print(f"  TP={result['tp']}  FP={result['fp']}  FN={result['fn']}")
    print(f"  Precision: {result['precision']:.4f}")
    print(f"  Recall:    {result['recall']:.4f}")
    print(f"  Micro F1:  {result['micro_f1']:.4f}")
    print(f"  Macro F1:  {result['macro_f1']:.4f}")


# ==================== 字典加载 ====================

def _build_full_oral_map() -> Dict[str, str]:
    from src.kg_alignment import get_oral_to_standard_map
    return dict(get_oral_to_standard_map())


# ==================== CMeEE ====================

def evaluate_cmeee(data: list, pred_field: str = None) -> float:
    """字符串集合 F1（向后兼容）"""
    gold_list, pred_list = [], []
    for item in data:
        gold = set(s.strip() for s in item.get("gold_entities_str", "").split(",") if s.strip())

        if pred_field:
            pred_str = item.get(pred_field, "")
        else:
            pred_str = (item.get("step3_final_output")
                        or item.get("step1_enriched_output")
                        or item.get("step1_raw_output", ""))
        pred = set(s.strip() for s in pred_str.split(",") if s.strip())

        gold_list.append(gold)
        pred_list.append(pred)

    result = compute_f1_from_lists(gold_list, pred_list)
    print_evaluation_report("CMeEE (字符串集合 F1)", result)
    return result["micro_f1"]


def evaluate_cmeee_span_level(data: list, pred_field: str = "step3_entities") -> float:
    """v20.4: CBLUE 官方 span-level F1
    
    用 (start_idx, end_idx, type) 三元组精确匹配。
    同名实体在不同位置算不同实例——这是 CMeEE 提交平台的真实评估口径。
    """
    gold_list, pred_list = [], []
    for item in data:
        gold = set()
        for e in item.get("entities", []):
            if 'start_idx' in e and 'end_idx' in e and 'type' in e:
                gold.add((e['start_idx'], e['end_idx'], e['type']))

        pred = set()
        for e in item.get(pred_field, []):
            if isinstance(e, dict) and 'start_idx' in e and 'end_idx' in e and 'type' in e:
                pred.add((e['start_idx'], e['end_idx'], e['type']))

        gold_list.append(gold)
        pred_list.append(pred)

    result = compute_f1_from_lists(gold_list, pred_list)
    print_evaluation_report("CMeEE (span-level F1, CBLUE 官方口径)", result)
    return result["micro_f1"]


def evaluate_cmeee_dual(data: list, pred_field_str: str = "step3_final_output",
                         pred_field_span: str = "step3_entities") -> Dict:
    """v20.4: 同时报告字符串集合 F1 和 span-level F1"""
    print("\n--- CMeEE 双指标评估 ---")
    f1_str = evaluate_cmeee(data, pred_field_str)
    f1_span = evaluate_cmeee_span_level(data, pred_field_span)
    return {"string_f1": f1_str, "span_f1": f1_span}


# ==================== IMCS ====================

def _imcs_get_gold(item: dict) -> set:
    golds = set()
    for turn in item.get("dialogue", []):
        norms = turn.get("symptom_norm", [])
        types = turn.get("symptom_type", [])
        for i, n in enumerate(norms):
            if not n or not n.strip():
                continue
            stype = types[i] if i < len(types) else "1"
            if stype in IMCS_TARGET_SYMPTOM_TYPES:
                golds.add(n.strip())
    return golds


def _imcs_get_pred(item: dict, use_norm: bool, pred_field: Optional[str] = None) -> set:
    """v20.1 修复：use_norm=True 时使用 4 级降级"""
    if pred_field:
        pred_str = item.get(pred_field, "")
    else:
        pred_str = item.get("step3_final_output") or item.get("step1_raw_output", "")
    raw_preds = [s.strip() for s in pred_str.split(",") if s.strip()]

    if not use_norm:
        return set(raw_preds)

    # 用 filter_hallucinations 同款 4 级降级
    from src.filter_hallucinations import normalize_imcs_entity
    from src.kg_alignment import get_oral_to_standard_map, build_imcs_norm_vocab

    oral_map = get_oral_to_standard_map()
    norm_vocab = set(build_imcs_norm_vocab())

    out = set()
    for p in raw_preds:
        # learned_oral_map 在评估端无法复用 (因为 knowledge 不在这里)
        # 评估端只用数据集自带 oral_map
        normed = normalize_imcs_entity(p, oral_map, {}, norm_vocab)
        if normed:
            out.add(normed)
    return out


def evaluate_imcs(data: list, use_norm: bool = False,
                  pred_field: Optional[str] = None) -> float:
    gold_list, pred_list = [], []
    for item in data:
        gold_list.append(_imcs_get_gold(item))
        pred_list.append(_imcs_get_pred(item, use_norm, pred_field))

    result = compute_f1_from_lists(gold_list, pred_list)
    print_evaluation_report(f"IMCS ({'归一化后' if use_norm else '字面'})", result)
    return result["micro_f1"]


def evaluate_imcs_raw(data: list, pred_field: Optional[str] = None) -> float:
    return evaluate_imcs(data, use_norm=False, pred_field=pred_field)


def evaluate_imcs_normalized(data: list, pred_field: Optional[str] = None) -> float:
    return evaluate_imcs(data, use_norm=True, pred_field=pred_field)


# ==================== 错误分析 ====================

def generate_error_analysis(data: list, dataset: str, top_n: int = 20,
                             pred_field: Optional[str] = None) -> Dict:
    fp_counter = Counter()
    fn_counter = Counter()

    for item in data:
        if dataset == "cmeee":
            gold = set(s.strip() for s in item.get("gold_entities_str", "").split(",")
                       if s.strip())
            pred_str = (item.get(pred_field) if pred_field else
                        (item.get("step3_final_output") or
                         item.get("step1_enriched_output") or
                         item.get("step1_raw_output", "")))
            pred = set(s.strip() for s in pred_str.split(",") if s.strip())
        else:
            gold = _imcs_get_gold(item)
            pred = _imcs_get_pred(item, use_norm=True, pred_field=pred_field)

        fp_counter.update(pred - gold)
        fn_counter.update(gold - pred)

    print(f"\n--- {dataset.upper()} 错误分析 ---")
    print(f"\nTop-{top_n} False Positive：")
    for w, c in fp_counter.most_common(top_n):
        print(f"  {c:4d}  {w}")
    print(f"\nTop-{top_n} False Negative：")
    for w, c in fn_counter.most_common(top_n):
        print(f"  {c:4d}  {w}")

    return {
        "top_fp": fp_counter.most_common(top_n),
        "top_fn": fn_counter.most_common(top_n),
    }
