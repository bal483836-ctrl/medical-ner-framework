"""
数据集自动检测器 - v21

设计目标：
  统一接口下，从数据集字段格式自动判断数据集类型，
  并提供"取文本 / 取标注 / 抽 gold"等统一操作。

字段格式启发规则（按优先级匹配）：
  - 顶层有 'dialogue' 字段 → IMCS（对话型）
  - 顶层有 'entities' 字段且 entity 含 'type' → CMeEE 或 Yidu
    - type 值是 'dis','sym','pro' 等 9 类缩写 → CMeEE
    - type 值是 'Disease and Diagnosis' 等英文 → Yidu
  - 顶层有 'text' 但无 entities → 推断的纯文本数据集

每条数据返回一个 DataItem 对象，封装所有差异。
"""
import re
from dataclasses import dataclass, field
from typing import List, Dict, Set, Optional, Tuple, Any
from collections import Counter


# ==================== 数据集类型枚举 ====================

DATASET_CMEEE = "cmeee"
DATASET_IMCS  = "imcs"
DATASET_YIDU  = "yidu"
DATASET_UNKNOWN = "unknown"


# CMeEE 类型集合
_CMEEE_TYPES = {"dis", "sym", "pro", "equ", "dru", "ite", "bod", "mic", "dep"}
# Yidu 类型集合
_YIDU_TYPES = {
    "Disease and Diagnosis", "Imaging", "Laboratory", "Medicine",
    "Anatomy", "Operation"
}


# ==================== DataItem 统一数据视图 ====================

@dataclass
class DataItem:
    """统一的数据条目视图，封装不同数据集的字段差异。"""
    raw: dict                          # 原始数据
    dataset_type: str                  # cmeee / imcs / yidu
    text_chunks: List[Dict] = field(default_factory=list)
    # 每个 chunk: {"id": str, "text": str, "speaker": str (可选), "context": str (可选)}
    gold_entities: List[Dict] = field(default_factory=list)
    # 每个 ent: {"chunk_id": str, "entity": str, "type": str, "norm": str (可选)}
    has_norm_field: bool = False       # 是否有 symptom_norm（需要 IMCS 归一化）

    def get_text_for_extraction(self) -> List[Dict]:
        """返回需要送给 LLM 的文本列表（每个元素一次 LLM 调用）"""
        return self.text_chunks


def detect_dataset_type(data: List[dict]) -> str:
    """从数据样本判定数据集类型。
    取前 5 条样本投票，避免单条样本异常。
    """
    if not data:
        return DATASET_UNKNOWN

    votes = Counter()
    for item in data[:5]:
        # IMCS 特征：有 dialogue 字段
        if "dialogue" in item and isinstance(item["dialogue"], list):
            votes[DATASET_IMCS] += 1
            continue
        # CMeEE/Yidu 特征：有 entities + text
        if "entities" in item and "text" in item:
            ents = item.get("entities", [])
            if ents and isinstance(ents, list) and ents[0].get("type"):
                t = ents[0]["type"]
                if t in _CMEEE_TYPES:
                    votes[DATASET_CMEEE] += 1
                elif t in _YIDU_TYPES:
                    votes[DATASET_YIDU] += 1
                else:
                    # 未知类型按 CMeEE 处理
                    votes[DATASET_CMEEE] += 1
            else:
                # 无标注但有 text/entities 结构，按 CMeEE
                votes[DATASET_CMEEE] += 1
            continue
        # 兜底
        votes[DATASET_UNKNOWN] += 1

    if not votes:
        return DATASET_UNKNOWN
    return votes.most_common(1)[0][0]


# ==================== 统一字段适配器 ====================

def build_data_item(raw: dict, dataset_type: str, item_idx: int = 0) -> DataItem:
    """把任意数据集的一条样本变成统一 DataItem。"""
    if dataset_type == DATASET_CMEEE or dataset_type == DATASET_YIDU:
        return _build_cmeee_yidu_item(raw, dataset_type, item_idx)
    elif dataset_type == DATASET_IMCS:
        return _build_imcs_item(raw, item_idx)
    else:
        # 未知类型，按 CMeEE 兜底
        return _build_cmeee_yidu_item(raw, DATASET_CMEEE, item_idx)


def _build_cmeee_yidu_item(raw: dict, ds_type: str, idx: int) -> DataItem:
    text = raw.get("text", "") or raw.get("originalText", "") or ""
    chunk_id = str(raw.get("text_id") or raw.get("id") or f"item_{idx}")
    item = DataItem(
        raw=raw,
        dataset_type=ds_type,
        text_chunks=[{
            "id": chunk_id,
            "text": text,
            "speaker": "",
            "context": "",
        }],
        has_norm_field=False,
    )
    # 收集 gold 实体
    for ent in raw.get("entities", []):
        item.gold_entities.append({
            "chunk_id": chunk_id,
            "entity": (ent.get("entity") or "").strip(),
            "type": ent.get("type") or "",
            "norm": "",
        })
    return item


def _build_imcs_item(raw: dict, idx: int) -> DataItem:
    """IMCS 样本：把每个 turn 当作一个 chunk。
    上下文：前一轮对话作为 context。
    """
    item = DataItem(
        raw=raw,
        dataset_type=DATASET_IMCS,
        has_norm_field=True,
    )

    dialogue = raw.get("dialogue", [])
    item_id = str(raw.get("example_id") or raw.get("id") or f"item_{idx}")

    prev_sentence = ""
    for turn_idx, turn in enumerate(dialogue):
        sentence = turn.get("sentence", "")
        speaker  = turn.get("speaker", "")
        chunk_id = f"{item_id}_t{turn_idx}"

        item.text_chunks.append({
            "id":       chunk_id,
            "text":     sentence,
            "speaker":  speaker,
            "context":  prev_sentence,
        })

        # 收集 gold（按 type 1=患者确认 / 2=医生推断；过滤掉 0=否定/询问）
        # symptom_type 是 list[str]，对应每个 norm
        norms = turn.get("symptom_norm", []) or []
        types = turn.get("symptom_type", []) or []
        for i, nm in enumerate(norms):
            t = types[i] if i < len(types) else "1"
            if str(t) not in ("1", "2"):
                continue
            if not nm or not nm.strip():
                continue
            item.gold_entities.append({
                "chunk_id": chunk_id,
                "entity":   nm.strip(),
                "type":     f"sym_type_{t}",
                "norm":     nm.strip(),
            })

        prev_sentence = sentence

    return item


# ==================== gold 集合提取（用于评估） ====================

def get_gold_set_for_chunk(item: DataItem, chunk_id: str,
                           use_norm: bool = False) -> Set[str]:
    """取一个 chunk 的 gold 实体集合。

    use_norm=True 时返回归一化后的实体（仅对 IMCS 有意义）；
    否则返回原始 entity 字段。
    """
    out = set()
    for ent in item.gold_entities:
        if ent["chunk_id"] != chunk_id:
            continue
        if use_norm and ent.get("norm"):
            out.add(ent["norm"])
        else:
            out.add(ent["entity"])
    return out


def get_all_gold_chunks(items: List[DataItem],
                       use_norm: bool = False) -> List[Tuple[str, Set[str]]]:
    """返回 [(chunk_id, gold_set), ...]，用于评估。"""
    out = []
    for item in items:
        for chunk in item.text_chunks:
            gold = get_gold_set_for_chunk(item, chunk["id"], use_norm)
            # 即使 gold 为空，也保留（用于评估真负例样本）
            out.append((chunk["id"], gold))
    return out


# ==================== 学习样本字段转换 ====================
# 为了与现有 FewShotLearner / IMCSLearner 接口兼容，
# 我们需要把数据回退成它们期望的格式

def to_legacy_format(items: List[DataItem], dataset_type: str) -> List[dict]:
    """把统一 DataItem 列表转回原始数据格式，喂给 FewShotLearner"""
    return [it.raw for it in items]
