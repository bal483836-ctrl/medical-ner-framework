"""
Reflector - v20

v20 中真正的反思逻辑已内联到 extract_entities.py（按 JSON 格式做反思）。
此模块仅保留 merge_entities 工具方法，供其他模块复用。

之前 v19 的 Reflector.reflect_and_correct 是死代码（全代码库零调用），已删除。
"""
from typing import List, Set


class Reflector:
    """实体合并工具（保留兼容接口）"""

    @staticmethod
    def merge_entities(*entity_lists) -> List[str]:
        """合并多个实体列表，去重保序"""
        seen: Set[str] = set()
        result = []
        for lst in entity_lists:
            if not lst:
                continue
            if isinstance(lst, str):
                lst = [s.strip() for s in lst.split(",") if s.strip()]
            for ent in lst:
                ent = ent.strip()
                if ent and ent not in seen:
                    seen.add(ent)
                    result.append(ent)
        return result

    @staticmethod
    def union_keep_order(a: List[str], b: List[str]) -> List[str]:
        """A ∪ B，保 A 的顺序，B 的新元素追加在后"""
        return Reflector.merge_entities(a, b)
