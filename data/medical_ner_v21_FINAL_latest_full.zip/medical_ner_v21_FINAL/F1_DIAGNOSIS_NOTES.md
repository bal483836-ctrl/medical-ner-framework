# 医疗 NER v21 低 F1 静态诊断记录

## 关键发现

当前项目在 IMCS 数据集上存在明显的 **任务口径错配**：

1. `src/unified_prompt.py` 的 IMCS 抽取提示词明确要求模型输出“原文形态，不归一化”，例如“拉肚子”应输出“拉肚子”，不输出“腹泻”。
2. `src/dataset_detector.py` 在构造 IMCS gold 时，`gold_entities[].entity` 和 `gold_entities[].norm` 都使用 `symptom_norm` 标准词，没有保留口语原文。
3. `src/unified_normalize_eval.py` 的 `evaluate_raw_extraction()` 在 `use_norm=False` 时仍然读取 `gold_entities[].entity`，因此 IMCS 的 raw 评估实际是“口语预测 vs 标准词 gold”。这会把大量本应正确的口语抽取判为 FP/FN。
4. `compute_set_f1()` 对 gold/pred 同为空的 chunk 计算 F1=0，导致 macro F1 被大量真负例 chunk 人为压低。对于对话式 IMCS，空症状轮次很多，这会显著扭曲 macro F1。
5. `src/unified_extractor.py` 允许 IMCS 候选实体字面出现在 `text + context` 中，然而评估是按当前 chunk 的 `chunk_id` 对齐 gold。若模型从上一轮 context 抽出症状并归到当前轮，会制造跨轮 FP。
6. `src/unified_normalize_eval.py` 的温度归一化把 37.3--41.0 的所有温度统一归为“发热”，但词表中有“低热 / 中等度热 / 高热”，这会造成标准词错配。
7. LLM 归一化兜底只传排序后前 80 个标准词，可能漏掉正确候选，限制召回上限。

## 初步结论

F1 只有约 0.1 不应首先归因于模型能力不足，而应优先修复 **评估口径、归一化和 chunk 对齐**。在没有真实数据和模型环境的情况下，无法承诺实测达到 0.8，但从代码逻辑看，修复上述问题是把指标拉回合理区间的必要前置步骤。
