"""
统一抽取器 - v21

设计：
  一个 extract() 入口处理任何数据集：
    1. 内部根据 DataItem.dataset_type 选择 prompt 模板
    2. 主模型（Qwen3-32B）做主抽取
    3. 副模型（DeepSeek-R1-14B）做 CoT 反思
    4. 输出统一格式：每个 chunk 一份 entities 列表

输入：List[DataItem]（来自 dataset_detector）
输出：写入 step1_unified.json，结构如下：

[
  {
    "item_id": "xxx",
    "dataset_type": "cmeee",
    "chunks": [
      {
        "id": "chunk_0",
        "text": "...",
        "speaker": "",
        "context": "",
        "raw_entities": [{"entity": "感冒", "type": "dis"}, ...],
        "reflected_entities": [...],   # 反思后
      },
      ...
    ],
    "gold_entities_str": "感冒,发热",   # 兼容老评估
  },
  ...
]
"""
import json
import os
import re
import sys
from typing import List, Dict
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.dataset_detector import (
    DataItem, DATASET_CMEEE, DATASET_IMCS, DATASET_YIDU, DATASET_UNKNOWN,
)
from src.unified_prompt import (
    UnifiedPromptFactory, CMEEE_TARGET_TYPES, YIDU_TYPE_DESC,
)
from src.llm_client import get_client, parse_deepseek_answer


# ==================== 输出解析 ====================

def _parse_cmeee_json(raw: str) -> Dict[str, List[str]]:
    """从 LLM 输出中容错解析 9 类型 JSON"""
    empty = {t: [] for t in CMEEE_TARGET_TYPES}
    if not raw:
        return empty
    match = re.search(r'\{[\s\S]*\}', raw)
    if not match:
        return empty
    s = match.group()
    # 修复常见错误
    s_fixed = s.replace('“', '"').replace('”', '"').replace("'", '"')
    s_fixed = re.sub(r',\s*([\]}])', r'\1', s_fixed)
    try:
        data = json.loads(s_fixed)
    except json.JSONDecodeError:
        try:
            data = json.loads(s)
        except json.JSONDecodeError:
            return empty

    result = {}
    for t in CMEEE_TARGET_TYPES:
        v = data.get(t, [])
        if isinstance(v, str):
            v = [v]
        elif not isinstance(v, list):
            v = []
        result[t] = [str(x).strip() for x in v if str(x).strip()]
    return result


def _parse_yidu_json(raw: str) -> Dict[str, List[str]]:
    empty = {t: [] for t in YIDU_TYPE_DESC}
    if not raw:
        return empty
    match = re.search(r'\{[\s\S]*\}', raw)
    if not match:
        return empty
    s = match.group()
    s_fixed = s.replace('“', '"').replace('”', '"').replace("'", '"')
    s_fixed = re.sub(r',\s*([\]}])', r'\1', s_fixed)
    try:
        data = json.loads(s_fixed)
    except json.JSONDecodeError:
        try:
            data = json.loads(s)
        except json.JSONDecodeError:
            return empty
    result = {}
    for t in YIDU_TYPE_DESC:
        v = data.get(t, [])
        if isinstance(v, str):
            v = [v]
        elif not isinstance(v, list):
            v = []
        result[t] = [str(x).strip() for x in v if str(x).strip()]
    return result


def _parse_imcs_list(raw: str) -> List[str]:
    if not raw:
        return []
    raw = raw.strip().strip('"').strip("'")
    if raw in ("无", "none", "None", "无症状", ""):
        return []
    parts = re.split(r'[、,，;；\s]+', raw)
    return [p.strip() for p in parts if p.strip() and p.strip() != "无"]


def _trim_boundary(name: str) -> str:
    name = re.sub(r'[的等了吗啊呢吧呀嘛、，。；：!?\"]+$', '', name)
    name = re.sub(r'^[的等了吗啊呢吧呀嘛、，。；：!?\"]+', '', name)
    return name.strip()


def _entity_in_text(entity: str, text: str, context: str = "") -> bool:
    """实体是否字面出现"""
    if not entity:
        return False
    full = (text or "") + (context or "")
    if entity in full:
        return True
    trimmed = _trim_boundary(entity)
    return bool(trimmed) and trimmed in full


# ==================== 统一抽取主流程 ====================

class UnifiedExtractor:
    """统一抽取器：双 LLM 协作"""

    def __init__(self, knowledge=None, use_reflection: bool = True,
                 use_batch: bool = True, batch_size: int = 16):
        """
        Args:
            knowledge: LearnedKnowledge 对象（来自 Step 0）
            use_reflection: 是否启用反思（副模型）
            use_batch: 是否启用 vLLM 批处理（速度快 5-10 倍）
            batch_size: 批大小
        """
        self.knowledge = knowledge
        self.use_reflection = use_reflection
        self.use_batch = use_batch
        self.batch_size = batch_size
        self.client = get_client()

    def _get_constraints(self) -> str:
        if self.knowledge is None:
            return ""
        return getattr(self.knowledge, "style_constraints", "")

    def _get_skill_refs(self) -> List[Dict]:
        if self.knowledge is None:
            return []
        return getattr(self.knowledge, "skill_refs", []) or []

    def _get_ner_skills(self) -> str:
        if self.knowledge is None:
            return ""
        return getattr(self.knowledge, "learned_ner_skills", "") or ""

    # -------- 单 chunk 抽取（不批处理时用） --------

    def _extract_one_chunk(self, dataset_type: str, chunk: Dict) -> Dict:
        prompt = UnifiedPromptFactory.build_extraction_prompt(
            dataset_type=dataset_type,
            chunk=chunk,
            learned_constraints=self._get_constraints(),
            skill_refs=self._get_skill_refs(),
            learned_ner_skills=self._get_ner_skills(),
        )
        raw = self.client.call_primary(prompt)
        return self._parse_extraction(dataset_type, raw, chunk)

    def _parse_extraction(self, dataset_type: str, raw: str, chunk: Dict) -> Dict:
        """把 LLM 输出解析为统一的 entities 列表"""
        entities = []
        if dataset_type == DATASET_CMEEE:
            parsed = _parse_cmeee_json(raw)
            for t, names in parsed.items():
                for n in names:
                    n_trim = _trim_boundary(n)
                    if not n_trim:
                        continue
                    if not _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):
                        continue
                    entities.append({"entity": n_trim, "type": t})
        elif dataset_type == DATASET_YIDU:
            parsed = _parse_yidu_json(raw)
            for t, names in parsed.items():
                for n in names:
                    n_trim = _trim_boundary(n)
                    if not n_trim:
                        continue
                    if not _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):
                        continue
                    entities.append({"entity": n_trim, "type": t})
        elif dataset_type == DATASET_IMCS:
            names = _parse_imcs_list(raw)
            for n in names:
                n_trim = _trim_boundary(n)
                if not n_trim:
                    continue
                if not _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):
                    continue
                entities.append({"entity": n_trim, "type": "sym"})
        else:
            # unknown: 当成 IMCS 风格的"、"分隔列表
            names = _parse_imcs_list(raw)
            for n in names:
                n_trim = _trim_boundary(n)
                if not n_trim:
                    continue
                if _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):
                    entities.append({"entity": n_trim, "type": ""})
        return {"entities": entities, "raw": raw}

    # -------- 反思阶段（副模型） --------

    def _reflect_one(self, dataset_type: str, chunk: Dict,
                     entities: List[Dict]) -> List[Dict]:
        if not self.use_reflection or not entities:
            return entities

        # 准备候选
        if dataset_type in (DATASET_CMEEE, DATASET_YIDU):
            type_keys = CMEEE_TARGET_TYPES if dataset_type == DATASET_CMEEE \
                        else list(YIDU_TYPE_DESC.keys())
            candidates = {t: [] for t in type_keys}
            for e in entities:
                t = e["type"]
                if t in candidates:
                    candidates[t].append(e["entity"])
        elif dataset_type == DATASET_IMCS:
            candidates = [e["entity"] for e in entities]
        else:
            return entities

        prompt = UnifiedPromptFactory.build_reflection_prompt(
            dataset_type=dataset_type,
            chunk=chunk,
            candidates=candidates,
        )
        raw = self.client.call_secondary(prompt, parse_cot=True)

        # 解析反思输出
        if dataset_type in (DATASET_CMEEE, DATASET_YIDU):
            refined_json = (_parse_cmeee_json(raw) if dataset_type == DATASET_CMEEE
                            else _parse_yidu_json(raw))
            new_entities = []
            for t, names in refined_json.items():
                for n in names:
                    n_trim = _trim_boundary(n)
                    if not n_trim:
                        continue
                    if not _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):
                        continue
                    new_entities.append({"entity": n_trim, "type": t})
            return new_entities
        else:  # IMCS
            names = _parse_imcs_list(raw)
            new_entities = []
            for n in names:
                n_trim = _trim_boundary(n)
                if not n_trim:
                    continue
                if _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):
                    new_entities.append({"entity": n_trim, "type": "sym"})
            return new_entities

    # -------- 批处理优化路径（vLLM 上加速 5-10x） --------

    def _extract_chunks_batch(self, dataset_type: str,
                              chunks: List[Dict]) -> List[Dict]:
        """批量抽取一组 chunks"""
        prompts = [
            UnifiedPromptFactory.build_extraction_prompt(
                dataset_type=dataset_type,
                chunk=c,
                learned_constraints=self._get_constraints(),
                skill_refs=self._get_skill_refs(),
                learned_ner_skills=self._get_ner_skills(),
            )
            for c in chunks
        ]
        raws = self.client.call_primary_batch(prompts)
        return [self._parse_extraction(dataset_type, raw, c)
                for raw, c in zip(raws, chunks)]

    def _reflect_chunks_batch(self, dataset_type: str,
                              chunks: List[Dict],
                              entities_list: List[List[Dict]]) -> List[List[Dict]]:
        """批量反思一组 chunks"""
        # 过滤掉没有候选的 chunk（不需要反思）
        idx_to_reflect = [i for i, ents in enumerate(entities_list) if ents]
        if not idx_to_reflect:
            return entities_list

        prompts = []
        for i in idx_to_reflect:
            chunk = chunks[i]
            ents = entities_list[i]
            if dataset_type in (DATASET_CMEEE, DATASET_YIDU):
                type_keys = CMEEE_TARGET_TYPES if dataset_type == DATASET_CMEEE \
                            else list(YIDU_TYPE_DESC.keys())
                cand = {t: [] for t in type_keys}
                for e in ents:
                    if e["type"] in cand:
                        cand[e["type"]].append(e["entity"])
            else:
                cand = [e["entity"] for e in ents]
            prompts.append(UnifiedPromptFactory.build_reflection_prompt(
                dataset_type, chunk, cand,
            ))
        raws = self.client.call_secondary_batch(prompts, parse_cot=True)

        # 解析回写
        result = list(entities_list)
        for k, raw in enumerate(raws):
            i = idx_to_reflect[k]
            chunk = chunks[i]
            if dataset_type in (DATASET_CMEEE, DATASET_YIDU):
                refined = (_parse_cmeee_json(raw) if dataset_type == DATASET_CMEEE
                           else _parse_yidu_json(raw))
                new_ents = []
                for t, names in refined.items():
                    for n in names:
                        n_trim = _trim_boundary(n)
                        if not n_trim:
                            continue
                        if not _entity_in_text(n_trim, chunk["text"],
                                                chunk.get("context", "")):
                            continue
                        new_ents.append({"entity": n_trim, "type": t})
                result[i] = new_ents
            else:
                names = _parse_imcs_list(raw)
                new_ents = []
                for n in names:
                    n_trim = _trim_boundary(n)
                    if not n_trim:
                        continue
                    if _entity_in_text(n_trim, chunk["text"], chunk.get("context", "")):
                        new_ents.append({"entity": n_trim, "type": "sym"})
                result[i] = new_ents
        return result

    # -------- 主入口 --------

    # -------- 断点缓存读写 --------

    def _ckpt_path(self, base_path: str, stage: str) -> str:
        """生成断点文件路径"""
        if not base_path:
            return None
        dir_ = os.path.dirname(base_path) or "."
        base = os.path.basename(base_path).replace(".json", "")
        return os.path.join(dir_, f"{base}.{stage}.ckpt.jsonl")

    def _load_ckpt(self, ckpt_path: str) -> Dict[int, Dict]:
        """读取已完成的 chunk_idx → result 映射"""
        if not ckpt_path or not os.path.exists(ckpt_path):
            return {}
        done = {}
        with open(ckpt_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    done[rec["chunk_idx"]] = rec["data"]
                except Exception:
                    continue
        return done

    def _append_ckpt(self, ckpt_path: str, chunk_idx: int, data: Dict):
        if not ckpt_path:
            return
        os.makedirs(os.path.dirname(ckpt_path) or ".", exist_ok=True)
        with open(ckpt_path, "a", encoding="utf-8") as f:
            f.write(json.dumps({"chunk_idx": chunk_idx, "data": data},
                                ensure_ascii=False) + "\n")
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass

    # -------- 主入口 --------

    def extract(self, items: List[DataItem],
                output_path: str = None) -> List[Dict]:
        """对一组 DataItem 做抽取，返回统一格式结果。
        支持断点续传：批次完成后立刻写 .ckpt.jsonl，崩溃后重启会跳过已完成 chunks。
        """
        if not items:
            return []

        dataset_type = items[0].dataset_type
        print(f"\n📌 统一抽取启动 | 数据集类型: {dataset_type} | "
              f"样本数: {len(items)} | 批模式: {self.use_batch}")

        # 展平所有 chunks
        all_chunks_meta = []      # [(item_idx, chunk)]
        for it_idx, item in enumerate(items):
            for chunk in item.text_chunks:
                all_chunks_meta.append((it_idx, chunk))

        n_chunks = len(all_chunks_meta)
        print(f"  ⊙ 总 chunk 数: {n_chunks}")

        # 断点路径
        extract_ckpt = self._ckpt_path(output_path, "extract")
        reflect_ckpt = self._ckpt_path(output_path, "reflect")

        # ---------- Step 1: 主抽取 ----------
        chunk_results = [None] * n_chunks
        done_extract = self._load_ckpt(extract_ckpt)
        if done_extract:
            print(f"  📂 发现 extract 断点: {len(done_extract)}/{n_chunks} 已完成")
        for idx, data in done_extract.items():
            if idx < n_chunks:
                chunk_results[idx] = data

        print(f"\n  [1/2] 主抽取（Qwen3-32B）| 待处理: "
              f"{n_chunks - len(done_extract)}")

        if self.use_batch:
            for start in tqdm(range(0, n_chunks, self.batch_size),
                              desc="主抽取批次"):
                end = min(start + self.batch_size, n_chunks)
                todo_indices = [i for i in range(start, end)
                                if chunk_results[i] is None]
                if not todo_indices:
                    continue
                batch_chunks = [all_chunks_meta[i][1] for i in todo_indices]
                batch_out = self._extract_chunks_batch(dataset_type, batch_chunks)
                for k, res in enumerate(batch_out):
                    ci = todo_indices[k]
                    chunk_results[ci] = res
                    self._append_ckpt(extract_ckpt, ci, res)
        else:
            for i, (_, chunk) in enumerate(tqdm(all_chunks_meta, desc="主抽取")):
                if chunk_results[i] is not None:
                    continue
                res = self._extract_one_chunk(dataset_type, chunk)
                chunk_results[i] = res
                self._append_ckpt(extract_ckpt, i, res)

        # ---------- Step 2: 反思 ----------
        if self.use_reflection:
            done_reflect = self._load_ckpt(reflect_ckpt)
            if done_reflect:
                print(f"  📂 发现 reflect 断点: {len(done_reflect)}/{n_chunks} 已完成")
            for idx, data in done_reflect.items():
                if idx < n_chunks and chunk_results[idx]:
                    chunk_results[idx]["reflected_entities"] = data.get(
                        "reflected_entities", chunk_results[idx]["entities"]
                    )

            print(f"\n  [2/2] 反思（DeepSeek-R1-14B）| 待处理: "
                  f"{n_chunks - len(done_reflect)}")

            chunks_only = [m[1] for m in all_chunks_meta]

            if self.use_batch:
                for start in tqdm(range(0, n_chunks, self.batch_size),
                                  desc="反思批次"):
                    end = min(start + self.batch_size, n_chunks)
                    todo_indices = [
                        i for i in range(start, end)
                        if "reflected_entities" not in (chunk_results[i] or {})
                    ]
                    if not todo_indices:
                        continue
                    batch_chunks = [chunks_only[i] for i in todo_indices]
                    batch_ents = [chunk_results[i]["entities"] for i in todo_indices]
                    refined = self._reflect_chunks_batch(
                        dataset_type, batch_chunks, batch_ents,
                    )
                    for k, new_ents in enumerate(refined):
                        ci = todo_indices[k]
                        chunk_results[ci]["reflected_entities"] = new_ents
                        self._append_ckpt(reflect_ckpt, ci,
                                          {"reflected_entities": new_ents})
            else:
                for i, (_, chunk) in enumerate(tqdm(all_chunks_meta, desc="反思")):
                    if "reflected_entities" in (chunk_results[i] or {}):
                        continue
                    new_ents = self._reflect_one(
                        dataset_type, chunk, chunk_results[i]["entities"]
                    )
                    chunk_results[i]["reflected_entities"] = new_ents
                    self._append_ckpt(reflect_ckpt, i,
                                      {"reflected_entities": new_ents})
        else:
            for r in chunk_results:
                if r and "reflected_entities" not in r:
                    r["reflected_entities"] = r["entities"]

        # ---------- 组装结果 ----------
        results = []
        for it_idx, item in enumerate(items):
            item_result = {
                "item_id": str(it_idx),
                "dataset_type": dataset_type,
                "chunks": [],
                "raw": item.raw,
            }
            for chunk in item.text_chunks:
                # 找到对应的抽取结果
                idx = None
                for k, (ii, ch) in enumerate(all_chunks_meta):
                    if ii == it_idx and ch["id"] == chunk["id"]:
                        idx = k
                        break
                if idx is None:
                    continue
                res = chunk_results[idx]
                item_result["chunks"].append({
                    "id":           chunk["id"],
                    "text":         chunk["text"],
                    "speaker":      chunk.get("speaker", ""),
                    "context":      chunk.get("context", ""),
                    "raw_entities": res["entities"],
                    "reflected_entities": res.get("reflected_entities", res["entities"]),
                    "llm_raw":      res.get("raw", "")[:500],   # 截短调试用
                })
            # 兼容老 evaluator：拼一个 gold_entities_str
            gold_set = set()
            for ent in item.gold_entities:
                gold_set.add(ent["entity"])
            item_result["gold_entities_str"] = ",".join(sorted(gold_set))
            # 全局 pred 字符串
            pred_set = set()
            for ch in item_result["chunks"]:
                for e in ch["reflected_entities"]:
                    pred_set.add(e["entity"])
            item_result["step1_pred_str"] = ",".join(sorted(pred_set))
            results.append(item_result)

        # ---------- 保存 ----------
        if output_path:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(results, f, ensure_ascii=False, indent=2)
            print(f"\n  ✅ 主抽取结果已保存: {output_path}")

        return results
