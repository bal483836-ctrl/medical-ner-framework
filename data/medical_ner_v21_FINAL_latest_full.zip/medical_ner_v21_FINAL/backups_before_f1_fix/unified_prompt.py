"""
统一 Prompt Factory - v21

设计目标：
  对外只暴露一个入口 build_extraction_prompt / build_reflection_prompt，
  内部根据 dataset_type 自动选择模板。

模板覆盖：
  - cmeee : 9 类型 JSON 抽取
  - imcs  : 对话症状抽取（原文形态）
  - yidu  : 6 类型 JSON 抽取
  - unknown: 通用 NER（无类型约束）

新增 v21 特性：
  - CoT 反思 prompt：让 DeepSeek-R1 输出 <thinking>...</thinking><answer>...</answer>
  - 主抽取 prompt 加入 KNN few-shot 接口（外部传入相似样本）
"""
import json
from typing import List, Dict, Optional

from src.dataset_detector import (
    DATASET_CMEEE, DATASET_IMCS, DATASET_YIDU, DATASET_UNKNOWN
)


# ==================== 类型定义 ====================

CMEEE_TYPE_DESC = {
    "dis": "疾病/诊断（具体疾病名、综合征、病变）",
    "sym": "症状/体征（病人主诉的不适、医学观察到的异常表现）",
    "pro": "手术/诊疗操作（医疗动作、检查过程、治疗手段）",
    "equ": "医疗设备（仪器、器械）",
    "dru": "药物（药品名）",
    "ite": "检验项目/指标（化验项目、可量化的医学指标）",
    "bod": "身体部位/解剖结构/分子（含器官、细胞、组织、染色体、基因）",
    "mic": "微生物/病原（细菌、病毒、寄生虫等）",
    "dep": "科室与部门（医院科室）",
}

CMEEE_TARGET_TYPES = list(CMEEE_TYPE_DESC.keys())

CMEEE_TYPE_DISTINCTIONS = """
【类型边界（重要：常错处）】
- "感染" → 默认 dis（疾病），不是 sym
- "出血" → 默认 sym（症状），但 "脑出血" 整体是 dis
- "胎儿" → bod（身体部位），不是 dis
- "化疗"、"全身用药"、"针灸" → pro（操作），不是 dru
- "心率"、"血压"、"血糖"、"体温" → ite（指标），不是 sym
- "肌张力"、"BUN"、"GFR" → ite（指标），不是 bod
- "免疫抑制剂" → dru（药物大类），不是 ite
- "白细胞"、"血小板"、"红细胞" → bod（细胞），不是 ite
- "心电图" → ite（检查项目），但 "心电图机" → equ
- "病毒"、"细菌"、"葡萄球菌" → mic，不是 dis
- "ICU"、"急诊科"、"心内科" → dep，独立成类
"""

YIDU_TYPE_DESC = {
    "Disease and Diagnosis": "疾病和诊断",
    "Imaging":               "影像检查",
    "Laboratory":            "实验室检验",
    "Medicine":              "药物",
    "Anatomy":               "解剖部位",
    "Operation":             "手术",
}


# ==================== 内置示例 ====================

_BUILTIN_CMEEE_EXAMPLES = [
    {
        "text": "经手术证实为十二指肠溃疡伴穿孔，行胃大部切除术。",
        "output": {
            "dis": ["十二指肠溃疡"], "sym": ["穿孔"],
            "pro": ["手术", "胃大部切除术"],
            "equ": [], "dru": [], "ite": [], "bod": [], "mic": [], "dep": [],
        }
    },
    {
        "text": "胎儿心率监测显示节律异常，经心电图检查确诊心律失常。",
        "output": {
            "dis": ["心律失常"], "sym": ["节律异常"],
            "pro": ["心电图检查"],
            "equ": [], "dru": [],
            "ite": ["心率", "心电图"], "bod": ["胎儿"],
            "mic": [], "dep": [],
        }
    },
    {
        "text": "葡萄球菌肺炎@血清中磷壁酸抗体测定可作为病原学诊断的补充。",
        "output": {
            "dis": ["葡萄球菌肺炎"], "sym": [], "pro": ["病原学诊断"],
            "equ": [], "dru": [],
            "ite": ["血清中磷壁酸抗体测定"],
            "bod": [], "mic": ["葡萄球菌"], "dep": [],
        }
    },
]


_BUILTIN_IMCS_EXAMPLES = """【示例1】发言：宝宝拉肚子两天了，还有点烧
原文症状：拉肚子、烧

【示例2】发言：流了一天的清鼻涕，喉咙有痰，鼻子不通气
原文症状：流清鼻涕、喉咙有痰、鼻子不通气

【示例3】发言：体温多少？
原文症状：无（询问句不输出）

【示例4】发言：没发烧也没拉稀
原文症状：无（否定症状不输出）

【示例5】发言：从昨天下午到现在发热，在37.2-38.2度波动
原文症状：发热、37.2-38.2度"""


# ==================== 内部模板：CMeEE ====================

def _format_cmeee_examples(skill_refs: List[Dict], max_n: int = 4) -> str:
    examples = []
    if skill_refs:
        for item in skill_refs[:max_n]:
            text = item.get("text", "")
            by_type = {t: [] for t in CMEEE_TYPE_DESC}
            for ent in item.get("entities", []):
                t = ent.get("type")
                n = (ent.get("entity") or "").strip()
                if t in by_type and n:
                    by_type[t].append(n)
            if any(by_type.values()):
                examples.append({"text": text, "output": by_type})
    if len(examples) < max_n:
        examples.extend(_BUILTIN_CMEEE_EXAMPLES[:max_n - len(examples)])

    lines = []
    for i, item in enumerate(examples[:max_n], 1):
        out = {t: item["output"].get(t, []) for t in CMEEE_TYPE_DESC}
        lines.append(f"【示例{i}】")
        lines.append(f"原文：{item['text']}")
        lines.append(f"输出：{json.dumps(out, ensure_ascii=False)}")
    return "\n".join(lines)


def _cmeee_extraction_prompt(text: str, learned_constraints: str,
                             skill_refs: List[Dict],
                             learned_ner_skills: str = "") -> str:
    type_desc = "\n".join(f"  - {t}：{d}" for t, d in CMEEE_TYPE_DESC.items())
    examples = _format_cmeee_examples(skill_refs, max_n=4)

    skills_block = ""
    if learned_ner_skills:
        skills_block = f"\n【提取技巧（从训练样本归纳）】\n{learned_ner_skills}\n"

    return f"""你是医学信息抽取专家。从医学文本中识别 9 类实体。

# 实体类型
{type_desc}
{CMEEE_TYPE_DISTINCTIONS}

{learned_constraints}{skills_block}

# 核心规则
1. 字面精确：抽出的字符串必须**逐字符**出现在原文中
2. 边界严格：不带尾部「了/的/吗/啊/呢」助词；不带前缀「治疗 X/明显的 X」
3. 不要拆解长实体：「急性阑尾炎」整体是 dis，不再拆「阑尾炎」（除非独立出现）
4. 短词召回：单字 bod（血/心/肝/肺/肾）要抽；2-3 字短词（出血/感染/化疗）也要抽
5. 英文缩写保留：CT、ERCP、BUN、CRP、GFR、MRI 等
6. 整段长描述：「血常规周围血白细胞计数可以增高」这种 5 字以上医学描述整段作 sym
7. 不要凭常识猜：原文没出现的实体不抽

# 高质量示例
{examples}

# 待标注文本
{text}

# 输出格式（严格 JSON，无前缀说明）
{{"dis":[],"sym":[],"pro":[],"equ":[],"dru":[],"ite":[],"bod":[],"mic":[],"dep":[]}}

JSON:"""


def _cmeee_reflection_cot_prompt(text: str, candidates: Dict[str, List[str]]) -> str:
    """v21: DeepSeek-R1 CoT 反思 prompt"""
    return f"""你是医学审稿专家。逐项审查下列候选实体，判断是否需要删除或修改类型。

# 原文
{text}

# 候选实体
{json.dumps(candidates, ensure_ascii=False)}

# 审查规则（逐项思考）

## 1. 字面验证
候选必须**逐字符**出现在原文中。否则删除。

## 2. 边界检查
- 剥离尾部助词「了/的/吗/啊/呢/吧」
- 剥离前缀修饰「治疗 X」「明显的 X」
- 不要错切到不该切的位置

## 3. 类型校正
- 「感染、综合征、传导阻滞」→ dis
- 「心率、血糖、体温、肌张力」→ ite（不是 sym 也不是 bod）
- 「化疗、针灸、全身用药」→ pro
- 「胎儿、白细胞、染色体」→ bod
- 「葡萄球菌、肺炎链球菌」→ mic
- 「ICU、急诊科」→ dep

## 4. ⚠️ 不要做的
- 不要新增候选 JSON 中没有的实体
- 不要从长实体拆出短实体
- 不要仅凭感觉改类型

# 输出格式（必须严格遵守）
先在 <thinking> 标签内逐项分析（可以详细推理），然后在 <answer> 标签内输出修正后的 JSON。

<thinking>
逐项分析每个候选实体...
</thinking>
<answer>
{{"dis":[],"sym":[],"pro":[],"equ":[],"dru":[],"ite":[],"bod":[],"mic":[],"dep":[]}}
</answer>
"""


# ==================== 内部模板：IMCS ====================

def _imcs_extraction_prompt(sentence: str, speaker: str, context: str,
                            learned_constraints: str,
                            learned_ner_skills: str = "") -> str:
    skills_block = ""
    if learned_ner_skills:
        skills_block = f"\n【从训练样本归纳的症状识别技巧】\n{learned_ner_skills}\n"

    return f"""你是儿科医学症状识别专家。分析对话，识别患者**确实存在**或**医生推断为存在**的症状。

# 上文（仅供理解语境）
{context if context else "首轮发言"}

# 当前发言
[{speaker}] {sentence}

{learned_constraints}{skills_block}

# 抽取规则

## ✅ 应该抽出
1. 患者陈述的症状：「孩子拉肚子」「流清鼻涕」「睡不好」「吃奶少」
2. 患者描述的体感：「肚子疼」「小便发黄」
3. 数字温度：「38.5度」「37.2-38.2度」
4. 医生推断且患者未否认的

## ❌ 不应该抽出
1. 否定句：「不发烧」「没拉稀」「没什么大碍」
2. 询问句：「有腹泻吗？」「体温多少？」
3. 检查/治疗：「血常规」「拍 X 光」「吃药」
4. 已不存在：「之前发烧昨天好了」

## ⚠️ 关键
- **抽原文形态，不归一化**：「拉肚子」→ 输出「拉肚子」，不输出「腹泻」
- 必须字面在原文（含上文）出现
- 无相关症状时，输出"无"

# 示例
{_BUILTIN_IMCS_EXAMPLES}

# 输出
仅输出原文中字面出现的症状描述，多个用"、"分隔，无症状输出"无"，无前缀说明：
"""


def _imcs_reflection_cot_prompt(sentence: str, speaker: str, context: str,
                                candidates: List[str]) -> str:
    """v21: IMCS 反思 prompt（DeepSeek 做边界裁决）"""
    cand_str = "、".join(candidates) if candidates else "无"
    return f"""你是儿科医学审稿专家。判断下列候选症状是否应该保留。

# 上文
{context if context else "首轮发言"}

# 当前发言
[{speaker}] {sentence}

# 候选症状
{cand_str}

# 审查规则
1. 候选词必须字面出现在原文中
2. 否定句中的症状（「不发烧」「没腹泻」）应删除
3. 询问句中的症状（「有腹泻吗？」）应删除
4. 不属于患者主诉或医生推断的应删除（如检查项目、治疗手段）

# 输出格式
<thinking>
逐项分析每个候选...
</thinking>
<answer>
保留的症状（多个用"、"分隔，无则输出"无"）
</answer>
"""


def _imcs_normalize_llm_prompt(oral: str, norm_vocab_sample: List[str]) -> str:
    """v21 新增：IMCS 归一化兜底（规则匹配失败时调副模型）"""
    vocab_str = "、".join(norm_vocab_sample[:60])
    return f"""从下列标准症状词表中，找出与口语描述语义最接近的一个。

口语描述：{oral}

标准词表：{vocab_str}

# 要求
- 只输出最匹配的一个标准词，不要解释
- 如果没有合适的匹配，输出"无"

# 示例
口语：拉肚子 → 腹泻
口语：流鼻涕 → 鼻流涕
口语：嗓子不舒服 → 咽痛
口语：吃奶都差不多 → 无

输出："""


# ==================== 内部模板：Yidu ====================

def _yidu_extraction_prompt(text: str, learned_constraints: str = "") -> str:
    type_desc = "\n".join(f"  - {k}：{v}" for k, v in YIDU_TYPE_DESC.items())
    return f"""你是医学信息抽取专家。从电子病历文本中识别 6 类实体。

# 实体类型
{type_desc}

{learned_constraints}

# 核心规则
1. 字面精确：抽出的字符串必须**逐字符**出现在原文中
2. 边界严格：不带助词、不带修饰前缀
3. 类型严格按定义判断

# 待标注文本
{text}

# 输出格式（JSON，无前缀说明）
{{"Disease and Diagnosis":[],"Imaging":[],"Laboratory":[],"Medicine":[],"Anatomy":[],"Operation":[]}}

JSON:"""


# ==================== 内部模板：unknown ====================

def _unknown_extraction_prompt(text: str) -> str:
    return f"""从下列文本中识别医学相关实体（疾病、症状、药物、检查、部位等）。

# 文本
{text}

# 规则
- 字面在原文出现
- 边界严格，无助词修饰

# 输出
所有医学实体，用"、"分隔；无则输出"无"。
"""


# ==================== 对外统一 API ====================

class UnifiedPromptFactory:
    """统一接口：任何数据集都用同一个方法名调用"""

    @staticmethod
    def build_extraction_prompt(
        dataset_type: str,
        chunk: Dict,                       # {"text", "speaker", "context", "id"}
        learned_constraints: str = "",
        skill_refs: List[Dict] = None,
        learned_ner_skills: str = "",
    ) -> str:
        if skill_refs is None:
            skill_refs = []

        if dataset_type == DATASET_CMEEE:
            return _cmeee_extraction_prompt(
                chunk["text"], learned_constraints, skill_refs, learned_ner_skills
            )
        elif dataset_type == DATASET_IMCS:
            return _imcs_extraction_prompt(
                chunk["text"], chunk.get("speaker", ""),
                chunk.get("context", ""),
                learned_constraints, learned_ner_skills,
            )
        elif dataset_type == DATASET_YIDU:
            return _yidu_extraction_prompt(chunk["text"], learned_constraints)
        else:
            return _unknown_extraction_prompt(chunk["text"])

    @staticmethod
    def build_reflection_prompt(
        dataset_type: str,
        chunk: Dict,
        candidates,                        # CMeEE/Yidu: Dict[type, List]; IMCS: List[str]
    ) -> str:
        if dataset_type == DATASET_CMEEE:
            return _cmeee_reflection_cot_prompt(chunk["text"], candidates)
        elif dataset_type == DATASET_IMCS:
            return _imcs_reflection_cot_prompt(
                chunk["text"], chunk.get("speaker", ""),
                chunk.get("context", ""), candidates,
            )
        elif dataset_type == DATASET_YIDU:
            # Yidu 暂用 CMeEE 模板（结构相同）
            return _cmeee_reflection_cot_prompt(chunk["text"], candidates)
        else:
            return f"""请审查以下候选实体是否准确：
原文：{chunk['text']}
候选：{candidates}
仅输出保留的实体（"、"分隔）："""

    @staticmethod
    def build_normalize_prompt(oral: str, norm_vocab: List[str]) -> str:
        """IMCS 归一化兜底"""
        return _imcs_normalize_llm_prompt(oral, norm_vocab)
