"""
统一归一化 + 评估 - v21

设计：
  - 评估指标统一为字符串集合 F1（任何数据集都适用）
  - 归一化只对"有 norm 字段"的数据集（如 IMCS）启用
  - 归一化策略：
      1. 规则匹配（精确 / oral_map / 学习 oral_map / 子串）
      2. LLM 兜底（DeepSeek-14B）：方案 5 的核心改进

评估 1：原始抽取 F1
评估 2：归一化后 F1（仅对有 norm 字段的数据集）
"""
import json
import os
import re
import sys
from typing import List, Dict, Set, Tuple, Optional
from collections import Counter
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import OUTPUT_DIR, FEVER_GRADE
from src.dataset_detector import (
    DataItem, get_gold_set_for_chunk,
    DATASET_CMEEE, DATASET_IMCS, DATASET_YIDU,
)
from src.llm_client import get_client
from src.unified_prompt import UnifiedPromptFactory
from src.kg_alignment import get_oral_to_standard_map, build_imcs_norm_vocab


# ==================== F1 计算 ====================

def compute_f1(tp: int, fp: int, fn: int) -> Tuple[float, float, float]:
    p = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    r = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * p * r / (p + r) if (p + r) > 0 else 0.0
    return p, r, f1


def compute_set_f1(gold_list: List[Set[str]],
                   pred_list: List[Set[str]]) -> Dict:
    """字符串集合 F1（统一指标）"""
    tp = fp = fn = 0
    per_sample_f1 = []
    for gold, pred in zip(gold_list, pred_list):
        c_tp = len(gold & pred)
        c_fp = len(pred - gold)
        c_fn = len(gold - pred)
        tp += c_tp; fp += c_fp; fn += c_fn
        _, _, f1 = compute_f1(c_tp, c_fp, c_fn)
        per_sample_f1.append(f1)
    p, r, micro = compute_f1(tp, fp, fn)
    macro = sum(per_sample_f1) / len(per_sample_f1) if per_sample_f1 else 0.0
    return {
        "tp": tp, "fp": fp, "fn": fn,
        "precision": round(p, 4), "recall": round(r, 4),
        "micro_f1": round(micro, 4), "macro_f1": round(macro, 4),
        "n_samples": len(gold_list),
    }


def print_eval_report(name: str, result: Dict):
    print(f"\n{'=' * 64}")
    print(f"【{name}】")
    print(f"{'=' * 64}")
    print(f"  样本（chunk）数: {result['n_samples']}")
    print(f"  TP={result['tp']}  FP={result['fp']}  FN={result['fn']}")
    print(f"  Precision: {result['precision']:.4f}")
    print(f"  Recall:    {result['recall']:.4f}")
    print(f"  Micro F1:  {result['micro_f1']:.4f}")
    print(f"  Macro F1:  {result['macro_f1']:.4f}")


# ==================== 评估 1：原始抽取 ====================

def evaluate_raw_extraction(items: List[DataItem],
                            extraction_results: List[Dict],
                            name: str = "原始抽取") -> Dict:
    """对统一抽取结果做字符串集合 F1 评估
    每个 chunk 一个样本（同一 DataItem 内多个 chunk 独立评估）。
    """
    gold_chunks = {}    # chunk_id -> gold set
    for item in items:
        for chunk in item.text_chunks:
            cid = chunk["id"]
            gold_chunks[cid] = get_gold_set_for_chunk(item, cid, use_norm=False)

    pred_chunks = {}
    for item_result in extraction_results:
        for ch in item_result.get("chunks", []):
            pred_chunks[ch["id"]] = set(
                e["entity"] for e in ch.get("reflected_entities", [])
            )

    gold_list, pred_list = [], []
    for cid in gold_chunks:
        gold_list.append(gold_chunks[cid])
        pred_list.append(pred_chunks.get(cid, set()))

    result = compute_set_f1(gold_list, pred_list)
    print_eval_report(name, result)
    return result


# ==================== 归一化模块 ====================

def _build_norm_resources():
    """加载所有可用的归一化资源"""
    oral_map = dict(get_oral_to_standard_map())
    norm_vocab = build_imcs_norm_vocab()
    return oral_map, norm_vocab


def _rule_based_normalize(entity: str,
                          oral_map: Dict[str, str],
                          learned_oral_map: Dict[str, str],
                          norm_vocab: Set[str]) -> Dict:
    """规则归一化 7 级
    返回 {"normed": str|None, "method": str}
    """
    entity = entity.strip()
    if not entity:
        return {"normed": None, "method": "empty"}

    # 1) 已是标准词
    if entity in norm_vocab:
        return {"normed": entity, "method": "already_standard"}

    # 2) 数据集自带口语映射
    if entity in oral_map:
        return {"normed": oral_map[entity], "method": "oral_map"}

    # 3) 学习对齐口语映射
    if entity in learned_oral_map:
        return {"normed": learned_oral_map[entity], "method": "learned_oral"}

    # 4) 实体含标准词（"咳痰"→"痰"，取最长）
    best, best_len = None, 0
    for norm in norm_vocab:
        if norm in entity and len(norm) > best_len:
            best, best_len = norm, len(norm)
    if best and best_len >= 1:
        return {"normed": best, "method": "substring_contains"}

    # 5) 标准词含实体（"咳"→"咳嗽"）
    for norm in norm_vocab:
        if entity in norm and len(entity) >= 2:
            return {"normed": norm, "method": "substring_contained"}

    # 6) 前缀去除
    prefixes = [
        "有点", "有些", "比较", "非常", "轻微", "严重", "持续", "反复",
        "偶尔", "经常", "一直", "总是", "总", "老",
        "咳", "流", "拉", "吐", "拉了", "吐了", "流了", "咳了",
        "喉咙有", "嗓子有", "鼻子有", "肚子", "胸口", "脑袋",
        "有", "无", "在",
    ]
    for prefix in prefixes:
        if entity.startswith(prefix) and len(entity) > len(prefix):
            rem = entity[len(prefix):]
            if rem in norm_vocab:
                return {"normed": rem, "method": "prefix_strip_standard"}
            if rem in oral_map:
                return {"normed": oral_map[rem], "method": "prefix_strip_oral"}
            if rem in learned_oral_map:
                return {"normed": learned_oral_map[rem], "method": "prefix_strip_learned"}
            for norm in norm_vocab:
                if norm in rem and len(norm) >= 2:
                    return {"normed": norm, "method": "prefix_strip_substring"}

    # 7) 后缀去除
    suffixes = ["了", "的", "正常", "不正常", "差不多", "得很"]
    for suffix in suffixes:
        if entity.endswith(suffix) and len(entity) > len(suffix):
            rem = entity[:-len(suffix)]
            if rem in norm_vocab:
                return {"normed": rem, "method": "suffix_strip_standard"}
            if rem in oral_map:
                return {"normed": oral_map[rem], "method": "suffix_strip_oral"}

    # 8) 温度推断
    temp_match = re.search(r'(\d{2}\.?\d?)\s*[°℃度]', entity)
    if temp_match:
        try:
            t = float(temp_match.group(1))
            if 37.3 <= t <= 41.0:
                return {"normed": "发热", "method": "temperature_inference"}
        except ValueError:
            pass

    return {"normed": None, "method": "rule_fail"}


def _llm_normalize_batch(failed_orals: List[str],
                         norm_vocab: List[str],
                         use_batch: bool = True,
                         ckpt_path: str = None) -> Dict[str, Optional[str]]:
    """v21 新增：规则匹配失败的口语词，调副 LLM（DeepSeek-14B）做语义归一化
    返回 {oral: normed_or_None}
    支持断点：传入 ckpt_path 后会跳过已完成的 oral
    """
    if not failed_orals:
        return {}

    # 加载断点
    done = {}
    if ckpt_path and os.path.exists(ckpt_path):
        with open(ckpt_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    done[rec["oral"]] = rec["normed"]
                except Exception:
                    continue
        print(f"  📂 LLM 归一化断点: {len(done)}/{len(failed_orals)} 已完成")

    todo = [oral for oral in failed_orals if oral not in done]
    if not todo:
        print(f"  ✓ LLM 归一化全部已完成（来自断点）")
        return done

    client = get_client()
    vocab_sample = sorted(norm_vocab)
    if len(vocab_sample) > 80:
        vocab_sample = vocab_sample[:80]

    prompts = [
        UnifiedPromptFactory.build_normalize_prompt(oral, vocab_sample)
        for oral in todo
    ]
    print(f"\n  🔬 LLM 归一化兜底: 待处理 {len(prompts)} 条")

    norm_set = set(norm_vocab)
    result = dict(done)

    if use_batch:
        batch_size = 32
        for start in tqdm(range(0, len(prompts), batch_size), desc="LLM 归一化批次"):
            end = min(start + batch_size, len(prompts))
            sub_prompts = prompts[start:end]
            sub_raws = client.call_secondary_batch(
                sub_prompts, max_tokens=32, parse_cot=True,
            )
            # 增量写断点
            if ckpt_path:
                os.makedirs(os.path.dirname(ckpt_path) or ".", exist_ok=True)
                with open(ckpt_path, "a", encoding="utf-8") as f:
                    for j, raw in enumerate(sub_raws):
                        oral = todo[start + j]
                        raw_s = (raw or "").strip()
                        cand = re.split(r'[\s\n、,，]', raw_s, maxsplit=1)[0].strip().strip('"').strip("'")
                        normed = cand if (cand and cand != "无" and cand in norm_set) else None
                        result[oral] = normed
                        f.write(json.dumps({"oral": oral, "normed": normed},
                                            ensure_ascii=False) + "\n")
                    f.flush()
            else:
                for j, raw in enumerate(sub_raws):
                    oral = todo[start + j]
                    raw_s = (raw or "").strip()
                    cand = re.split(r'[\s\n、,，]', raw_s, maxsplit=1)[0].strip().strip('"').strip("'")
                    result[oral] = cand if (cand and cand != "无" and cand in norm_set) else None
    else:
        for i, p in enumerate(tqdm(prompts, desc="LLM 归一化")):
            raw = client.call_secondary(p, max_tokens=32, parse_cot=True)
            oral = todo[i]
            raw_s = (raw or "").strip()
            cand = re.split(r'[\s\n、,，]', raw_s, maxsplit=1)[0].strip().strip('"').strip("'")
            result[oral] = cand if (cand and cand != "无" and cand in norm_set) else None

    return result


# ==================== 主归一化入口 ====================

def normalize_extraction_results(
    items: List[DataItem],
    extraction_results: List[Dict],
    knowledge=None,
    use_llm_fallback: bool = True,
    output_path: str = None,
) -> List[Dict]:
    """对统一抽取结果做归一化（写回 extraction_results 中）。

    只有 IMCS（has_norm_field=True）需要归一化；
    其他数据集直接 passthrough。
    """
    if not items:
        return extraction_results

    if not items[0].has_norm_field:
        print(f"\n  ⏩ 数据集类型 [{items[0].dataset_type}] 无归一化字段，跳过 Step 5")
        # 把 reflected_entities 直接拷贝为 normalized_entities，保持接口一致
        for item_result in extraction_results:
            for ch in item_result.get("chunks", []):
                ch["normalized_entities"] = [
                    {"entity": e["entity"], "type": e["type"],
                     "normed": e["entity"], "method": "passthrough"}
                    for e in ch.get("reflected_entities", [])
                ]
            pred_norm = set()
            for ch in item_result.get("chunks", []):
                for e in ch["normalized_entities"]:
                    pred_norm.add(e["normed"])
            item_result["step2_pred_str"] = ",".join(sorted(pred_norm))
        return extraction_results

    print(f"\n  🔧 IMCS 归一化启动 | use_llm_fallback={use_llm_fallback}")

    # 准备资源
    oral_map, norm_vocab = _build_norm_resources()
    learned_oral_map = {}
    if knowledge is not None:
        learned_oral_map = getattr(knowledge, "aligned_oral_to_norm", {}) or {}
        # 把学习到的 norm 也并入 vocab
        for nm in getattr(knowledge, "norm_vocab", []) or []:
            norm_vocab.add(nm)

    norm_vocab_list = sorted(norm_vocab)
    print(f"    词表大小: {len(norm_vocab_list)} | "
          f"oral_map: {len(oral_map)} | learned_oral: {len(learned_oral_map)}")

    # ---------- 第一遍：规则归一化 ----------
    all_failed = []      # (item_idx, chunk_idx, ent_idx, entity)
    method_counter = Counter()

    for ii, item_result in enumerate(extraction_results):
        for ci, ch in enumerate(item_result.get("chunks", [])):
            normed_list = []
            for ei, e in enumerate(ch.get("reflected_entities", [])):
                ent_text = e["entity"]
                res = _rule_based_normalize(ent_text, oral_map,
                                             learned_oral_map, norm_vocab)
                method_counter[res["method"]] += 1
                normed_list.append({
                    "entity":  ent_text,
                    "type":    e.get("type", ""),
                    "normed":  res["normed"],
                    "method":  res["method"],
                })
                if res["normed"] is None:
                    all_failed.append((ii, ci, ei, ent_text))
            ch["normalized_entities"] = normed_list

    print(f"    规则归一化结果分布:")
    for m, c in method_counter.most_common():
        print(f"      {m}: {c}")

    # ---------- 第二遍：LLM 兜底 ----------
    if use_llm_fallback and all_failed:
        unique_failed = list(set([f[3] for f in all_failed]))
        print(f"    规则失败 {len(all_failed)} 条（去重后 {len(unique_failed)}）")
        norm_ckpt = None
        if output_path:
            dir_ = os.path.dirname(output_path) or "."
            base = os.path.basename(output_path).replace(".json", "")
            norm_ckpt = os.path.join(dir_, f"{base}.norm.ckpt.jsonl")
        llm_map = _llm_normalize_batch(unique_failed, norm_vocab_list,
                                        use_batch=True, ckpt_path=norm_ckpt)
        success_n = sum(1 for v in llm_map.values() if v)
        print(f"    LLM 兜底成功: {success_n}/{len(unique_failed)}")

        # 回填
        for (ii, ci, ei, oral) in all_failed:
            normed = llm_map.get(oral)
            ch = extraction_results[ii]["chunks"][ci]
            ent_record = ch["normalized_entities"][ei]
            if normed:
                ent_record["normed"] = normed
                ent_record["method"] = "llm_fallback"

    # ---------- 写 pred 字符串 ----------
    for item_result in extraction_results:
        pred_norm = set()
        for ch in item_result.get("chunks", []):
            for e in ch.get("normalized_entities", []):
                if e.get("normed"):
                    pred_norm.add(e["normed"])
        item_result["step2_pred_str"] = ",".join(sorted(pred_norm))

    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(extraction_results, f, ensure_ascii=False, indent=2)
        print(f"\n  ✅ 归一化结果已保存: {output_path}")

    return extraction_results


# ==================== 评估 2：归一化后 ====================

def evaluate_normalized(items: List[DataItem],
                        extraction_results: List[Dict],
                        name: str = "归一化后") -> Dict:
    """归一化后字符串集合 F1
    - 对有 norm 字段的数据集（IMCS），gold 用 norm 字段
    - 对其他数据集，等同于 evaluate_raw_extraction（passthrough）
    """
    use_norm = items[0].has_norm_field if items else False

    gold_chunks = {}
    for item in items:
        for chunk in item.text_chunks:
            cid = chunk["id"]
            gold_chunks[cid] = get_gold_set_for_chunk(item, cid, use_norm=use_norm)

    pred_chunks = {}
    for item_result in extraction_results:
        for ch in item_result.get("chunks", []):
            normed = set()
            for e in ch.get("normalized_entities", []):
                if e.get("normed"):
                    normed.add(e["normed"])
            pred_chunks[ch["id"]] = normed

    gold_list, pred_list = [], []
    for cid in gold_chunks:
        gold_list.append(gold_chunks[cid])
        pred_list.append(pred_chunks.get(cid, set()))

    result = compute_set_f1(gold_list, pred_list)
    print_eval_report(name, result)
    return result
