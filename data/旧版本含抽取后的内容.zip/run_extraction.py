import pandas as pd
import os
import re
import ast
import torch
import numpy as np
from functools import lru_cache
from tqdm import tqdm
from sentence_transformers import SentenceTransformer, util
import spacy

# ================= 配置 =================
BASE_DIR = "/root/autodl-tmp/MedNER_Project"

# 输入与输出
NER_OUTPUT_PATH = os.path.join(BASE_DIR, "outputs", "final_kg_expanded.csv")
SAVE_PATH = os.path.join(BASE_DIR, "outputs", "step4_context_extracted.csv")

# 🟢 [核心参数]
INITIAL_WINDOW = 64     # 初始硬窗口大小 (Core Window)
LOOKAHEAD_WINDOW = 128   # 前瞻/感知窗口大小 (用于打分)
STEP_SIZE = 64             # 步进大小 (确认相关后加入的内容长度)
MAX_TOTAL_LEN = 512        # 最大总长度限制
SEMANTIC_THRESHOLD = 0.65  # 扩张停止阈值 (Score低于此值则停止)

# 🟢 [评分权重参数]
SEMANTIC_WEIGHT = 10.0     # alpha: 语义相似度权重
SYNTATIC_BONUS = 5.0       # beta:  句法依存强关联奖励
KEYWORD_BONUS = 3.0        # gamma: 关键词硬规则奖励
DISTANCE_PENALTY = 0.5     # delta: 距离惩罚系数

# 🟢 [模型配置]
# 1. 语义模型 (BGE)
LOCAL_BGE_PATH = "/root/autodl-tmp/MedNER_Project/models/bge-small-zh-v1.5"
ONLINE_BGE_NAME = "BAAI/bge-small-zh-v1.5"
# 2. 句法模型 (Spacy)
SPACY_MODEL_NAME = "zh_core_web_sm"

# 🟢 [关键词表] (句法分析的重点关注对象)
ASSERTION_CUES = ["未见", "否认", "排除", "无", "不伴", "未闻及", "查体", "诊断", "显示", "提示", "既往"]

# =======================================
# 🚀 引擎加载 (双单例模式)
# =======================================
class EngineRoom:
    _semantic_model = None
    _syntactic_model = None

    @classmethod
    def get_semantic_model(cls):
        """加载 BGE 向量模型 (Neuro Engine)"""
        if cls._semantic_model is None:
            print(f"🤖 [Neuro] 正在加载 BGE 语义模型...")
            device = "cuda" if torch.cuda.is_available() else "cpu"
            if os.path.exists(LOCAL_BGE_PATH):
                print(f"   ✅ 加载本地: {LOCAL_BGE_PATH}")
                cls._semantic_model = SentenceTransformer(LOCAL_BGE_PATH, device=device)
            else:
                print(f"   ⚠️ 加载在线: {ONLINE_BGE_NAME}")
                cls._semantic_model = SentenceTransformer(ONLINE_BGE_NAME, device=device)
        return cls._semantic_model

    @classmethod
    def get_syntactic_model(cls):
        """加载 Spacy 句法模型 (Symbolic Engine)"""
        if cls._syntactic_model is None:
            print(f"🧠 [Symbolic] 正在加载 Spacy 句法模型 ({SPACY_MODEL_NAME})...")
            try:
                # 禁用 NER 等组件以提速，只保留 Parser (句法分析器)
                cls._syntactic_model = spacy.load(SPACY_MODEL_NAME, disable=["ner"])
            except Exception as e:
                print(f"❌ Spacy 模型加载失败: {e}")
                print("   👉 请运行: python -m spacy download zh_core_web_sm")
                return None
        return cls._syntactic_model

# =======================================
# 🛠️ 核心算法函数
# =======================================

def calculate_dependency_relevance(nlp, target, text_segment):
    """
    🟢 [Symbolic Engine] 句法依存分析
    计算 target(实体) 和 text_segment(前瞻文本) 之间的“语法距离”。
    原理：构造临时句子 "{Target}，{Segment}"，分析依存树路径。
    """
    if not nlp or not text_segment.strip(): return 0.0
    
    # 优化：如果前瞻文本里没有关键线索词，没必要做昂贵的句法分析
    if not any(cue in text_segment for cue in ASSERTION_CUES): return 0.0

    # 构造临时句子进行分析 (逗号连接以模拟从句关系)
    combined_text = f"{target}，{text_segment}"
    try:
        doc = nlp(combined_text)
    except:
        return 0.0

    target_token = None
    cue_tokens = []

    # 遍历 Token 寻找实体和关键词
    for token in doc:
        if target in token.text or token.text in target:
            if not target_token: target_token = token
        if token.text in ASSERTION_CUES:
            cue_tokens.append(token)

    if not target_token or not cue_tokens: return 0.0

    max_score = 0.0
    for cue in cue_tokens:
        score = 0.0
        # 情况A: 关键词直接支配实体 (Ancestor关系)
        # 例如: "否认(Head) -> ... -> 高血压(Child)"
        if cue in target_token.ancestors:
            distance = 0
            temp = target_token
            # 计算树上的跳数距离
            while temp != cue and temp != temp.head and distance < 5:
                temp = temp.head
                distance += 1
            # 距离越近，分数越高
            score = max(0, 1.0 - (distance * 0.2))
        
        # 情况B: 关键词和实体是兄弟节点 (Head相同)
        # 例如: "无(Obj) -> 症状(Head) <- 高血压(Obj)"
        elif cue.head == target_token.head:
            score = 0.8
            
        max_score = max(max_score, score)

    return max_score

def calculate_hybrid_score(sem_model, syn_model, target, candidate_text, step_count):
    """
    🟢 [Hybrid Scoring] 双引擎混合打分
    公式: Score = (Sem * 10) + (Syn_Bonus) + (Key_Bonus) - (Dist_Penalty)
    """
    if not candidate_text.strip(): return 0.0

    # 1. 语义相似度 (Neuro)
    emb = sem_model.encode([target, candidate_text], convert_to_tensor=True, show_progress_bar=False)
    sim_score = util.cos_sim(emb[0], emb[1]).item()
    
    # 2. 句法依存分 (Symbolic - Deep)
    syn_score = calculate_dependency_relevance(syn_model, target, candidate_text)
    
    # 3. 关键词硬规则 (Symbolic - Surface)
    keyword_bonus = KEYWORD_BONUS if any(c in candidate_text for c in ASSERTION_CUES) else 0.0
    
    # 4. 距离惩罚 (Step Count: 扩展了多少步)
    dist_penalty = step_count * DISTANCE_PENALTY
    
    # 特殊通道：如果句法关系极强（直接否定），强制高分放行
    if syn_score >= 0.8:
        return 100.0 
    
    # 加权求和
    final_score = (sim_score * SEMANTIC_WEIGHT) + (syn_score * SYNTATIC_BONUS) + keyword_bonus - dist_penalty
    return final_score

def extract_context_fusion(row):
    """
    🟢 终极抽取主流程：
    1. 中心锚定 -> 2. 初始硬窗口(64) -> 3. 语义前瞻+动态步进(128->64)
    """
    full_text = str(row.get('text', ''))
    target = str(row.get('target_word', ''))
    
    if not full_text or not target: return ""

    # --- Step 1: 中心锚定策略 (Centrality Anchoring) ---
    positions = [m.start() for m in re.finditer(re.escape(target), full_text)]
    
    if not positions: 
        # 兜底：若找不到实体(可能因清洗导致)，返回前64字
        return full_text[:INITIAL_WINDOW]
    
    # 计算离文本几何中心最近的实体位置
    text_center = len(full_text) // 2
    anchor_start = min(positions, key=lambda p: abs(p - text_center))
    anchor_end = anchor_start + len(target)
    anchor_center = (anchor_start + anchor_end) // 2

    # --- Step 2: 初始硬窗口 (Initial Hard Window) ---
    # 逻辑：如果原文 < 64，直接返回全文（不丢弃任何信息）
    if len(full_text) <= INITIAL_WINDOW:
        return full_text

    half_win = INITIAL_WINDOW // 2
    curr_l = max(0, anchor_center - half_win)
    curr_r = min(len(full_text), anchor_center + half_win)

    # --- Step 3: 语义前瞻 + 动态步进 (Lookahead & Step) ---
    # 只有当原文很长时，才进行扩展
    
    sem_model = EngineRoom.get_semantic_model()
    syn_model = EngineRoom.get_syntactic_model()
    
    steps_taken = 0 # 记录步数，用于计算距离惩罚

    while (curr_r - curr_l) < MAX_TOTAL_LEN:
        expanded = False
        steps_taken += 1
        
        candidates = []

        # [Lookahead Left]
        if curr_l > 0:
            look_start = max(0, curr_l - LOOKAHEAD_WINDOW)
            look_segment = full_text[look_start : curr_l]
            # 打分
            score_l = calculate_hybrid_score(sem_model, syn_model, target, look_segment, steps_taken)
            candidates.append(('left', score_l))

        # [Lookahead Right]
        if curr_r < len(full_text):
            look_end = min(len(full_text), curr_r + LOOKAHEAD_WINDOW)
            look_segment = full_text[curr_r : look_end]
            # 打分
            score_r = calculate_hybrid_score(sem_model, syn_model, target, look_segment, steps_taken)
            candidates.append(('right', score_r))

        if not candidates: break

        # 贪心决策：选分高的方向
        direction, best_score = max(candidates, key=lambda x: x[1])

        # 🛑 [核心去噪]：如果最佳方向的分数都不达标，说明是无关信息，丢弃并停止
        if best_score >= SEMANTIC_THRESHOLD:
            if direction == 'left':
                # 步进：确认相关后，只吃进 STEP_SIZE (64)，而不是 Lookahead (128)
                step_start = max(0, curr_l - STEP_SIZE)
                curr_l = step_start
            else:
                step_end = min(len(full_text), curr_r + STEP_SIZE)
                curr_r = step_end
            expanded = True

        # 如果这一轮两边都没扩展（都判定为无关），则彻底结束
        if not expanded:
            break

    # 提取最终文本
    final_context = full_text[curr_l : curr_r]
    # 简单的边界清洗
    return final_context.strip().strip("，,。.")

def main():
    print("==================================================")
    print("🚀 [Step 4] 启动终极融合抽取：中心锚定 + 双引擎评分 + 动态步进")
    print("==================================================")
    print(f"📌 参数配置: Init={INITIAL_WINDOW} | Lookahead={LOOKAHEAD_WINDOW} | Step={STEP_SIZE} | Thresh={SEMANTIC_THRESHOLD}")
    
    if not os.path.exists(NER_OUTPUT_PATH):
        print(f"❌ 输入文件不存在: {NER_OUTPUT_PATH}"); return

    df = pd.read_csv(NER_OUTPUT_PATH)
    
    # =========================================================================
    # 🟢 [核心修复] 安全的列名映射，防止产生同名的 target_word 列
    # =========================================================================
    # 1. 重置索引，防止由于 Step 3 的 explode 导致潜在的重复 Index 报错
    df = df.reset_index(drop=True)
    
    # 2. 映射原文
    if 'original_text' in df.columns:
        df.rename(columns={'original_text': 'text'}, inplace=True)
        
    # 3. 精准锁定目标实体列 (优先使用 Step 3 拆分出来的 target_entity)
    if 'target_entity' in df.columns:
        df.rename(columns={'target_entity': 'target_word'}, inplace=True)
    elif 'filtered_entities' in df.columns:
        df.rename(columns={'filtered_entities': 'target_word'}, inplace=True)
    elif 'entity' in df.columns:
        df.rename(columns={'entity': 'target_word'}, inplace=True)
    
    # 实体预处理
    def clean_ent(x): return str(x).strip("[]' ") 
    
    # 强制确保目标列变成了字符串（兜底容错）
    df['target_word'] = df['target_word'].astype(str).apply(clean_ent)
    
    # 过滤掉空实体
    df = df[(df['target_word'] != '') & (df['target_word'] != 'nan')]

    # 预加载模型 (触发单例)
    EngineRoom.get_semantic_model()
    EngineRoom.get_syntactic_model()
    
    # 运行抽取
    tqdm.pandas(desc="Processing")
    df['context'] = df.progress_apply(extract_context_fusion, axis=1)
    
    # 过滤无效结果
    df = df[df['context'].str.strip() != '']
    
    cols = ['target_word', 'context', 'text']
    if 'kg_knowledge' in df.columns: cols.append('kg_knowledge')
    
    df[cols].drop_duplicates().to_csv(SAVE_PATH, index=False, encoding='utf-8-sig')
    print(f"\n✅ 抽取完成! 结果已保存至: {SAVE_PATH}")
    print(f"📊 总样本数: {len(df)}")
    
    # 打印效果预览
    if len(df) > 0:
        print("\n👀 [Preview] 前3条结果:")
        for i in range(min(3, len(df))):
            print(f"🎯 实体: {df.iloc[i]['target_word']}")
            print(f"📝 窗口: {df.iloc[i]['context']}")
            print("-" * 50)

if __name__ == "__main__":
    main()