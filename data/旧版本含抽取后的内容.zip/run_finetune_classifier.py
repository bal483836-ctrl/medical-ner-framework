import argparse
import pandas as pd
import torch
import numpy as np
import gc
import os
import random
import re
import json
import scipy.special
import sys
import torch.nn.functional as F
from torch import nn
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
from sklearn.utils.class_weight import compute_class_weight
from datasets import Dataset # 🌟 核心修复：补充缺失的 Dataset 导入
from transformers import (
    AutoTokenizer, 
    AutoModelForSequenceClassification, 
    AutoModelForCausalLM,
    Trainer, 
    TrainingArguments,
    DataCollatorWithPadding,
    AutoConfig,
    BertTokenizer
)
from transformers.trainer_utils import get_last_checkpoint  # 🌟 引入断点续训探针

# 🟢 动态导入基准断言逻辑
try:
    from run_llm_assertion import USER_PROMPT_TEMPLATE as ASSERTION_PROMPT
    from run_llm_assertion import SYSTEM_PROMPT as ASSERTION_SYS_PROMPT
    from run_llm_assertion import extract_status_from_text
except ImportError:
    sys.path.append("/root/autodl-tmp/MedNER_Project")
    from run_llm_assertion import USER_PROMPT_TEMPLATE as ASSERTION_PROMPT
    from run_llm_assertion import SYSTEM_PROMPT as ASSERTION_SYS_PROMPT
    from run_llm_assertion import extract_status_from_text

# ==========================================
# 🟢 1. 全局配置与参数定义
# ==========================================
try:
    import config
    QWEN_MODEL_PATH = config.LLM_MODEL_PATH
    ROBERTA_MODEL_PATH = config.BERT_MODEL_PATH
except ImportError:
    QWEN_MODEL_PATH = "/root/autodl-tmp/MedNER_Project/models/Qwen2.5-7B-Instruct" 
    ROBERTA_MODEL_PATH = "/root/autodl-tmp/MedNER_Project/models/chinese-roberta-wwm-ext"

LLM_BATCH_SIZE = 2  

parser = argparse.ArgumentParser(description="医疗断言微调 (生产版: 实体标记 + 定向增强 + 断点续训)")
parser.add_argument("--model_name", type=str, default=ROBERTA_MODEL_PATH)
parser.add_argument("--input_file", type=str, default="outputs/step5_assertion_results.csv")
parser.add_argument("--output_dir", type=str, default="models/bert_finetuned_final") # 🌟 修改为 final 目录

# 🌟 核心优化：嵌入 Optuna 搜索出的终极黄金参数 🌟
parser.add_argument("--epochs", type=int, default=7)
parser.add_argument("--batch_size", type=int, default=16) 
parser.add_argument("--lr", type=float, default=3.38e-5)
parser.add_argument("--aug_ratio", type=float, default=3.0)
parser.add_argument("--focal_gamma", type=float, default=1.6) 
parser.add_argument("--fgm_eps", type=float, default=0.11)
parser.add_argument("--weight_decay", type=float, default=0.01)
parser.add_argument("--warmup_ratio", type=float, default=0.13) 
parser.add_argument("--test_size", type=float, default=0.1)
args = parser.parse_args()

def seed_everything(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# ==========================================
# 🛡️ 2. FGM 与 Focal Loss 组件
# ==========================================
class FGM:
    def __init__(self, model):
        self.model = model
        self.backup = {}
    def attack(self, epsilon=1.0, emb_name='word_embeddings'):
        for name, param in self.model.named_parameters():
            if param.requires_grad and emb_name in name:
                self.backup[name] = param.data.clone()
                norm = torch.norm(param.grad)
                if norm != 0 and not torch.isnan(norm):
                    r_at = epsilon * param.grad / norm
                    param.data.add_(r_at)
    def restore(self, emb_name='word_embeddings'):
        for name, param in self.model.named_parameters():
            if param.requires_grad and emb_name in name:
                param.data = self.backup[name]
        self.backup = {}

class FocalLoss(nn.Module):
    def __init__(self, alpha=None, gamma=2.0, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha; self.gamma = gamma; self.reduction = reduction
    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = (1 - pt) ** self.gamma * ce_loss
        if self.alpha is not None:
            alpha_t = self.alpha.gather(0, targets)
            focal_loss = focal_loss * alpha_t
        return focal_loss.mean() if self.reduction == 'mean' else focal_loss.sum()

class AdvancedTrainer(Trainer):
    def __init__(self, class_weights=None, gamma=2.0, epsilon=0.5, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if class_weights is not None:
            weight_tensor = torch.tensor(class_weights).float().to(self.args.device)
            self.loss_fct = FocalLoss(alpha=weight_tensor, gamma=gamma)
        else:
            self.loss_fct = nn.CrossEntropyLoss()
        self.epsilon = epsilon

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        labels = inputs.get("labels")
        outputs = model(**inputs)
        logits = outputs.get("logits")
        loss = self.loss_fct(logits.view(-1, self.model.config.num_labels), labels.view(-1))
        return (loss, outputs) if return_outputs else loss
        
    def training_step(self, model, inputs, num_items_in_batch=None, **kwargs):
        model.train()
        inputs = self._prepare_inputs(inputs)
        with self.compute_loss_context_manager():
            loss = self.compute_loss(model, inputs)
        if self.args.n_gpu > 1: loss = loss.mean()
        if self.args.gradient_accumulation_steps > 1: loss = loss / self.args.gradient_accumulation_steps
        self.accelerator.backward(loss, retain_graph=True)
        
        fgm = FGM(model)
        fgm.attack(epsilon=self.epsilon)
        with self.compute_loss_context_manager():
            loss_adv = self.compute_loss(model, inputs)
        if self.args.n_gpu > 1: loss_adv = loss_adv.mean()
        if self.args.gradient_accumulation_steps > 1: loss_adv = loss_adv / self.args.gradient_accumulation_steps
        self.accelerator.backward(loss_adv) 
        fgm.restore() 
        return loss.detach()

# ==========================================
# 🧠 4. 数据增强 (定向指令增强版)
# ==========================================
def clean_think_tags(text):
    if not isinstance(text, str): return ""
    text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL).strip()
    text = re.sub(r'<think>.*', '', text, flags=re.DOTALL).strip()
    return text

# 🌟 核心优化：动态生成重写指令，针对性增强缺乏的语境
def get_rewrite_prompt(entity, context, label):
    if label == 0: # 增强阴性样本
        return f"""你是一个医疗文本生成专家。请生成一句包含实体【{entity}】的【阴性/否定】医疗描述。
要求：句型要极度多样化（例如：使用“否认”、“未见”、“不伴”、“排除”、“无...症状”等不同表达方式）。
参考上下文：{context}
【硬约束：严禁输出任何思考过程，直接输出生成的话，不要任何多余字符！】"""
    else: # 增强阳性样本
        return f"""你是一个医疗文本生成专家。请改写下面的医疗文本，保持【阳性/存在】的语义不变，但变换句型结构。
必须包含核心实体：【{entity}】。
原始文本：{context}
【硬约束：严禁输出任何思考过程，直接输出生成的话，不要任何多余字符！】"""

def generate_train_aug_data(minority_df, target_count, output_path, model, tokenizer):
    if target_count <= 0: return

    sample_pool_size = int(target_count * 3.0)
    source_samples = minority_df.sample(n=sample_pool_size, replace=True, random_state=42)
    records = source_samples.to_dict('records')
    
    buffer = []; valid_count = 0
    pbar = tqdm(total=len(records), desc=f"数据增强处理进度") 

    for i in range(0, len(records), LLM_BATCH_SIZE):
        if valid_count >= target_count: break
        batch = records[i : i + LLM_BATCH_SIZE]
        
        rewrite_prompts = []
        for row in batch:
            # 🌟 核心优化：使用动态 prompt 进行增强
            prompt = get_rewrite_prompt(row['entity'], row['context'], row['label'])
            messages = [{"role": "system", "content": "You are a direct and concise medical assistant. NEVER output <think> tags."}, {"role": "user", "content": prompt}]
            rewrite_prompts.append(tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True))

        try:
            inputs = tokenizer(rewrite_prompts, return_tensors="pt", padding=True, truncation=True, max_length=1024).to(model.device)
            torch.manual_seed(42 + i) 
            with torch.no_grad():
                outputs = model.generate(**inputs, max_new_tokens=512, do_sample=True, temperature=0.6, pad_token_id=tokenizer.eos_token_id)
            raw_contexts = tokenizer.batch_decode(outputs[:, inputs.input_ids.shape[1]:], skip_special_tokens=True)
            new_contexts = [clean_think_tags(text) for text in raw_contexts]
        except Exception as e: 
            print(f"\n⚠️ 文本改写阶段报错: {e}"); pbar.update(len(batch)); continue

        verify_prompts = []
        for j, nc in enumerate(new_contexts):
            ent = batch[j]['entity']
            marked_text = nc.replace(ent, f"[E]{ent}[/E]", 1) if ent in nc else f"{nc} (目标: [E]{ent}[/E])"
            prompt = ASSERTION_PROMPT.format(marked_text=marked_text, entity_name=ent) + "\n【硬约束】直接输出JSON，严禁输出 <think>！"
            messages = [{"role": "system", "content": "NEVER use <think> tags. Output ONLY JSON."}, {"role": "user", "content": prompt}]
            verify_prompts.append(tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True))

        try:
            inputs_v = tokenizer(verify_prompts, return_tensors="pt", padding=True, truncation=True, max_length=1024).to(model.device)
            with torch.no_grad():
                outputs_v = model.generate(**inputs_v, max_new_tokens=256, do_sample=False, pad_token_id=tokenizer.eos_token_id)
            raw_verify = tokenizer.batch_decode(outputs_v[:, inputs_v.input_ids.shape[1]:], skip_special_tokens=True)
            verify_results = [clean_think_tags(text) for text in raw_verify]
        except Exception as e: 
            print(f"\n⚠️ 断言验证阶段报错: {e}"); pbar.update(len(batch)); continue

        for k, res in enumerate(verify_results):
            if valid_count >= target_count: break
            
            status = extract_status_from_text(res)
            orig_label = batch[k]['label']
            is_valid = False
            if orig_label == 1 and status in ['Present', 'Possible', 'General']: is_valid = True
            elif orig_label == 0 and status == 'Absent': is_valid = True
            
            if k == 0 and (i // LLM_BATCH_SIZE) % 5 == 0:  
                print("\n" + "-"*60)
                print(f"⚡ [光速探针] (净化后)")
                print(f"🔹 扩写结果: {new_contexts[k]}")
                print(f"🔹 验证判定: [{status}] -> {'✅ 收录' if is_valid else '❌ 丢弃'}")
                print("-"*60 + "\n")

            if is_valid and new_contexts[k].strip():
                new_row = batch[k].copy()
                new_row['context'] = new_contexts[k].strip()
                ent, ctx = new_row['entity'], new_row['context']
                kg = str(new_row.get('kg_knowledge', '无关联知识'))
                if kg == 'nan' or not kg.strip(): kg = '无关联知识'
                
                new_row['query'] = f"实体：{ent} 知识：{kg}"
                
                # 🌟 核心优化同步：在扩写后加入实体标记
                if ent in ctx:
                    marked_ctx = ctx.replace(ent, f"【{ent}】", 1) 
                else:
                    marked_ctx = f"【{ent}】{ctx}"
                new_row['context_text'] = f"语境：{marked_ctx}"
                
                buffer.append(new_row)
                valid_count += 1

        if len(buffer) >= 32:
            pd.DataFrame(buffer).to_csv(output_path, mode='a', header=not os.path.exists(output_path), index=False, encoding='utf-8-sig')
            buffer = []

        pbar.update(len(batch))
        pbar.set_postfix({'已收录': valid_count, '目标': target_count})

    pbar.close()
    if buffer: pd.DataFrame(buffer).to_csv(output_path, mode='a', header=not os.path.exists(output_path), index=False, encoding='utf-8-sig')

# ==========================================
# 📊 5. 主流程
# ==========================================
def main():
    seed_everything(42)
    os.makedirs(args.output_dir, exist_ok=True)
    print(f"📂 读取原始数据: {args.input_file}")
    df = pd.read_csv(args.input_file)
    
    def strict_label(x):
        x_str = str(x).lower()
        if any(k in x_str for k in ['present', 'positive', 'possible', 'general']): return 1
        elif any(k in x_str for k in ['absent', 'negative']): return 0
        else: return -1

    if 'assertion' in df.columns:
        df['label'] = df['assertion'].apply(strict_label)
        df = df[df['label'] != -1]

    step4_file = os.path.join(os.path.dirname(args.input_file), "step4_context_extracted.csv")
    if os.path.exists(step4_file):
        df4 = pd.read_csv(step4_file)
        if 'kg_knowledge' in df4.columns:
            df4 = df4.rename(columns={'target_word': 'entity'}).drop_duplicates(subset=['entity', 'context'])
            df = pd.merge(df, df4[['entity', 'context', 'kg_knowledge']], on=['entity', 'context'], how='left')

    if 'kg_knowledge' not in df.columns: df['kg_knowledge'] = '无关联知识'
    df['query'] = "实体：" + df['entity'].astype(str) + " 知识：" + df['kg_knowledge'].astype(str)
    
    # 🌟 核心优化：构建带有【实体】标记的语境，彻底解决 BERT 无法对焦多实体的问题
    def add_entity_markers(row):
        ctx = str(row['context'])
        ent = str(row['entity'])
        if ent in ctx:
            marked_ctx = ctx.replace(ent, f"【{ent}】", 1) 
        else:
            marked_ctx = f"【{ent}】{ctx}" 
        return f"语境：{marked_ctx}"

    df['context_text'] = df.apply(add_entity_markers, axis=1)
    
    df = df[['query', 'context_text', 'label', 'entity', 'context', 'kg_knowledge']].dropna(subset=['query', 'context_text', 'label'])
    df['label'] = df['label'].astype(int)

    count_0, count_1 = len(df[df['label']==0]), len(df[df['label']==1])
    print(f"\n📊 真实有效数据分布 -> 阴性(0): {count_0} | 阳性(1): {count_1}")

    # 🌟 核心猛药：将降采样比例从 1:4 压榨至 1:2，强迫模型停止偏袒阳性！
    if count_1 > count_0 * 2:
        print(f"📉 触发强力降采样机制：随机保留 {count_0 * 2} 条阳性数据以彻底破除惰性...")
        df_0 = df[df['label'] == 0]
        df_1 = df[df['label'] == 1].sample(n=count_0 * 2, random_state=42)
        df = pd.concat([df_0, df_1]).sample(frac=1, random_state=42).reset_index(drop=True)

    train_df, val_df = train_test_split(df, test_size=args.test_size, random_state=42, stratify=df['label'])
    train_df, val_df = train_df.reset_index(drop=True), val_df.reset_index(drop=True)
    
    aug_file_path = os.path.join(args.output_dir, "train_aug_v10_markers.csv") # 更新文件名以便区分
    
    if not os.path.exists(aug_file_path):
        try:
            print("\n🤖 加载 Qwen 进行光速补充增强 (启用定向指令增强)...")
            qwen_tokenizer = AutoTokenizer.from_pretrained(QWEN_MODEL_PATH, trust_remote_code=True)
            qwen_tokenizer.padding_side = 'left'
            qwen_model = AutoModelForCausalLM.from_pretrained(QWEN_MODEL_PATH, device_map="auto", torch_dtype="auto", trust_remote_code=True).eval()

            t_count_0, t_count_1 = len(train_df[train_df['label']==0]), len(train_df[train_df['label']==1])
            major_df = train_df[train_df['label']==0] if t_count_0 > t_count_1 else train_df[train_df['label']==1]
            minor_df = train_df[train_df['label']==1] if t_count_0 > t_count_1 else train_df[train_df['label']==0]
            
            ratio = len(major_df) / len(minor_df) if len(minor_df) > 0 else 0
            if ratio > 1.2:
                target_count = min(int(len(minor_df) * args.aug_ratio) - len(minor_df), len(major_df) - len(minor_df)) 
                if target_count > 0:
                    generate_train_aug_data(minor_df, target_count, aug_file_path, qwen_model, qwen_tokenizer)
            
            del qwen_model, qwen_tokenizer
            torch.cuda.empty_cache()
            gc.collect()
        except Exception as e: print(f"❌ 增强出错跳过: {e}")

    print("\n" + "="*50)
    print(f"🚀 启动 BERT 分类器 (实体对焦版 + FGM + FocalLoss Gamma={args.focal_gamma})")
    print("="*50)

    # 🟢 修复：老老实实加载本地下载好的模型！
    try:
        os.environ["HF_ENDPOINT"] = "https://mirrors.aliyun.com/huggingface" # 注入阿里镜像防患于未然
        bert_tokenizer = BertTokenizer.from_pretrained(args.model_name) 
    except Exception as e:
        print(f"❌ 分词器加载失败，请检查本地模型文件: {e}")
        return

    def tokenize(batch):
        return bert_tokenizer(batch["query"], batch["context_text"], padding="max_length", truncation=True, max_length=512)
    
    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        probs = scipy.special.softmax(logits, axis=1)[:, 1] 
        preds_default = (probs >= 0.5).astype(int)
        
        print("\n" + "="*60)
        print("📈 验证集综合体检报告 (默认判定阈值 0.5)")
        print("-" * 60)
        print(classification_report(labels, preds_default, target_names=["阴性(0)", "阳性(1)"], digits=4))
        
        cm = confusion_matrix(labels, preds_default)
        print("🎯 混淆矩阵:")
        print(f"      真实 \\ 预测 |  猜阴性(0)  |  猜阳性(1)")
        print(f"      ------------|-------------|------------")
        print(f"       实际阴性(0) |   TN: {cm[0][0]:<5} |   FP: {cm[0][1]:<5}")
        print(f"       实际阳性(1) |   FN: {cm[1][0]:<5} |   TP: {cm[1][1]:<5}")
        print("="*60)

        best_f1, best_thresh = 0, 0.5
        for thresh in np.arange(0.1, 0.95, 0.05):
            t_preds = (probs >= thresh).astype(int)
            t_f1 = f1_score(labels, t_preds, average='macro')
            if t_f1 > best_f1: best_f1 = t_f1; best_thresh = thresh
                
        print(f"💡 【模型潜能突破】如果将区分阈值设为 {best_thresh:.2f}，你的 F1 Macro 可达 -> {best_f1:.4f}！")
        print("="*60 + "\n")
        return {"accuracy": accuracy_score(labels, preds_default), "f1_macro": f1_score(labels, preds_default, average='macro')}

    if os.path.exists(aug_file_path):
        aug_df = pd.read_csv(aug_file_path)
        train_df = pd.concat([train_df[['query', 'context_text', 'label']], aug_df[['query', 'context_text', 'label']]]).sample(frac=1, random_state=42).reset_index(drop=True)
    
    classes = np.unique(train_df['label'])
    weights = compute_class_weight(class_weight='balanced', classes=classes, y=train_df['label'])
    weights = weights / np.max(weights)  
    class_weights_list = weights.tolist()

    train_dataset = Dataset.from_pandas(train_df).map(tokenize, batched=True)
    val_dataset = Dataset.from_pandas(val_df).map(tokenize, batched=True)

    config_bert = AutoConfig.from_pretrained(args.model_name, num_labels=2)
    config_bert.hidden_dropout_prob = 0.15 
    config_bert.attention_probs_dropout_prob = 0.15
    model = AutoModelForSequenceClassification.from_pretrained(args.model_name, config=config_bert)
    model.to(torch.device("cuda" if torch.cuda.is_available() else "cpu"))

    checkpoint_dir = os.path.join(args.output_dir, "checkpoint")
    training_args = TrainingArguments(
        output_dir=checkpoint_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="f1_macro",
        logging_steps=50,
        learning_rate=args.lr,
        weight_decay=args.weight_decay,
        warmup_ratio=args.warmup_ratio,
        save_total_limit=2,  # 保存最新的 2 个 checkpoint 防止意外覆盖
        seed=42, report_to="none"
    )

    trainer = AdvancedTrainer(
        class_weights=class_weights_list, gamma=args.focal_gamma, epsilon=args.fgm_eps, 
        model=model, args=training_args, train_dataset=train_dataset, eval_dataset=val_dataset,
        tokenizer=bert_tokenizer, data_collator=DataCollatorWithPadding(bert_tokenizer), compute_metrics=compute_metrics
    )

    last_checkpoint = None
    if os.path.isdir(checkpoint_dir):
        last_checkpoint = get_last_checkpoint(checkpoint_dir)
        if last_checkpoint is not None:
            print(f"\n🔋 检测到历史训练节点 ({last_checkpoint})，系统正在自动恢复断线重连！")

    print("\n⏳ 开始训练...")
    trainer.train(resume_from_checkpoint=last_checkpoint)
    
    print("\n📊 最终模型定格评估...")
    metrics = trainer.evaluate()
    
    final_model_dir = os.path.join(args.output_dir, "final")
    trainer.save_model(final_model_dir)
    bert_tokenizer.save_pretrained(final_model_dir)
    print("✅ 终极破局版模型保存完毕！可以用于生产推理。")

if __name__ == "__main__":
    main()