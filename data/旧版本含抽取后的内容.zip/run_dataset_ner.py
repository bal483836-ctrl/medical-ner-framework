import json
import os
import time
import pandas as pd
from tqdm import tqdm
import logging
import random
import numpy as np
import torch

import config
from helper_functions import load_qwen_model, get_qwen_response

# ==========================================
# 1. 生产级日志配置 (双路输出：控制台 + 文件)
# ==========================================
def setup_logger():
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    log_file = os.path.join(config.OUTPUT_DIR, 'extraction_log.txt')
    
    logger = logging.getLogger("NER_Pipeline")
    logger.setLevel(logging.INFO)
    
    # 防止重复添加 Handler
    if not logger.handlers:
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        
        # 文件 Handler
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        # 控制台 Handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
    return logger

logger = setup_logger()

# ==========================================
# 2. 全局设置与数据加载
# ==========================================
def seed_everything(seed=42):
    """锁定所有随机源，确保实验可复现"""
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    logger.info(f"🔒 全局随机种子已锁定: {seed}")

def load_data_robust(file_path):
    """生产级鲁棒数据加载函数"""
    logger.info(f"正在读取数据文件: {file_path}")
    
    if not os.path.exists(file_path):
        logger.error(f"文件不存在: {file_path}")
        return []

    # 模式 1: 标准 JSON (List[Dict] 或 Dict)
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            data = data if isinstance(data, list) else [data]
        logger.info(f"✅ 成功以标准 JSON 格式加载 {len(data)} 条数据。")
        return data
    except json.JSONDecodeError:
        logger.warning("⚠️ 标准 JSON 解析失败，尝试 JSON Lines 模式读取...")

    # 模式 2: JSON Lines 容错模式
    data = []
    valid_count, error_count = 0, 0
    with open(file_path, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line: continue
            
            # 尝试清理可能存在的行尾逗号
            if line.endswith(','): 
                line = line[:-1]
                
            try:
                data.append(json.loads(line))
                valid_count += 1
            except Exception as e:
                error_count += 1
                if error_count <= 5: # 避免日志刷屏，只记录前5个错误
                    logger.warning(f"行 {line_num} 解析失败: {e} | 内容截断: {line[:50]}...")

    logger.info(f"✅ 逐行加载完成: 成功 {valid_count} 条，失败 {error_count} 条。")
    return data

# ==========================================
# 3. 核心推理逻辑 (带重试机制)
# ==========================================
def call_llm_with_retry(model, tokenizer, prompt, max_retries=3):
    """带指数退避的重试机制，防止偶发推理失败"""
    for attempt in range(max_retries):
        try:
            res = get_qwen_response(model, tokenizer, prompt)
            return res
        except Exception as e:
            logger.error(f"调用 LLM 失败 (尝试 {attempt+1}/{max_retries}): {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt) # 指数退避: 1s, 2s, 4s...
            else:
                return "" # 彻底失败后返回空字符串

# ==========================================
# 4. 主流程
# ==========================================
def main():
    seed_everything(42)
    logger.info("=== [Step 1] CMEEE 实体抽取 (生产环境版) 开始 ===")

    # 1. 加载数据
    data = load_data_robust(config.CMEEE_FILE)
    if not data:
        logger.error("❌ 数据加载失败或数据为空，程序终止。")
        return
    
    df = pd.DataFrame(data)
    logger.info(f"准备处理总数据量: {len(df)}")

    # 2. 断点续传 (Checkpointing) 设置
    out_path = os.path.join(config.OUTPUT_DIR, "step1_ner_raw_output.csv")
    results = []
    start_index = 0
    save_interval = 50 # 每 50 条增量保存一次

    if os.path.exists(out_path):
        try:
            existing_df = pd.read_csv(out_path, encoding='utf-8-sig')
            results = existing_df.to_dict('records')
            start_index = len(results)
            logger.info(f"🔄 检测到已有进度，跳过前 {start_index} 条，继续抽取...")
        except Exception as e:
            logger.warning(f"⚠️ 读取历史进度失败，将重新开始: {e}")
            results = []
            start_index = 0

    if start_index >= len(df):
        logger.info("✅ 所有数据已处理完毕，无需重复执行。")
        return

    # 3. 加载模型
    try:
        logger.info("正在加载 Qwen 模型...")
        model, tokenizer = load_qwen_model()
        logger.info("✅ 模型加载成功。")
    except Exception as e:
        logger.error(f"❌ 模型加载发生致命错误: {e}")
        return

    # 4. 批量处理
    # 使用 itertuples 替代 iterrows 提升性能
    for row in tqdm(df.iloc[start_index:].itertuples(index=False), 
                    total=len(df)-start_index, 
                    desc="实体抽取中", 
                    initial=start_index):
        
        # 兼容文本字段名
        text = getattr(row, 'text', getattr(row, 'sentence', ''))
        
        # 过滤无效文本
        if not text or len(str(text)) < 2:
            results.append({"original_text": text, "raw_ner_output": ""})
            continue

        prompt = f"""任务：从中文临床文本中提取【医疗实体】。
实体类别包括：疾病、症状、药物、手术、身体部位、诊疗手段、检查项目。

要求：
1. 仅输出实体名称。
2. 多个实体用英文逗号 ',' 分隔。
3. 如果没有相关实体，直接输出“无”。
4. 严禁输出任何解释、无关文字或标点符号。
s
文本：{text}
实体："""

        # 调用推理 (带重试)
        res = call_llm_with_retry(model, tokenizer, prompt)
        
        # 后处理清洗
        if res:
            res = res.replace("。", "").replace("，", ",").strip()
            if "无" in res and len(res) < 5:
                res = ""
                
        results.append({
            "original_text": text,
            "raw_ner_output": res
        })

        # 增量保存 (防止崩溃导致进度丢失)
        if len(results) % save_interval == 0:
            pd.DataFrame(results).to_csv(out_path, index=False, encoding='utf-8-sig')

    # 5. 最终保存
    try:
        pd.DataFrame(results).to_csv(out_path, index=False, encoding='utf-8-sig')
        logger.info(f"🎉 抽取任务圆满完成！最终结果已保存至: {out_path}")
    except Exception as e:
        logger.error(f"❌ 最终结果保存失败: {e}")

if __name__ == "__main__":
    main()