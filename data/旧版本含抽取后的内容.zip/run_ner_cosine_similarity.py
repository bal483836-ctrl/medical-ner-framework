import pandas as pd
import numpy as np
import os
import torch
import torch.nn.functional as F
from tqdm import tqdm
import config
from helper_functions import load_embedding_model, get_embeddings

# ================= 配置 =================
BATCH_SIZE = 64
SIMILARITY_THRESHOLD = config.COSINE_SIMILARITY_THRESHOLD
# =======================================

def clean_and_split(text):
    """简单的后处理，将LLM输出分割为列表"""
    if not isinstance(text, str): return []
    # 统一分隔符
    text = text.replace("，", ",").replace("\n", ",")
    # 去除空字符和空白
    items = [x.strip() for x in text.split(",") if x.strip()]
    return list(set(items)) # 行内去重

def compute_cosine_similarity_torch(a_vecs, b_vecs):
    """
    使用 PyTorch 进行 GPU 加速的余弦相似度计算
    输入应该是 Numpy Array，函数内部转 Tensor 计算，最后返回 Numpy
    """
    # 转换为 Tensor 并不自动计算梯度
    with torch.no_grad():
        a = torch.tensor(a_vecs)
        b = torch.tensor(b_vecs)
        
        # 归一化 (Cosine Similarity = Dot Product of Normalized Vectors)
        a_norm = F.normalize(a, p=2, dim=1)
        b_norm = F.normalize(b, p=2, dim=1)
        
        # 矩阵乘法: [N, Dim] @ [Dim, M] -> [N, M]
        # 如果数据量极大导致显存溢出，这里可能需要分块，但一般医疗实体数量级够用
        sim_matrix = torch.mm(a_norm, b_norm.t())
        
        # 取每一行的最大值 (即每个候选实体与词典中最相似词的分数)
        max_scores, _ = torch.max(sim_matrix, dim=1)
        
        return max_scores.cpu().numpy()

def run_similarity_filter():
    input_path = os.path.join(config.OUTPUT_DIR, "step1_ner_raw_output.csv")
    if not os.path.exists(input_path):
        print(f"❌ 未找到 {input_path}，请先运行 run_dataset_ner.py")
        return

    # 1. 加载数据
    print(f"Loading NER results from {input_path}...")
    df = pd.read_csv(input_path)
    
    # 2. 提取所有唯一实体 (全局去重)
    print("Extracting unique entities...")
    all_entities = set()
    for raw in df['raw_ner_output']:
        items = clean_and_split(raw)
        all_entities.update(items)
    
    unique_entities_list = list(all_entities)
    print(f"📊 统计: 总数据行数 {len(df)}，其中包含 {len(unique_entities_list)} 个唯一实体。")
    
    if not unique_entities_list:
        print("⚠️ 未发现任何实体，退出。")
        return

    # 3. 加载标准词典
    if not os.path.exists(config.DICT_FILE):
        print(f"⚠️ 警告：未找到词典 {config.DICT_FILE}，使用默认回退词典。")
        target_words = ["感冒", "发烧", "肺炎", "高血压", "糖尿病"]
    else:
        with open(config.DICT_FILE, 'r', encoding='utf-8') as f:
            target_words = [line.strip() for line in f if line.strip()]
    print(f"📚 标准词典大小: {len(target_words)}")

    # 4. 加载模型并计算 Embeddings
    print("Loading Embedding Model...")
    model, tokenizer = load_embedding_model()

    print("Embedding Target Dictionary...")
    # 词典向量通常比较大，计算一次即可
    target_embeddings = get_embeddings(target_words, model, tokenizer, batch_size=BATCH_SIZE)

    print(f"Embedding {len(unique_entities_list)} Unique Candidates...")
    candidate_embeddings = get_embeddings(unique_entities_list, model, tokenizer, batch_size=BATCH_SIZE)

    # 5. 批量计算相似度 (核心加速步骤)
    print("Computing Similarity Matrix...")
    # 结果是一个数组，对应 unique_entities_list 中每个词的最大相似度分数
    max_scores = compute_cosine_similarity_torch(candidate_embeddings, target_embeddings)

    # 6. 构建查询字典 {实体名: (是否保留, 分数)}
    entity_lookup = {}
    keep_count = 0
    
    for entity, score in zip(unique_entities_list, max_scores):
        is_valid = score >= SIMILARITY_THRESHOLD
        entity_lookup[entity] = (is_valid, score)
        if is_valid:
            keep_count += 1
            
    print(f"✅ 过滤完成: {keep_count}/{len(unique_entities_list)} 个实体通过阈值 ({SIMILARITY_THRESHOLD})")

    # 7. 回填到 DataFrame
    print("Mapping results back to DataFrame...")
    
    final_rows = []
    # 使用 tqdm 显示进度
    for _, row in tqdm(df.iterrows(), total=len(df)):
        raw_output = row.get('raw_ner_output', '')
        original_text = row.get('original_text', '')
        
        current_entities = clean_and_split(raw_output)
        
        valid_entities_str = []
        details_list = []
        
        for ent in current_entities:
            # 查表 O(1)
            is_valid, score = entity_lookup.get(ent, (False, 0.0))
            
            if is_valid:
                valid_entities_str.append(ent)
                details_list.append(f"{ent}({score:.2f})")
            # 也可以选择记录被过滤掉的词，方便分析
        
        final_rows.append({
            "original_text": original_text,
            "raw_ner_output": raw_output, # 保留原始输出方便对比
            "filtered_entities": ", ".join(valid_entities_str),
            "similarity_details": "; ".join(details_list)
        })

    # 8. 保存
    save_path = os.path.join(config.OUTPUT_DIR, "step2_ner_filtered.csv")
    result_df = pd.DataFrame(final_rows)
    result_df.to_csv(save_path, index=False, encoding='utf-8-sig')
    
    print(f"\n🎉 流程结束！结果已保存至: {save_path}")
    print("样本预览:")
    print(result_df[['filtered_entities', 'similarity_details']].head(3))

if __name__ == "__main__":
    run_similarity_filter()