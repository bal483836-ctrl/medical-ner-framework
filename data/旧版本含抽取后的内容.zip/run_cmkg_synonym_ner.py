import pandas as pd
import os
import config
from tqdm import tqdm

def load_kg_data():
    """
    加载完整的知识图谱数据：
    1. Triples (关系): 用于扩展同义词/关联词
    2. Entities Dict (实体库): 用于验证是否为标准词
    """
    kg_relations = {} # 存储关系映射 k -> [v1, v2]
    kg_nodes = set()  # 存储所有标准实体
    
    # 1. 加载实体词典 (entities_dict.txt)
    if os.path.exists(config.DICT_FILE):
        print(f"📚 正在加载实体词典: {config.DICT_FILE}")
        with open(config.DICT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                word = line.strip()
                if word:
                    kg_nodes.add(word)
    else:
        print(f"⚠️ 未找到实体词典 {config.DICT_FILE}")

    # 2. 加载三元组 (triples.txt)
    if os.path.exists(config.KG_FILE):
        print(f"🔗 正在加载三元组关系: {config.KG_FILE}")
        with open(config.KG_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line: continue
                # 兼容 tab 或 逗号
                parts = line.split('\t') if '\t' in line else line.split(',')
                
                if len(parts) >= 2:
                    head = parts[0].strip()
                    tail = parts[-1].strip()
                    if head and tail:
                        # 记录节点
                        kg_nodes.add(head)
                        kg_nodes.add(tail)
                        # 记录正向关系
                        if head not in kg_relations: kg_relations[head] = []
                        kg_relations[head].append(tail)
                        # (可选) 如果是同义词关系，通常是双向的，这里暂存单向
    else:
        print(f"⚠️ 未找到三元组文件 {config.KG_FILE}")

    print(f"✅ KG 加载完毕: {len(kg_nodes)} 个实体, {len(kg_relations)} 个关系源节点")
    return kg_relations, kg_nodes

def main():
    print("=== [Step 3] 知识图谱扩展 (KG Expansion) ===")
    
    # 输入文件：通常是 Step 2 过滤后的结果，或者是断言后的结果 (视流程而定)
    # 这里假设接在 Step 2 之后，或者 Step 3 (Assertion) 之后
    # 为了通用性，优先读取 Assertion 结果，如果没有则读取 Filter 结果
    input_path = os.path.join(config.OUTPUT_DIR, "step3_assertion_results.csv")
    if not os.path.exists(input_path):
        input_path = os.path.join(config.OUTPUT_DIR, "step2_ner_filtered.csv")
    
    if not os.path.exists(input_path):
        print("❌ 未找到上一步的输出文件 (Assertion 或 Filtered csv)")
        return

    print(f"📖 读取输入文件: {input_path}")
    df = pd.read_csv(input_path)
    
    # =========================================================================
    # 🟢 [核心修复] 实体爆炸 (Entity Explode)
    # 将逗号分隔的合成实体 (如 "发热, 咳嗽") 拆分成独立行，拯救 100% 失败的 KG 匹配
    # =========================================================================
    if 'filtered_entities' in df.columns:
        df['target_entity'] = df['filtered_entities'].astype(str).str.split(',')
    elif 'target_entity' in df.columns:
        df['target_entity'] = df['target_entity'].astype(str).str.split(',')
    elif 'entity' in df.columns:
        df['target_entity'] = df['entity'].astype(str).str.split(',')
        
    if 'target_entity' in df.columns:
        df = df.explode('target_entity')
        df['target_entity'] = df['target_entity'].astype(str).str.strip()
        # 清除清洗后产生的空值或无效值
        df = df[(df['target_entity'] != '') & (df['target_entity'] != 'nan') & (df['target_entity'] != 'None')]
        df = df.dropna(subset=['target_entity'])
        print(f"💥 实体拆分完毕，独立判定任务总数跃升至: {len(df)} 条")

    # 加载 KG
    kg_relations, kg_nodes = load_kg_data()
    
    if not kg_nodes and not kg_relations:
        print("⚠️ KG 数据为空，仅复制文件。")
        df.to_csv(os.path.join(config.OUTPUT_DIR, "final_kg_expanded.csv"), index=False, encoding='utf-8-sig')
        return

    expanded_data = []
    print("🚀 开始扩展实体信息...")

    for _, row in tqdm(df.iterrows(), total=len(df), desc="KG Expansion"):
        ent = str(row.get('target_entity', '')).strip()
        
        # 1. 验证是否为 KG 标准词
        is_standard = ent in kg_nodes
        
        # 2. 查找关联知识 (Triples)
        relations = kg_relations.get(ent, [])
        
        # 3. 模糊匹配补充 (如果直接匹配没找到)
        if not relations and not is_standard:
            # 简单的包含匹配策略
            for known_ent in kg_relations:
                if len(known_ent) > 1 and known_ent in ent:
                    relations.extend(kg_relations[known_ent])
                    if len(relations) >= 3: break # 限制数量
        
        # 4. 格式化输出信息
        knowledge_parts = []
        if is_standard:
            knowledge_parts.append("[KG认证词]")
        
        if relations:
            # 去重并取前 5 个
            unique_rels = list(set(relations))[:5]
            knowledge_parts.append(f"关联: {','.join(unique_rels)}")
            
        row_dict = row.to_dict()
        row_dict['kg_knowledge'] = " | ".join(knowledge_parts) if knowledge_parts else "无关联知识"
        
        expanded_data.append(row_dict)

    out_path = os.path.join(config.OUTPUT_DIR, "final_kg_expanded.csv")
    pd.DataFrame(expanded_data).to_csv(out_path, index=False, encoding='utf-8-sig')
    print(f"✅ 扩展完成！最终结果已保存至: {out_path}")

if __name__ == "__main__":
    main()