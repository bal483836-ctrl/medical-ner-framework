import pandas as pd
import os
import json
import re
from tqdm import tqdm
import sys
import torch
import random
import numpy as np

# 尝试导入辅助函数
try:
    from helper_functions import load_qwen_model
    import config
except ImportError:
    sys.path.append("/root/autodl-tmp/MedNER_Project")
    from helper_functions import load_qwen_model
    import config

# ================= 配置 =================
BASE_DIR = "/root/autodl-tmp/MedNER_Project"
BATCH_SIZE = 5

# 输入：读取 Step 4 的结果
INPUT_FILE = os.path.join(BASE_DIR, "outputs", "step4_context_extracted.csv")
# 输出：Step 5 结果 (实时写入这个文件)
OUTPUT_FILE = os.path.join(BASE_DIR, "outputs", "step5_assertion_results.csv")
# =======================================

# 🟢 全局随机种子锁定函数
def seed_everything(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    print(f"🔒 [System] 全局随机种子已锁定: {seed}")

# 🟢 优化版系统提示词
SYSTEM_PROMPT = """你是一个严谨的临床医学信息提取专家。你的核心任务是对医学文本中的实体进行状态断言分类。"""

# 🟢 Qwen3 适配版提示模板：结合 Entity Marker 与 General 兜底类
USER_PROMPT_TEMPLATE = """
【任务】分析下文【医学语境】中被特殊标记符 [E] 和 [/E] 包裹的【目标实体】，判断其客观临床存在状态。

【硬约束(Label Set)】你必须严格从以下 4 个标签中选择 1 个，绝不能输出其他词汇：
1. Present (阳性): 语境明确说明该疾病/症状/状态存在，或是患者确诊。
2. Absent (阴性): 语境明确否认、排除或说明没有该疾病/症状。
3. Possible (疑似): 语境说明疑似、可能、待排查该疾病，或概率发生。
4. General (一般性描述): 语境是医学教材、科普说明、用药禁忌或泛泛而谈，没有针对具体患者的“有/无”状态！(例如：“阿司匹林可治疗头痛”、“高血压会导致晕厥”均属于此类)

【医学语境】
{marked_text}

【目标实体】
{entity_name}

【输出格式】
仅输出标准JSON，不要包含任何Markdown标记或额外解释：
{{"results": [{{"entity": "{entity_name}", "status": "从4个标签中选1个"}}]}}
"""

def extract_status_from_text(text):
    """
    🟢 增强版解析函数，增加对 General 的捕获
    """
    if not text: return "ParseError"
    
    clean_text = re.sub(r'```json\s*|\s*```', '', text).strip()
    match = re.search(r'\{.*\}', clean_text, re.DOTALL)
    
    if match: 
        json_str = match.group(0)
        try:
            data = json.loads(json_str)
            if "results" in data and isinstance(data["results"], list) and len(data["results"]) > 0:
                 return data["results"][0].get("status", "ParseError")
            return data.get("status", "ParseError")
        except json.JSONDecodeError:
            pass

    # 兜底逻辑：正则硬抓
    if re.search(r'Present|阳性', text, re.IGNORECASE): return "Present"
    if re.search(r'Absent|阴性|否认', text, re.IGNORECASE): return "Absent"
    if re.search(r'Possible|可能|疑似', text, re.IGNORECASE): return "Possible"
    if re.search(r'General|一般', text, re.IGNORECASE): return "General"
    
    return "ParseError"

def run_assertion_check():
    seed_everything(42)

    print(f"🚀 [Step 5] 启动极速批量推理模式 (Batch Size: {BATCH_SIZE})...")
    
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 找不到输入文件: {INPUT_FILE}")
        return
        
    df_input = pd.read_csv(INPUT_FILE)
    total_rows = len(df_input)
    print(f"📖 总任务量: {total_rows} 条")
    
    # 断点续传检查
    processed_count = 0
    if os.path.exists(OUTPUT_FILE):
        try:
            with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
                processed_count = sum(1 for _ in f) - 1 
            processed_count = max(0, processed_count)
            print(f"🔄 检测到存档: 已完成 {processed_count} 条")
        except:
            processed_count = 0
    
    if processed_count >= total_rows:
        print("✅ 任务已完成。")
        return

    df_to_process = df_input.iloc[processed_count:].copy()
    print(f"▶️ 剩余任务: {len(df_to_process)} 条")

    # 加载模型 (这里会调用你 config.py 中配置的 Qwen3-14B)
    print("🤖 正在加载 Qwen3 模型...")
    model, tokenizer = load_qwen_model()
    
    tokenizer.padding_side = 'left'
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        
    print(f"⚡ 开始批量推理 (每批 {BATCH_SIZE} 条)...")

    records = df_to_process.to_dict('records')
    entity_col = 'target_word' if 'target_word' in df_input.columns else 'entity'
    text_col = 'context' if 'context' in df_input.columns else 'text'

    pbar = tqdm(total=len(records), unit="sample")
    
    for i in range(0, len(records), BATCH_SIZE):
        batch_records = records[i : i + BATCH_SIZE]
        
        batch_prompts = []
        batch_entities = []
        batch_contexts = []
        
        # --- A. 批量构建 Prompt ---
        for row in batch_records:
            text_input = str(row.get(text_col, ''))
            entity_val = str(row.get(entity_col, '')).strip()
            
            if not entity_val or entity_val.lower() == 'nan': continue

            # 实体标记注入
            if entity_val in text_input:
                marked_text = text_input.replace(entity_val, f"[E]{entity_val}[/E]", 1)
            else:
                marked_text = f"{text_input} (目标: [E]{entity_val}[/E])"
            
            prompt_content = USER_PROMPT_TEMPLATE.format(marked_text=marked_text, entity_name=entity_val)
            
            messages = [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt_content}
            ]
            full_prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            
            batch_prompts.append(full_prompt)
            batch_entities.append(entity_val)
            batch_contexts.append(text_input)

        if not batch_prompts:
            pbar.update(len(batch_records))
            continue

        # --- B. 批量推理 ---
        try:
            inputs = tokenizer(batch_prompts, return_tensors="pt", padding=True, truncation=True, max_length=2048).to(model.device)
            
            with torch.no_grad():
                outputs = model.generate(
                    **inputs, 
                    max_new_tokens=64, 
                    temperature=0.01,
                    do_sample=False  
                )
            
            input_len = inputs.input_ids.shape[1]
            generated_ids = outputs[:, input_len:]
            responses = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)
            
        except RuntimeError as e:
            if "out of memory" in str(e):
                print(f"\n⚠️ 显存不足 (OOM)，请减小 BATCH_SIZE！当前: {BATCH_SIZE}")
                torch.cuda.empty_cache()
                exit(1)
            else:
                print(f"\n❌ 推理出错: {e}")
                responses = ["Error"] * len(batch_records)

        # --- C. 后处理与保存 ---
        result_buffer = []
        for j, response_text in enumerate(responses):
            entity = batch_entities[j]
            context = batch_contexts[j]
            
            status = extract_status_from_text(response_text)
            
            # 🟢 核心修正：教材/科普知识中的实体客观存在，General 也应当判定为 1 (阳性/有效实体)
            label = 1 if status in ['Present', 'Positive', 'Possible', 'General'] else 0
            
            result_buffer.append({
                "input_text": f"实体: {entity} [SEP] 语境: {context}",
                "assertion": f"{entity}:{status}",
                "label": label,
                "entity": entity,
                "context": context
            })
            
        # 写入文件
        df_chunk = pd.DataFrame(result_buffer)
        write_header = not os.path.exists(OUTPUT_FILE)
        df_chunk.to_csv(OUTPUT_FILE, mode='a', header=write_header, index=False, encoding='utf-8-sig')
        
        pbar.update(len(batch_records))

    pbar.close()
    print(f"\n✅ [Step 5] 完成！结果保存在: {OUTPUT_FILE}")

if __name__ == "__main__":
    run_assertion_check()