import os
import torch
import pandas as pd
import numpy as np
import scipy.special
from tqdm import tqdm
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
from transformers import AutoModelForSequenceClassification, BertTokenizer

# ================= 配置 =================
BASE_DIR = "/root/autodl-tmp/MedNER_Project"

# 1. 刚刚用新数据集跑出来的测试集路径
TEST_DATA_PATH = os.path.join(BASE_DIR, "outputs/step5_assertion_results.csv")
STEP4_DATA_PATH = os.path.join(BASE_DIR, "outputs/step4_context_extracted.csv")

# 2. 你之前训练好的 BERT 模型权重路径
MODEL_DIR = os.path.join(BASE_DIR, "models/bert_finetuned_final/final")

BATCH_SIZE = 32
# =======================================

def load_and_prepare_test_data():
    """
    加载全新测试集，并使用与训练时完全一致的逻辑构建特征。
    """
    print(f"📂 正在加载全新测试集: {TEST_DATA_PATH}")
    if not os.path.exists(TEST_DATA_PATH):
        raise FileNotFoundError(f"找不到测试集文件: {TEST_DATA_PATH}，请确保流水线已跑完！")
        
    df = pd.read_csv(TEST_DATA_PATH)
    
    # 1. 从 Qwen 的输出中提取标准标签 (0为阴性, 1为阳性)
    def strict_label(x):
        x_str = str(x).lower()
        if any(k in x_str for k in ['present', 'positive', 'possible', 'general']): return 1
        elif any(k in x_str for k in ['absent', 'negative']): return 0
        else: return -1

    if 'assertion' in df.columns:
        df['label'] = df['assertion'].apply(strict_label)
        df = df[df['label'] != -1] # 过滤掉解析失败的数据

    # 2. 合并知识图谱信息 (如果有的话)
    if os.path.exists(STEP4_DATA_PATH):
        df4 = pd.read_csv(STEP4_DATA_PATH)
        if 'kg_knowledge' in df4.columns:
            df4 = df4.rename(columns={'target_word': 'entity'}).drop_duplicates(subset=['entity', 'context'])
            df = pd.merge(df, df4[['entity', 'context', 'kg_knowledge']], on=['entity', 'context'], how='left')

    if 'kg_knowledge' not in df.columns: 
        df['kg_knowledge'] = '无关联知识'
    df['kg_knowledge'] = df['kg_knowledge'].fillna('无关联知识')
    
    # 3. 严格复刻训练时的 Query 和带有【实体】标记的 Context
    df['query'] = "实体：" + df['entity'].astype(str) + " 知识：" + df['kg_knowledge'].astype(str)
    
    def add_entity_markers(row):
        ctx = str(row['context'])
        ent = str(row['entity'])
        if ent in ctx:
            marked_ctx = ctx.replace(ent, f"【{ent}】", 1) 
        else:
            marked_ctx = f"【{ent}】{ctx}" 
        return f"语境：{marked_ctx}"

    df['context_text'] = df.apply(add_entity_markers, axis=1)
    
    # 提取需要的列并清理空值
    df = df[['query', 'context_text', 'label', 'entity', 'context', 'kg_knowledge']].dropna(subset=['query', 'context_text', 'label'])
    df['label'] = df['label'].astype(int)
    
    return df

def main():
    print("==================================================")
    print("🚀 启动生产级 BERT 分类器【CMB临床病例】终极盲测")
    print("==================================================")
    
    if not os.path.exists(MODEL_DIR):
        print(f"❌ 找不到模型权重目录: {MODEL_DIR}")
        return

    # 1. 准备测试集
    df = load_and_prepare_test_data()
    queries = df['query'].tolist()
    contexts = df['context_text'].tolist()
    true_labels = df['label'].tolist() # 这里是将 Qwen 的判断视作金标准 Ground Truth
    
    print(f"\n📊 盲测数据集有效实体对数量: {len(df)}")
    print(f"   -> 阴性(0) 样本数: {true_labels.count(0)}")
    print(f"   -> 阳性(1) 样本数: {true_labels.count(1)}")

    # 2. 加载模型
    print(f"\n🤖 正在加载本地微调的 BERT 模型...")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tokenizer = BertTokenizer.from_pretrained(MODEL_DIR)
    model = AutoModelForSequenceClassification.from_pretrained(MODEL_DIR)
    model.to(device)
    model.eval()

    # 3. 批量推理
    all_probs = []
    print("\n⚡ 开始批量推理计算...")
    
    with torch.no_grad():
        for i in tqdm(range(0, len(queries), BATCH_SIZE), desc="Inference"):
            batch_queries = queries[i : i + BATCH_SIZE]
            batch_contexts = contexts[i : i + BATCH_SIZE]
            
            inputs = tokenizer(
                batch_queries, 
                batch_contexts, 
                padding="max_length", 
                truncation=True, 
                max_length=512, 
                return_tensors="pt"
            ).to(device)
            
            outputs = model(**inputs)
            logits = outputs.logits.cpu().numpy()
            
            # 提取分类为 1 (阳性) 的概率
            probs = scipy.special.softmax(logits, axis=1)[:, 1]
            all_probs.extend(probs.tolist())

    # 4. 评估指标计算
    all_probs = np.array(all_probs)
    true_labels = np.array(true_labels)
    preds_default = (all_probs >= 0.5).astype(int)
    
    print("\n" + "="*60)
    print("📈 全新临床病历测试集 (CMB) 评估报告 (判定阈值: 0.5)")
    print("-" * 60)
    
    acc = accuracy_score(true_labels, preds_default)
    
    # 增加 zero_division=0 防止因样本极度不平衡(如全是阳性或阴性)导致的警告
    f1_macro = f1_score(true_labels, preds_default, average='macro', zero_division=0)
    f1_binary = f1_score(true_labels, preds_default, average='binary', zero_division=0) 
    
    print(classification_report(true_labels, preds_default, labels=[0, 1], target_names=["阴性(0)", "阳性(1)"], digits=4, zero_division=0))
    
    cm = confusion_matrix(true_labels, preds_default, labels=[0, 1])
    print("🎯 混淆矩阵:")
    print(f"      真实 \\ 预测 |  猜阴性(0)  |  猜阳性(1)")
    print(f"      ------------|-------------|------------")
    print(f"       实际阴性(0) |   TN: {cm[0][0]:<5} |   FP: {cm[0][1]:<5}")
    print(f"       实际阳性(1) |   FN: {cm[1][0]:<5} |   TP: {cm[1][1]:<5}")
    print("-" * 60)
    print(f"🏆 总体准确率 (Accuracy) : {acc:.4f}")
    print(f"🏆 阳性 F1 (F1 Binary)   : {f1_binary:.4f}")
    print(f"🏆 宏平均 F1 (F1 Macro)  : {f1_macro:.4f}")
    
    # 5. 保存错误预测 (Bad Cases) 供分析
    df['bert_predict_prob'] = all_probs
    df['bert_predict_label'] = preds_default
    bad_cases = df[df['label'] != df['bert_predict_label']]
    
    bad_case_path = os.path.join(BASE_DIR, "outputs/cmb_blind_test_bad_cases.csv")
    bad_cases.to_csv(bad_case_path, index=False, encoding='utf-8-sig')
    print(f"\n🕵️‍♂️ 对比 Qwen 的结果，BERT 共有 {len(bad_cases)} 条判断不一致的样本。")
    print(f"💾 已将差异样本保存至: {bad_case_path}，你可以打开查看是 BERT 错了还是 Qwen 判错了！")

if __name__ == "__main__":
    main()