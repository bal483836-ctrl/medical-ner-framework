import os
import torch

# ================= 基础路径配置 =================
BASE_DIR = "/root/autodl-tmp/MedNER_Project"
DATA_DIR = os.path.join(BASE_DIR, "data")
MODEL_DIR = os.path.join(BASE_DIR, "models")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ================= 模型配置 =================
LLM_MODEL_ID = "Qwen/Qwen3-14B"  # 或者是 Qwen/Qwen3-14B-Instruct 等
LLM_MODEL_PATH = os.path.join(MODEL_DIR, "Qwen3-14B")

# Embedding: BGE-Large (用于相似度计算)
EMBEDDING_MODEL_ID = "BAAI/bge-large-zh-v1.5"
EMBEDDING_MODEL_PATH = os.path.join(MODEL_DIR, "bge-large-zh-v1.5")

# BERT: Google BERT Base (用于分类器微调等其他任务)
BERT_MODEL_ID = "chinese-roberta-wwm-ext" 
BERT_MODEL_PATH = os.path.join(MODEL_DIR, "chinese-roberta-wwm-ext")

# ================= 数据文件路径 =================
# ================= 数据文件路径 =================
CMEEE_FILE = os.path.join(DATA_DIR, "cmeee.json")
KG_FILE = os.path.join(DATA_DIR, "triples.txt")
DICT_FILE = os.path.join(DATA_DIR, "entities_dict.txt")

# ================= 核心参数 =================
COSINE_SIMILARITY_THRESHOLD = 0.8
CONTEXT_WINDOW_SIZE = 128            
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# ================= 训练参数 =================
MAX_LEN = 128
BATCH_SIZE = 16
LEARNING_RATE = 2e-5  
EPOCHS = 10